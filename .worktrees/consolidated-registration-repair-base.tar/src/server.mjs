import { createServer } from 'node:http';
import { Readable } from 'node:stream';
import { createHash, randomUUID } from 'node:crypto';
import { del as blobDelete, get as blobGet, put as blobPut } from '@vercel/blob';
import { readFile } from 'node:fs/promises';
import { extname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { SIDEBAR_MODULES, parentDashboardModules, sidebarHealth, visibleSidebar } from './sidebar-registry.js';
import { canAccess, canonicalRoleKey, createAuthService } from './auth.js';
import { createUserDirectoryService } from './user-directory.js';
import { createRoleProvisioningDiagnostic } from './role-provisioning-diagnostic.js';
import { createDurableRoleAccountProvisioning } from './durable-role-account-provisioning.js';
import { createAuditLog } from './audit.js';
import { CORE_LEVELS, createStudentService } from './students.js';
import { canonicalClassId, TRANSFER_PREVIOUS_CLASS_OPTIONS } from './student-classes.js';
import { displayStudentGender } from './student-gender.js';
import { createClassDatabaseService } from './class-database.js';
import { ACADEMIC_YEAR_OPTIONS, ATTENDANCE_METHODS, STUDENT_REASON_STATUSES, STUDENT_STATUSES, TERM_OPTIONS, createAttendanceService } from './attendance.js';
import { createAttendanceRepository } from './attendance-repository.js';
import { createAttendanceRegisterService } from './attendance-register-service.js';
import { createAttendanceAggregationService } from './attendance-aggregation.js';
import { createStaffAttendanceOverviewService } from './staff-attendance-overview.js';
import { createStudentAttendanceOverviewService } from './student-attendance-overview.js';
import { createExaminationService } from './examinations.js';
import { createFeeService } from './fees.js';
import { createFeeCollectionsRepository } from './fee-collections-repository.js';
import { createBudgetService } from './budgets.js';
import { createGeneralFinanceService } from './general-finance.js';
import { createCashbookService } from './cashbook.js';
import { createParentFeeObligationsRepository } from './parent-fee-obligations-repository.js';
import { createStaffService } from './staff.js';
import { createStaffLeaveReconciler } from './staff-leave-reconciler.js';
import { STAFF_ATTENDANCE_STATUSES, typeFromStaffAttendanceStatus } from './staff-leave-reconciliation.js';
import { createCommunicationService } from './communication.js';
import { createDurableAnnouncementsService } from './durable-announcements.js';
import { createAcademicCalendarService } from './academic-calendar.js';
import { createOperationsService } from './operations.js';
import { createResourceService } from './resources.js';
import { createComplianceService } from './compliance.js';
import { createReportingService } from './reporting.js';
import { createAdmissionFormService } from './admission-form.js';
import { createCommunicationEngine } from './communication-engine.js';
import { createArkeselGateway, createDurableSmsService, SMS_AUTHORIZED_ROLES } from './durable-sms.js';
import { createTranscriptService } from './transcripts.js';
import { createAdmissionProspectusService, DEFAULT_PROSPECTUS_TEMPLATE, PROSPECTUS_PERMISSION } from './admission-prospectus.js';
import { createAcademicResultsService, RESULT_HEADER_ASSET } from './academic-results.js';
import { createResultSlipPdfService } from './result-slip-pdf.js';
import { createSampleResultWorkflow } from './sample-result-workflow.js';
import { isSampleModeEnabled, PRODUCTION_SAFE_ACADEMIC_SAMPLE_ENDPOINTS } from './academic-sample-mode.js';
import { createSubjectService } from './subjects.js';
import { createSignatureService } from './signatures.js';
import { createProprietorAuthenticationController } from './proprietor-authentication-controller.js';
import { createReceiptBrandingService } from './receipt-branding.js';
import { createSportingActivitiesService, SPORTING_PERMISSIONS } from './sporting-activities.js';
import { createSubjectRegisterService, SUBJECT_REGISTER_PERMISSIONS } from './subject-register.js';
import { createShepActivitiesService, SHEP_PERMISSIONS } from './shep-activities.js';
import { createAdmissionProspectusPdfService } from './admission-prospectus-pdf.js';
import { createFinancialIntelligenceService } from './ai/financial-intelligence.js';
import { createAcademicAttendanceIntelligence } from './ai/academic-attendance-intelligence.js';
import { createAdmissionsWorkforceIntelligence } from './ai/admissions-workforce-intelligence.js';
import { createAdmissionEnrollmentService } from './admission-enrollment.js';
import { createExistingStudentLinkingService } from './existing-student-linking.js';
import { assessAdmissionFees } from './admission-fee-assessment.js';
import { createDurableAdmissionsService } from './durable-admissions.js';
import { inspectAdmissionSchema } from './admission-schema-diagnostic.js';
import { createAdmissionDocumentStorage, createVercelPrivateBlobProvider } from './admission-document-storage.js';
import { createDurableStudentProfileService } from './durable-student-profile.js';
import { createDurableAcademicService } from './durable-academic.js';
import { createDurablePromotionService } from './durable-promotion.js';
import { createDurableResultBlockingService } from './durable-result-blocking.js';
import { createFeeTypeRegistry } from './fee-types.js';
import { createInternalStudentRegistrationService, internalRegistrationErrorLogFields } from './internal-student-registration.js';
const releaseMetadata = Object.freeze({
  commitSha: process.env.VERCEL_GIT_COMMIT_SHA ?? process.env.GIT_COMMIT_SHA ?? 'unknown',
  deploymentId: process.env.VERCEL_DEPLOYMENT_ID ?? process.env.VERCEL_URL ?? 'local',
  environment: process.env.VERCEL_ENV ?? 'development'
});

export async function checkAuthenticationDatabaseHealth(database) {
  const safeCode = (error) => /^[A-Z0-9_]+$/.test(String(error?.code ?? '')) ? error.code : 'UNKNOWN';
  const result = { db: 'down', sessionStore: database?.supportsDurableAuthSessions ? 'down' : 'unsupported' };
  if (!database?.query) return result;
  try {
    await database.query('SELECT 1', []);
    result.db = 'up';
  } catch (error) {
    return { ...result, databaseErrorCode: safeCode(error) };
  }
  if (database.supportsDurableAuthSessions) {
    try {
      await database.query('SELECT id, user_id, school_id, token_hash, created_at, expires_at, revoked_at, last_used_at FROM auth_sessions LIMIT 0', []);
      result.sessionStore = 'up';
    } catch (error) {
      result.sessionErrorCode = safeCode(error);
    }
  }
  return result;
}
import { createOperationalAnalyticsRegistry, createOperationalIntelligence, registerBuiltInOperationalProviders } from './ai/operational-intelligence.js';
import { createSchoolKnowledgeIntelligence, syncRepositoryKnowledgeSources } from './ai/school-knowledge-intelligence.js';
import { createExecutiveCapabilityAdapters, createExecutiveIntelligence } from './ai/executive-intelligence.js';
import { createAIActionAdapters, createHumanControlledActions } from './ai/human-controlled-actions.js';
import { createAIAdministration } from './ai/administration.js';
import { createAIAuditLogger } from './ai/audit-logger.js';
import { createDisabledAIPersistence, loadConfiguredAIPersistence, loadConfiguredDatabaseAdapter, selectAIPersistence } from './ai/durable-stores.js';
import { assertProductionAISystemOfRecordReady } from './ai/system-of-record-readiness.js';
import { buildAIRegistry } from './ai/registry.js';
import { createProductionDataGuard } from './ai/production-data-guard.js';
import { createAIDataQualityGuard } from './ai/data-quality-guard.js';
import { createSchoolContextService } from './ai/school-context.js';
import { createConfiguredAIProviderRegistry } from './ai/provider-config.js';
import { createAIGateway } from './ai/gateway.js';
import { createAIOrchestrator } from './ai/orchestrator.js';
import { createAIConversationService } from './ai/conversation.js';
import './module-registry.js';
import { PROPRIETOR_PAGE_ALIASES, PROPRIETOR_SIDEBAR_ROUTES } from './proprietor-sidebar-routes.js';
import { resolveRouteContract } from './sidebar-route-contract.js';
import { authorizeFinancial, assertInputSchool, FinancialAuthorizationError } from './financial-authorization.js';
import { DEFAULT_PRODUCTION_SCHOOL_ID, DEMO_SCHOOL_ID, resolveCurrentSchoolContext } from './school-context.js';
import { createDurableFeeReader } from './durable-fee-reader.js';
import { createDurableFeePayments } from './durable-fee-payments.js';
import { createParentDashboardService } from './parent-dashboard.js';
import { createParentHistoricalRecordsService } from './parent-historical-records.js';
import { createSampleFixtureRepository } from './sample-fixture-repository.js';
import { createSchoolSettingsService } from './school-settings.js';
import { createSingleSchoolOverviewService } from './single-school-overview.js';
import { createSchoolProfileService } from './school-profile.js';
import { authorizeParentStudent, PARENT_UNLINKED_MESSAGE } from './parent-authorization.js';
import { isConfiguredTestStudentId, sampleFixturesEnabled, seedSampleStudentsIfEnabled } from './test-parent-fixture.js';
import { createAssignmentService } from './assignments.js';
import { createAttendanceAnalyticsService } from './attendance-analytics.js';
import { createAttendanceReportsService } from './attendance-reports.js';

const root = join(fileURLToPath(new URL('.', import.meta.url)), '..', 'public');
const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml' };
const branding = { schoolName: 'OSAAH DAYLIGHT SCH. COM.', location: 'BOGOSO', motto: 'AIM HIGH, ACADEMIC IS OUR CORE VALUE', logoPath: '/assets/osaah-daylight-logo.png', colours: { navy: '#102a43', royalBlue: '#1769aa', gold: '#d4a72c', white: '#ffffff' } };

export function createApp({ auth = null, students = null, attendance = null, attendanceRepository = null, staffAttendanceOverview = null, studentAttendanceOverview = null, attendanceAnalytics = null, attendanceReports = null, examinations = null, fees = null, feeTypes = null, staff = null, communication = null, communicationEngine = null, durableAnnouncements = null, operations = null, resources = null, compliance = null, reporting = null, generalFinance = null, cashbook = null, admissionForms = null, admissionDocumentStorage = null, admissionProspectus = null, subjects = null, signatures = null, classDatabase = null, database = null, academicResults = null, transcripts = null, receiptBranding = null, prospectusPdf = createAdmissionProspectusPdfService(), resultPdf = createResultSlipPdfService(), sportingActivities = null, subjectRegister = null, shepActivities = null, assignments = null, aiGateway = null, aiConversation = null, capabilityRegistry = null, toolRegistry = null, providerRegistry = null, providerId = process.env.OSAAH_AI_PROVIDER_ID ?? 'openai', modelId = process.env.OSAAH_AI_MODEL_ID ?? 'unconfigured', financialIntelligence = null, academicAttendanceIntelligence = null, admissionsWorkforceIntelligence = null, schoolSettings = null, operationalIntelligence = null, schoolKnowledgeIntelligence = null, academicCalendar = null, executiveIntelligence = null, humanControlledActions = null, aiPersistence = null, aiEnabled = null, audit = () => {}, singleSchoolOverview = null, schoolProfile = null, sampleFixtureRepository = null, resultBlocking = null, allowSmsNonProduction = false } = {}) {
  const serviceSchoolId = process.env.OSAAH_SCHOOL_ID ?? (database ? DEFAULT_PRODUCTION_SCHOOL_ID : DEMO_SCHOOL_ID);
  auth ??= createAuthService({ database, schoolId: serviceSchoolId, testParentSchoolId: serviceSchoolId });
  schoolSettings ??= createSchoolSettingsService({ database, schoolProfile: branding });
  const userDirectory = createUserDirectoryService({ database, canonicalSchoolId: serviceSchoolId });
  const roleProvisioningDiagnostic = createRoleProvisioningDiagnostic({ database });
  const durableRoleAccountProvisioning = database?.query && database?.transaction && database?.execute && auth?.hashPassword && auth?.loginFromDatabase && auth?.logoutSession
    ? createDurableRoleAccountProvisioning({ database, passwordHash: auth.hashPassword, verifyLogin: auth.loginFromDatabase, revokeSession: auth.logoutSession })
    : null;
  attendance ??= createAttendanceService({ requireReasons: true, schoolId: serviceSchoolId });
  fees ??= createFeeService({ schoolId: serviceSchoolId });
  feeTypes ??= createFeeTypeRegistry({ schoolId: serviceSchoolId });
  staff ??= createStaffService({ schoolId: serviceSchoolId });
  async function registeredAttendanceStaff(schoolId) {
    if (database?.query) {
      const rows = await database.query(`SELECT s.id AS id,s.staff_number AS employeeId,TRIM(CONCAT_WS(' ',s.first_name,s.last_name)) AS fullName,COALESCE((SELECT r.role_name FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=s.user_id ORDER BY r.oversight_rank DESC,r.role_key LIMIT 1),'Staff') AS roleKey,s.school_id AS schoolId FROM staff s WHERE s.school_id=? ORDER BY s.staff_number,s.id`, [schoolId]);
      return rows.map((member) => ({ id: member.id, employeeId: member.employeeId ?? member.staffNumber ?? member.id, fullName: member.fullName ?? [member.firstName, member.lastName].filter(Boolean).join(' '), roleKey: member.roleKey ?? 'Staff', schoolId: member.schoolId ?? schoolId }));
    }
    return staff.listProfiles().filter((member) => member.schoolId === schoolId && member.employmentStatus === 'ACTIVE').map((member) => ({ ...member, employeeId: member.employeeId ?? member.staffId ?? member.id, roleKey: member.roleKey ?? 'Staff' }));
  }
  async function isRegisteredAttendanceStaff(staffId, schoolId) {
    if (database?.query) {
      const rows = await database.query('SELECT id FROM staff WHERE id=? AND school_id=? LIMIT 1', [staffId, schoolId]);
      return rows.length > 0;
    }
    return staff.listProfiles().some((member) => member.schoolId === schoolId && member.employmentStatus === 'ACTIVE' && (member.id === staffId || member.staffId === staffId));
  }
  function isCalendarDate(value) {
    const match = String(value ?? '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) return false;
    const parsed = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
    return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
  }
  async function isValidStaffAttendanceScope(schoolId, academicYear, term) {
    if (database?.query) {
      const rows = await database.query('SELECT t.id FROM academic_years y JOIN terms t ON t.academic_year_id=y.id WHERE y.school_id=? AND (y.id=? OR y.name=?) AND (t.id=? OR t.name=?) LIMIT 1', [schoolId, academicYear, academicYear, term, term]);
      return rows.length > 0;
    }
    return ACADEMIC_YEAR_OPTIONS.includes(academicYear) && TERM_OPTIONS.includes(term);
  }
  communication ??= createCommunicationService({ schoolId: serviceSchoolId });
  durableAnnouncements ??= database?.query && database?.execute ? createDurableAnnouncementsService({ database, schoolId: serviceSchoolId, audit }) : null;
  const smsGateway = createArkeselGateway();
  const smsRuntimeEnabled = (process.env.VERCEL === '1' && String(process.env.VERCEL_ENV ?? '').toLowerCase() === 'production' && String(process.env.NODE_ENV ?? '').toLowerCase() === 'production') || allowSmsNonProduction;
  const smsService = smsRuntimeEnabled && database?.query && database?.execute && database?.transaction ? createDurableSmsService({ database, schoolId: serviceSchoolId, gateway: smsGateway, audit }) : null;
  const smsAuthorized = (actor) => Boolean(actor && SMS_AUTHORIZED_ROLES.includes(canonicalRoleKey(actor.roleKey)) && canAccess(actor, 'messages.sms.send'));
  operations ??= createOperationsService({ schoolId: serviceSchoolId });
  resources ??= createResourceService({ schoolId: serviceSchoolId });
  compliance ??= createComplianceService({ schoolId: serviceSchoolId });
  reporting ??= createReportingService({ schoolId: serviceSchoolId });
  admissionForms ??= createAdmissionFormService({ schoolId: serviceSchoolId });
  admissionProspectus ??= createAdmissionProspectusService({ schoolId: serviceSchoolId });
  students ??= createStudentService({ schoolId: serviceSchoolId });
  examinations ??= createExaminationService({ students, classes: CORE_LEVELS, schoolId: serviceSchoolId });
  subjects ??= createSubjectService({ schoolId: serviceSchoolId });
  assignments ??= createAssignmentService({ database, subjects, students, classes: CORE_LEVELS, schoolId: serviceSchoolId });
  signatures ??= createSignatureService({ staff, schoolId: serviceSchoolId });
  singleSchoolOverview ??= createSingleSchoolOverviewService({ database, schoolSettings, students, attendance, attendanceRepository, examinations, fees, staff, communication, audit, schoolId: serviceSchoolId });
  schoolProfile ??= createSchoolProfileService({ database, schoolSettings, singleSchoolOverview, staff, schoolId: serviceSchoolId });
  academicCalendar ??= createAcademicCalendarService({ database, schoolId: serviceSchoolId, audit });
  seedSampleStudentsIfEnabled(students, serviceSchoolId);
  const feeCollections = database?.query && database?.execute && database?.transaction ? createFeeCollectionsRepository({ adapter: database, audit, strictValidation: true }) : null;
  const durableFeeReader = database?.supportsDurableAuthSessions && database?.query ? createDurableFeeReader({ adapter: database }) : null;
  const durableFeePayments = database?.query && database?.execute && database?.transaction ? createDurableFeePayments({ database, schoolId: serviceSchoolId, audit }) : null;
  const budgets = database?.query && database?.execute && database?.transaction ? createBudgetService({ adapter: database, audit }) : null;
  generalFinance ??= database?.query && database?.execute && database?.transaction ? createGeneralFinanceService({ adapter: database, budgets, audit }) : null;
  cashbook ??= database?.query ? createCashbookService({ adapter: database, students }) : null;
  attendanceRepository ??= database?.query && database?.execute ? createAttendanceRepository({ adapter: database }) : null;
  staffAttendanceOverview ??= createStaffAttendanceOverviewService({ database, attendanceRepository, attendance, schoolId: serviceSchoolId });
  studentAttendanceOverview ??= database?.query ? createStudentAttendanceOverviewService({ database, schoolId: serviceSchoolId }) : null;
  attendanceAnalytics ??= createAttendanceAnalyticsService({ database, studentOverview: studentAttendanceOverview, staffOverview: staffAttendanceOverview, attendanceRepository, attendance, schoolId: serviceSchoolId });
  attendanceReports ??= createAttendanceReportsService({ attendanceAnalytics, studentOverview: studentAttendanceOverview, staffOverview: staffAttendanceOverview, attendanceRepository, attendance, students, staff, schoolProfile, schoolId: serviceSchoolId, audit, now: () => new Date().toISOString() });
  const staffLeaveReconciler = createStaffLeaveReconciler({ attendance: attendanceRepository ?? attendance, schoolId: serviceSchoolId, audit });
  const parentFeeObligations = database?.query ? createParentFeeObligationsRepository(database) : null;
  const proprietorAuthentication = database ? createProprietorAuthenticationController({ database }) : null;
  const admissionEnrollment = database?.transaction ? createAdmissionEnrollmentService({ database }) : null;
  const existingStudentLinking = database?.query && database?.execute && database?.transaction ? createExistingStudentLinkingService({ database, schoolId: serviceSchoolId }) : null;
  const internalStudentRegistration = database?.transaction ? createInternalStudentRegistrationService({ database }) : null;
  const durableAdmissions = database?.query && database?.execute ? createDurableAdmissionsService({ database, schoolId: serviceSchoolId }) : null;
  admissionDocumentStorage ??= process.env.BLOB_STORE_ID ? createAdmissionDocumentStorage({ provider: createVercelPrivateBlobProvider({ put: blobPut, get: blobGet, del: blobDelete }) }) : null;
  async function admissionFeeStructures(actor, application) {
    if (database?.query) {
      if (!application?.section1?.classAppliedFor || !application?.section1?.academicYearId || !application?.section1?.termId) return [];
      return database.query("SELECT id,school_id AS schoolId,class_id AS classId,academic_year_id AS academicYearId,term_id AS termId,'ADMISSION' AS type,amount,status FROM fee_structures_v2 WHERE school_id=? AND status='PUBLISHED' AND UPPER(fee_type) LIKE '%ADMISSION%' AND class_id=? AND academic_year_id=? AND term_id=? ORDER BY published_at DESC,id", [actor.schoolId, application.section1.classAppliedFor, application.section1.academicYearId, application.section1.termId]);
    }
    return fees.listStructures(actor);
  }
  const durableStudentProfile = database?.query && database?.execute ? createDurableStudentProfileService({ database }) : null;
  const durableAcademic = database?.query && database?.execute ? createDurableAcademicService({ database, schoolId: serviceSchoolId, signatures, students }) : null;
  const durablePromotion = database?.query && database?.execute && database?.transaction ? createDurablePromotionService({ database, schoolId: serviceSchoolId }) : null;
  resultBlocking ??= database?.query && database?.execute ? createDurableResultBlockingService({ database, schoolId: serviceSchoolId, audit }) : null;
  async function attendanceClassOptions(actor) {
    if (!database?.query) return CORE_LEVELS.map((name, displayOrder) => ({ id: name, name: name.replace(/^Primary /, 'Basic ').replace(/^KG([12])$/, 'KG $1'), displayOrder }));
    let rows;
    try {
      rows = await database.query("SELECT id,name,sort_order AS displayOrder FROM classes WHERE school_id=? AND status='ACTIVE' ORDER BY sort_order,id", [actor.schoolId]);
    } catch (error) {
      if (!/unknown column|doesn\'?t exist|no such column/i.test(String(error?.message ?? error))) throw error;
      rows = await database.query('SELECT id,name FROM classes WHERE school_id=? ORDER BY id', [actor.schoolId]);
    }
    const assigned = new Set((actor.roleKey === 'TEACHER' ? actor.assignedClassIds ?? [] : []).map((value) => String(value)));
    return rows.filter((row) => !assigned.size || assigned.has(String(row.id)) || assigned.has(String(row.name)) || assigned.has(canonicalClassId(row.name))).map((row, index) => ({ id: row.id, name: row.name, displayOrder: row.displayOrder ?? index }));
  }
  async function resolveAttendanceClass(actor, requestedClassId) {
    const options = await attendanceClassOptions({ ...actor, roleKey: null });
    const requested = String(requestedClassId ?? '').trim();
    return options.find((row) => String(row.id) === requested || String(row.name) === requested || canonicalClassId(row.name) === canonicalClassId(requested)) ?? null;
  }
  async function canonicalFeeTypes(actor) {
    if (database?.query) {
      try {
        const rows = await database.query('SELECT id,code,name,category,description,is_active AS isActive,is_system AS isSystem FROM fee_types WHERE school_id=? AND is_active=TRUE ORDER BY name,id', [actor.schoolId]);
        if (rows.length) return rows;
      } catch {}
    }
    if (actor.schoolId !== serviceSchoolId) return [];
    return feeTypes.list({ schoolId: actor.schoolId });
  }
  async function feeSetupOptions(actor) {
    if (!actor || (!canAccess(actor, 'fees.read') && !canAccess(actor, 'fees.configure') && !canAccess(actor, 'fees.write'))) throw Object.assign(new Error('Forbidden.'), { status: 403 });
    if (!database?.query) return { academicYears: [], terms: [], feeTypes: [], canPublish: canAccess(actor, 'fees.write'), classes: CORE_LEVELS.map((name, index) => ({ id: name, name: name.replace(/^Primary /, 'Basic ').replace(/^KG([12])$/, 'KG $1'), displayOrder: index })) };
    const [academicYears, terms, configuredFeeTypes, classes] = await Promise.all([
      database.query('SELECT id,name,starts_on AS startsOn,ends_on AS endsOn,is_current AS isCurrent FROM academic_years WHERE school_id=? ORDER BY starts_on DESC, id',[actor.schoolId]),
      database.query('SELECT t.id,t.academic_year_id AS academicYearId,t.name,t.starts_on AS startsOn,t.ends_on AS endsOn,t.is_current AS isCurrent FROM terms t JOIN academic_years y ON y.id=t.academic_year_id WHERE y.school_id=? ORDER BY t.starts_on ASC,t.id',[actor.schoolId]),
      canonicalFeeTypes(actor),
      database.query("SELECT c.id,c.name,0 AS displayOrder,c.level AS levelName,COALESCE(l.display_order,999) AS levelOrder FROM classes c LEFT JOIN levels l ON l.school_id=c.school_id AND l.name=c.level WHERE c.school_id=? ORDER BY COALESCE(l.display_order,999),c.name,c.id",[actor.schoolId])
    ]);
    const normalizeTerm = (name) => String(name ?? '').trim().toLowerCase().replace(/^(first|1st)\s+term$/, '1st Term').replace(/^(second|2nd)\s+term$/, '2nd Term').replace(/^(third|3rd)\s+term$/, '3rd Term');
    const canonicalTerms = terms.length ? terms.map((item) => ({ ...item, name: normalizeTerm(item.name) })) : TERM_OPTIONS.map((name) => ({ id: name, academicYearId: null, name }));
    return { academicYears, terms: canonicalTerms, feeTypes: configuredFeeTypes.filter((item, index, list) => index === list.findIndex((candidate) => candidate.id === item.id)), canPublish: canAccess(actor, 'fees.write'), classes: classes.map((item) => ({ ...item, name: String(item.name).replace(/^Primary /, 'Basic ').replace(/^KG([12])$/, 'KG $1') })) };
  }
  const persistence = aiPersistence ?? selectAIPersistence({ environment: process.env.NODE_ENV ?? 'development', allowMemory: process.env.NODE_ENV !== 'production' });
  const aiAuditLogger = createAIAuditLogger({ sink: persistence.auditSink });
  sportingActivities ??= createSportingActivitiesService({ students });
  subjectRegister ??= createSubjectRegisterService({ subjects, staff });
  academicResults ??= createAcademicResultsService({ students, subjects, signatures, subjectRegister, schoolId: serviceSchoolId });
  classDatabase ??= createClassDatabaseService({ students, classes: CORE_LEVELS, schoolId: database ? null : serviceSchoolId });
  async function durableClassDatabaseList(filters, actor) {
    classDatabase.options(actor);
    if (!database?.query) return classDatabase.list(filters, actor);
    const profileColumnRows = await database.query(`SELECT COLUMN_NAME AS columnName FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='student_profiles' AND COLUMN_NAME IN ('previous_school','previous_class')`);
    const profileColumns = new Set(profileColumnRows.map((row) => String(row.columnName ?? row.COLUMN_NAME ?? '').toLowerCase()));
    const previousSchoolSelect = profileColumns.has('previous_school')
      ? `(SELECT sp.previous_school FROM student_profiles sp WHERE sp.school_id=s.school_id AND (sp.student_master_id=s.id OR (sp.student_master_id IS NULL AND sp.student_id=s.permanent_student_id)) ORDER BY sp.updated_at DESC,sp.id DESC LIMIT 1) AS previousSchool`
      : 'NULL AS previousSchool';
    const previousClassSelect = profileColumns.has('previous_class')
      ? `(SELECT sp.previous_class FROM student_profiles sp WHERE sp.school_id=s.school_id AND (sp.student_master_id=s.id OR (sp.student_master_id IS NULL AND sp.student_id=s.permanent_student_id)) ORDER BY sp.updated_at DESC,sp.id DESC LIMIT 1) AS previousClass`
      : 'NULL AS previousClass';
    const academicYear = String(filters.academicYear ?? '').trim();
    const classId = String(filters.classId ?? '').trim();
    const search = `%${String(filters.search ?? '').trim().toLowerCase()}%`;
    const results = await database.query(`SELECT s.permanent_student_id AS permanentStudentId,s.id AS studentId,
      TRIM(CONCAT_WS(' ',s.first_name,s.middle_name,s.last_name)) AS studentName,s.gender AS gender,
      s.parent_guardian_name AS parentGuardianName,s.parent_phone AS registeredParentPhone,
      ${previousSchoolSelect},${previousClassSelect},
      e.class_id AS classId,COALESCE(y.name,e.academic_year) AS academicYear
      FROM student_enrollments e JOIN students s ON s.id=e.student_id AND s.school_id=e.school_id
      LEFT JOIN academic_years y ON y.id=e.academic_year_id AND y.school_id=e.school_id
      WHERE e.school_id=? AND e.is_current=1 AND UPPER(COALESCE(e.enrollment_status,'ACTIVE')) NOT IN ('WITHDRAWN','TRANSFERRED','COMPLETED','GRADUATED')
      AND (?='' OR y.id=? OR y.name=? OR e.academic_year=?)
      AND (?='' OR e.class_id=? OR EXISTS (SELECT 1 FROM classes c WHERE c.school_id=e.school_id AND c.id=e.class_id AND c.name=?))
      AND (?='' OR LOWER(CONCAT_WS(' ',s.first_name,s.middle_name,s.last_name,s.permanent_student_id)) LIKE ?)
      AND s.is_test_record IS NOT TRUE
      ORDER BY s.last_name,s.first_name,s.id`, [actor.schoolId, academicYear, academicYear, academicYear, academicYear, classId, classId, classId, search, search]);
    const assigned = actor.roleKey === 'TEACHER' ? new Set((actor.assignedClassIds ?? []).map(String)) : null;
    return results.filter((row) => !assigned || assigned.has(String(row.classId))).map((row) => ({ ...row, gender: displayStudentGender(row.gender) }));
  }
  sampleFixtureRepository ??= database?.query && database?.execute ? createSampleFixtureRepository({ adapter: database, schoolId: serviceSchoolId }) : null;
  const sampleResults = createSampleResultWorkflow({ students, subjects, academicResults, sampleFixtureRepository, schoolId: serviceSchoolId });
  async function normalizedSampleResultInput(input, actor) {
    let contextInput = input;
    if (durableAcademic) {
      const requestedClass = canonicalClassId(input.classId);
      const options = await durableAcademic.options(actor);
      const classRow = options.classes?.find((item) => String(item.id) === String(input.classId) || canonicalClassId(item.name) === requestedClass || canonicalClassId(item.id) === requestedClass);
      if (classRow) contextInput = { ...input, classId: classRow.id };
    }
    const context = durableAcademic ? await durableAcademic.resultContext(contextInput, actor) : { className: input.classId, academicYear: input.academicYear, term: input.term };
    const classId = canonicalClassId(context.className);
    if (!classId) throw new Error('The selected class is not configured for sample results.');
    return { input: { ...input, classId, academicYear: context.academicYear, term: context.term }, className: context.className };
  }
  async function normalizedSampleMockScoreInput(input, actor) {
    if (actor.portal !== 'school') throw Object.assign(new Error('Forbidden.'), { status: 403 });
    let classId = durableAcademic ? '' : canonicalClassId(input.classId);
    let subjectId = String(input.subjectId ?? '').trim();
    let academicYear = String(input.academicYear ?? input.academicYearId ?? '').trim();
    let term = String(input.term ?? input.termId ?? '').trim();
    let sampleActor = actor;
    if (durableAcademic) {
      const context = await durableAcademic.sampleMockScoreContext(input, actor);
      classId = canonicalClassId(context.class.name);
      academicYear ||= context.academicYearId;
      term ||= context.termId;
      if (!classId || !['JHS 1', 'JHS 2', 'JHS 3'].includes(classId)) throw new Error('Mock examinations are available for JHS 1, JHS 2, and JHS 3 only.');
      const remappedActor = actor.roleKey === 'TEACHER'
        ? { ...actor, assignedClassIds: (actor.assignedClassIds ?? []).map((id) => String(id) === String(context.class.id) ? classId : id) }
        : actor;
      const matches = subjects.list({ classId }, remappedActor).filter((subject) =>
        String(subject.name).trim().toLocaleLowerCase('en') === String(context.subject.name).trim().toLocaleLowerCase('en')
        && subject.active !== false && subject.isScoring !== false && Number(subject.isScoring) !== 0
      );
      if (matches.length !== 1) throw new Error('Selected subject is not uniquely configured for the sample class.');
      const sampleSubject = matches[0];
      subjectId = sampleSubject.id;
      sampleActor = actor.roleKey === 'TEACHER'
        ? { ...remappedActor, assignedSubjectIds: (actor.assignedSubjectIds ?? []).map((id) => String(id) === String(context.subject.id) ? sampleSubject.id : id) }
        : remappedActor;
    } else {
      if (!classId || !['JHS 1', 'JHS 2', 'JHS 3'].includes(classId)) throw new Error('Mock examinations are available for JHS 1, JHS 2, and JHS 3 only.');
      if (subjectId) {
        const subject = subjects.list({ classId }, actor).find((item) => String(item.id) === subjectId && item.active !== false && item.isScoring !== false && Number(item.isScoring) !== 0);
        if (!subject) throw new Error('Subject is invalid for this class and academic context.');
      }
    }
    students.seedSampleStudents?.();
    return { input: { ...input, classId, subjectId, academicYear, term, sampleMode: true }, actor: sampleActor };
  }
  transcripts ??= createTranscriptService({ students, academicResults, signatures, schoolProfile: branding });
  communicationEngine ??= createCommunicationEngine({ audit, schoolId: serviceSchoolId });
  shepActivities ??= createShepActivitiesService({ students, staff });
  receiptBranding ??= createReceiptBrandingService({ fees, students, schoolId: serviceSchoolId });
  const parentHistoricalRecords = database?.query ? createParentHistoricalRecordsService({ database }) : null;
  const attendanceRegister = createAttendanceRegisterService({ database, students, attendance, attendanceRepository, sampleFixtureRepository, schoolSettings });
  const parentDashboard = createParentDashboardService({ students, admissionEnrollment, attendance, attendanceRepository, sampleFixtureRepository, academicResults, resultBlocking, durableAcademic, fees, parentFeeObligations, durableFeeReader, receiptBranding, examinations, historicalRecords: parentHistoricalRecords, communication, durableAnnouncements, academicCalendar, operations, assignments, testParentSchoolId: serviceSchoolId });
  async function parentStudentsForRequest(actor) {
    const linked = await parentDashboard.listChildren(actor);
    const settled = await Promise.allSettled(linked.map((child) => parentDashboard.resolveChild(actor, child.permanentStudentId)));
    return settled.filter((item) => item.status === 'fulfilled').map((item) => item.value).filter(Boolean);
  }
  function parentAuthorizedStaffIds(actor, children) {
    if (actor.portal !== 'parent') return actor.authorizedStaffIds ?? [];
    const childClasses = new Set(children.map((child) => child.classId).filter(Boolean));
    const activeStaff = new Set(staff.listProfiles().filter((member) => member.schoolId === actor.schoolId && member.employmentStatus === 'ACTIVE').map((member) => member.id));
    return [...new Set((staff.assignments?.() ?? []).filter((assignment) => assignment.schoolId === actor.schoolId && childClasses.has(assignment.classId) && activeStaff.has(assignment.staffId)).map((assignment) => assignment.staffId))];
  }
  financialIntelligence ??= createFinancialIntelligenceService({ fees });
  academicAttendanceIntelligence ??= createAcademicAttendanceIntelligence({ academicResults, attendance, students, subjects, staff });
  admissionsWorkforceIntelligence ??= createAdmissionsWorkforceIntelligence({ admissions: admissionForms, staff, attendance });
  if (!operationalIntelligence) { const operationalRegistry = createOperationalAnalyticsRegistry({ modules: SIDEBAR_MODULES }); registerBuiltInOperationalProviders(operationalRegistry, { operations, resources, communication }); operationalIntelligence = createOperationalIntelligence({ registry: operationalRegistry }); }
  schoolKnowledgeIntelligence ??= createSchoolKnowledgeIntelligence();
  executiveIntelligence ??= createExecutiveIntelligence({ capabilities: createExecutiveCapabilityAdapters({ financialIntelligence, academicAttendanceIntelligence, admissionsWorkforceIntelligence, operationalIntelligence, schoolKnowledgeIntelligence }), revisionSources: [fees, academicResults, attendance], auditLogger: aiAuditLogger });
  humanControlledActions ??= createHumanControlledActions({ store: persistence.actionStore, adapters: createAIActionAdapters({ communication, reporting, reportingFeeds: { students, attendance, examinations, fees } }), auditLogger: aiAuditLogger });
  const aiRuntimeEnabled = aiEnabled ?? (String(process.env.OSAAH_AI_ENABLED ?? 'true').toLowerCase() !== 'false');
  const aiAdministration = createAIAdministration({ enabled: aiRuntimeEnabled, providerRegistry, providerId, modelId, capabilityRegistry, toolRegistry, auditLogger: aiAuditLogger, components: { gateway: aiGateway ? 'HEALTHY' : 'DEGRADED', orchestrator: aiConversation ? 'HEALTHY' : 'DEGRADED', productionDataGuard: 'HEALTHY', dataQualityGuard: 'HEALTHY', schoolContext: 'HEALTHY', humanControlledActions } });
  receiptBranding.validateAssets().catch((error) => console.error(`Receipt branding validation failed: ${error.message}`));
  function dispatchAttendanceNotification(record, { correction = false } = {}) {
    if (!['PRESENT', 'ABSENT'].includes(record.status)) return;
    const links = students.parentLinksFor?.(record.studentId, record.schoolId) ?? [];
    const verb = record.status === 'PRESENT' ? 'is present' : 'is absent';
    for (const link of links) {
      const body = `Dear Parent, your child, ${link.studentName} with Permanent Student ID ${link.permanentStudentId} ${verb} today.`;
      const idempotencyKey = `${record.schoolId}+${link.permanentStudentId}+${record.date}+${record.status}+ATTENDANCE`;
      if (link.telephone) { const queued = communicationEngine.enqueue({ channel: 'SMS', recipient: link.telephone, payload: { body, category: 'ATTENDANCE', correction }, idempotencyKey }, { id: 'attendance-system', schoolId: record.schoolId }); communicationEngine.process(queued.id, { id: 'attendance-system', schoolId: record.schoolId }).catch(() => {}); }
      communication.notify({ type: 'ATTENDANCE', category: 'ATTENDANCE', recipientId: link.parentId, studentId: link.studentId, permanentStudentId: link.permanentStudentId, studentName: link.studentName, classId: link.classId, title: record.status === 'PRESENT' ? 'Attendance: Present' : 'Attendance: Absent', body }, { userId: 'attendance-system' });
      audit(createAuditLog({ schoolId: record.schoolId, userId: 'attendance-system', action: correction ? 'ATTENDANCE_NOTIFICATION_CORRECTION_QUEUED' : 'ATTENDANCE_NOTIFICATION_QUEUED', entity: 'StudentAttendance', entityId: record.id, newValue: { permanentStudentId: link.permanentStudentId, attendanceDate: record.date, attendanceStatus: record.status, idempotencyKey } }));
    }
  }
  function dispatchParentMessage({ studentId, category, title, body, idempotencyKey, amount = null, balance = null }) {
    const links = students.parentLinksFor?.(studentId, userSchoolId(studentId)) ?? [];
    for (const link of links) {
      const key = `${idempotencyKey}+${link.parentId}`;
      if (link.telephone) { const queued = communicationEngine.enqueue({ channel: 'SMS', recipient: link.telephone, payload: { body, category, amount, balance }, idempotencyKey: key }, { id: 'communication-system', schoolId: link.schoolId ?? serviceSchoolId }); communicationEngine.process(queued.id, { id: 'communication-system', schoolId: link.schoolId ?? serviceSchoolId }).catch(() => {}); }
      communication.notify({ type: category, category, recipientId: link.parentId, studentId: link.studentId, permanentStudentId: link.permanentStudentId, studentName: link.studentName, classId: link.classId, title, body }, { userId: 'communication-system' });
    }
  }
  function userSchoolId(studentId) { return students.getStudent(studentId, { requestedSchoolId: serviceSchoolId })?.schoolId ?? serviceSchoolId; }
  function dispatchPaymentNotification(payment) { const student = students.getStudent(payment.studentId, { requestedSchoolId: payment.schoolId }); if (!student) return; const body = `Dear Parent, we have received GHS ${Number(payment.amount).toFixed(2)} for ${[student.firstName, student.middleName, student.surname].filter(Boolean).join(' ')}, Permanent Student ID ${student.permanentStudentId}. Outstanding balance: GHS ${Number(payment.balance).toFixed(2)}. Thank you.`; dispatchParentMessage({ studentId: student.id, category: 'FEES_PAID', title: 'Payment received', body, amount: payment.amount, balance: payment.balance, idempotencyKey: `PAYMENT:${payment.receiptNumber}` }); }
  function dispatchAdmissionNotification(student) { const body = `Dear Parent, the admission of ${[student.firstName, student.middleName, student.surname].filter(Boolean).join(' ')} into ${branding.schoolName} has been accepted. Permanent Student ID: ${student.permanentStudentId}. Please log in to the Parent Portal or contact the school for the next steps.`; dispatchParentMessage({ studentId: student.id, category: 'ADMISSION_ACCEPTED', title: 'Admission accepted', body, idempotencyKey: `ADMISSION_ACCEPTED:${student.permanentStudentId}` }); }
  function dispatchClassNotification(classId, category, title, body, idempotencyKey) { students.listStudents({ requestedSchoolId: serviceSchoolId }).filter((student) => student.classId === classId).forEach((student) => dispatchParentMessage({ studentId: student.id, category, title, body: body(student), idempotencyKey: `${idempotencyKey}:${student.permanentStudentId}` })); }
  function announcementRecipients(body, actor) { const allowed = ['PROPRIETOR', 'SCHOOL_ADMIN', 'HEADTEACHER'].includes(actor.roleKey) && actor.schoolId === serviceSchoolId; if (!allowed) throw Object.assign(new Error('Announcement authorization required.'), { status: 403 }); const studentsInScope = students.listStudents({ requestedSchoolId: actor.schoolId }).filter((student) => (!body.studentIds?.length || body.studentIds.includes(student.id)) && (!body.classIds?.length || body.classIds.includes(student.classId))); const links = studentsInScope.flatMap((student) => students.parentLinksFor(student.id, actor.schoolId)).filter((link, index, rows) => (!body.parentIds?.length || body.parentIds.includes(link.parentId)) && rows.findIndex((other) => other.parentId === link.parentId && other.studentId === link.studentId) === index); return links; }
  function announcementPreview(body, actor) { const links = announcementRecipients(body, actor); const valid = links.filter((link) => link.telephone); return { intendedRecipients: links.length, validPhoneNumbers: valid.length, invalidOrMissingPhoneNumbers: links.length - valid.length, estimatedSmsCount: body.channel === 'IN_APP' ? 0 : valid.length, recipients: links.map((link) => ({ parentId: link.parentId, studentId: link.studentId, permanentStudentId: link.permanentStudentId, studentName: link.studentName, hasPhone: Boolean(link.telephone) })) }; }
  function dispatchAnnouncement(body, actor) { if (body.confirm !== true) throw Object.assign(new Error('Explicit bulk-send confirmation is required.'), { status: 400 }); const links = announcementRecipients(body, actor); const emergency = Boolean(body.emergency); const title = emergency ? 'Emergency notice' : String(body.title ?? 'School announcement'); const message = emergency ? `URGENT — ${branding.schoolName}: ${String(body.message ?? '').trim()}` : String(body.message ?? '').trim(); if (!message) throw new Error('Announcement message is required.'); links.forEach((link) => { const key = `ANNOUNCEMENT:${body.idempotencyKey ?? `${title}:${message}`}:${link.parentId}:${link.permanentStudentId}`; if (body.channel !== 'SMS') communication.notify({ type: emergency ? 'EMERGENCY' : 'ANNOUNCEMENT', category: emergency ? 'EMERGENCY' : 'ANNOUNCEMENT', recipientId: link.parentId, studentId: link.studentId, permanentStudentId: link.permanentStudentId, studentName: link.studentName, title, body: message }, { userId: actor.id }); if (body.channel !== 'IN_APP' && link.telephone) { const queued = communicationEngine.enqueue({ channel: 'SMS', recipient: link.telephone, payload: { body: message, priority: emergency ? 'HIGH' : 'NORMAL' }, idempotencyKey: key }, { id: actor.id, schoolId: actor.schoolId }); communicationEngine.process(queued.id, actor).catch(() => {}); } }); return { queuedRecipients: links.length, channel: body.channel ?? 'BOTH', emergency, confirmed: true }; }
  return async function handle(request, response) {
    const pathname = new URL(request.url, 'http://localhost').pathname;
    if (['/admissions', '/admissions/apply', '/admission-application.html', '/admissions.html'].includes(pathname)) {
      response.writeHead(308, { Location: '/admissions/register', 'Cache-Control': 'no-store' });
      return response.end();
    }
    const legacyAdmissionWrite = (pathname === '/api/admission-applications' && request.method === 'POST')
      || (pathname.startsWith('/api/admission-applications/') && (['POST', 'PUT', 'PATCH', 'DELETE'].includes(request.method) || /\/(update|submit|review|enroll|offer-acceptance|documents)(\/|$)/.test(pathname)))
      || (pathname === '/api/public/admission-workflow/options' && request.method !== 'GET')
      || (pathname === '/api/students' && request.method === 'POST')
      || (pathname === '/api/students/link-existing' && request.method === 'POST')
      || (pathname.startsWith('/api/admissions') && request.method !== 'GET');
    if (legacyAdmissionWrite) return json(response, { error: 'This admission workflow has been retired. Use /admissions/register.', code: 'LEGACY_ADMISSION_WORKFLOW_RETIRED', registrationUrl: '/admissions/register' }, 410);
    if (pathname === '/api/health' && request.method === 'GET') {
      const startedAt = Date.now();
      const health = await checkAuthenticationDatabaseHealth(database);
      if (health.db === 'down') console.error('Authentication health check failed', { component: 'application_database', operation: 'health_check', code: health.databaseErrorCode ?? 'DATABASE_ADAPTER_UNAVAILABLE' });
      if (health.sessionStore === 'down') console.error('Authentication health check failed', { component: 'application_database', operation: 'session_store_check', code: health.sessionErrorCode ?? 'UNKNOWN' });
      const { databaseErrorCode, sessionErrorCode, ...publicHealth } = health;
      const result = { ok: health.db === 'up' && health.sessionStore === 'up', ...publicHealth, latencyMs: Date.now() - startedAt };
      return json(response, result, result.ok ? 200 : 503);
    }
    if (pathname.startsWith('/assets/')) {
      const assetRoot = resolve(root);
      const assetFile = resolve(assetRoot, `.${pathname}`);
      const assetRelativePath = relative(assetRoot, assetFile);
      if (assetRelativePath.startsWith('..') || assetRelativePath.includes(':')) { response.writeHead(403); return response.end('Forbidden'); }
      try {
        const body = await readFile(assetFile);
        response.writeHead(200, { 'Content-Type': mime[extname(assetFile)] ?? 'application/octet-stream', 'Cache-Control': 'public, max-age=31536000, immutable' });
        return response.end(body);
      } catch {
        response.writeHead(404); return response.end('Not found');
      }
    }
    if (pathname === '/api/release' && request.method === 'GET') return json(response, releaseMetadata);
    if (pathname === '/api/branding') return json(response, branding);
    const publicProspectusActor = { id: 'public-parent', portal: 'parent', schoolId: serviceSchoolId, permissions: new Set() };
    if (pathname === '/api/public/admission-prospectus/options' && request.method === 'GET') return json(response, admissionProspectus.listOptions());
    if (pathname === '/api/public/admission-prospectus' && request.method === 'GET') return json(response, { prospectuses: admissionProspectus.list(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), publicProspectusActor) });
    if (pathname.startsWith('/api/public/admission-prospectus/') && pathname.endsWith('/pdf') && request.method === 'GET') { const id = pathname.split('/').filter(Boolean)[3]; const prospectus = admissionProspectus.get(id, publicProspectusActor); if (!prospectus) return json(response, { error: 'Published prospectus not found.' }, 404); try { const body = await prospectusPdf.pdf(prospectus); response.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${safeProspectusFilename(prospectus)}"`, 'Cache-Control': 'public, max-age=300' }); return response.end(body); } catch { return json(response, { error: 'Prospectus PDF is temporarily unavailable.' }, 500); } }
    if (pathname === '/api/auth/login' && request.method === 'POST') return login(request, response, auth, audit);
    if (pathname === '/api/auth/logout' && request.method === 'POST') { await auth.logoutSession(readCookie(request, 'osaah_session')); return json(response, { ok: true }, 204, `osaah_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secureCookieSuffix(request)}`); }
    if (pathname === '/api/auth/proprietor/login' && request.method === 'POST') {
      if (!proprietorAuthentication) return json(response, { error: 'Authentication service unavailable.' }, 500);
      try {
        const result = await proprietorAuthentication(await readJson(request));
        if (result.status === 200) audit(createAuditLog({ userId: result.body.user.id, roleId: result.body.user.role, action: 'DATABASE_LOGIN_SUCCESS', entity: 'Authentication' }));
        return json(response, result.body, result.status);
      } catch {
        return json(response, { error: 'Authentication service unavailable.' }, 500);
      }
    }
    if (pathname === '/api/auth/session' && request.method === 'GET') {
      const sessionToken = readCookie(request, 'osaah_session');
      const bearerToken = sessionToken ? null : bearer(request);
      const authContext = sessionDiagnosticContext(request, pathname, sessionToken ?? bearerToken, sessionToken ? 'cookie' : bearerToken ? 'bearer' : 'unknown');
      const user = await auth.authenticateAsync(sessionToken ?? bearerToken, authContext);
      if (process.env.OSAAH_AUTH_SESSION_DIAGNOSTICS === '1') console.info('Authentication session diagnostic', { requestId: authContext.requestId, requestPath: pathname, stage: 'session_endpoint_result', authenticated: Boolean(user), roleKey: user?.roleKey === 'PROPRIETOR' ? 'PROPRIETOR' : user ? 'OTHER' : null });
      return user ? json(response, { user: publicUser(user), redirectTo: user.dashboard }) : json(response, { error: 'Authentication required.' }, 401);
    }
    if (pathname === '/api/auth/change-password' && request.method === 'POST') {
      const token = readCookie(request, 'osaah_session') ?? bearer(request);
      const user = await auth.authenticateAsync(token);
      if (!user) return json(response, { error: 'Authentication required.' }, 401);
      try {
        const result = await auth.changeOwnPassword(user, await readJson(request), token);
        audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'PASSWORD_CHANGED', entity: 'User', entityId: user.id }));
        return json(response, result, 200, `osaah_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secureCookieSuffix(request)}`);
      } catch (error) {
        return json(response, { error: error.message, code: error.code ?? 'PASSWORD_CHANGE_FAILED' }, error.status ?? 400);
      }
    }
    if (pathname === '/api/auth/password-reset' && request.method === 'POST') { const body = await readJson(request); return json(response, auth.requestPasswordReset(body.username ?? '')); }
    if (pathname === '/api/auth/password-reset/complete' && request.method === 'POST') { const body = await readJson(request); const result = auth.completePasswordReset(body.token ?? '', body.newPassword ?? ''); return json(response, result, result.ok ? 200 : 400); }
    if (pathname === '/api/documents/verify' && request.method === 'GET') return json(response, compliance.verifyDocument(new URL(request.url, 'http://localhost').searchParams.get('code') ?? ''));
    if (pathname === '/api/privacy/notice' && request.method === 'GET') return json(response, compliance.privacyNotice());
    if (pathname === '/api/official-documents/verify' && request.method === 'GET') return json(response, reporting.verifyOfficialDocument(new URL(request.url, 'http://localhost').searchParams.get('code') ?? ''));
    const guestAdmissionSession = readCookie(request, 'osaah_admission_session');
    const publicAdmissionActor = guestAdmissionSession ? { id: guestAdmissionSession, portal: 'parent', schoolId: serviceSchoolId } : null;
    if (pathname === '/api/public/admission-workflow/options' && request.method === 'GET') {
      const classes = CORE_LEVELS.map((name, displayOrder) => ({ id: name, name: name.replace(/^Primary /, 'Basic ').replace(/^KG([12])$/, 'KG $1'), displayOrder }));
      const academicYears = ACADEMIC_YEAR_OPTIONS.map((name) => ({ id: name, name, admissionYear: String(name).match(/^\d{4}/)?.[0] ?? null }));
      const terms = TERM_OPTIONS.map((name) => ({ id: name, name, academicYearId: null }));
      return json(response, { classes, academicYears, terms, documentStorageAvailable: Boolean(admissionDocumentStorage) });
    }
    if (pathname === '/api/admission-applications' && request.method === 'GET' && publicAdmissionActor) {
      const filters = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams);
      const applications = admissionForms.listApplications(filters, publicAdmissionActor);
      return json(response, { applications: applications.map(presentAdmissionApplication) });
    }
    if (pathname.startsWith('/api/admission-applications/') && pathname.split('/').filter(Boolean).length === 3 && request.method === 'GET' && publicAdmissionActor) {
      const id = pathname.split('/')[3];
      const result = admissionForms.getApplication(id, publicAdmissionActor);
      return result ? json(response, presentAdmissionApplication(result)) : json(response, { error: 'Not found.' }, 404);
    }
    if (pathname === '/api/admission-fees/quote' && request.method === 'GET' && publicAdmissionActor) { const query = new URL(request.url, 'http://localhost').searchParams; const fee = admissionForms.activeFeeFor(query.get('classAppliedFor'), query.get('academicYear'), query.get('term')); return fee ? json(response, { fee }) : json(response, { error: 'No published fee structure found.' }, 404); }
    if (pathname === '/api/admission-applications' && request.method === 'POST' && publicAdmissionActor) { try { const result = admissionForms.createApplication(await readJson(request), publicAdmissionActor); audit(createAuditLog({ schoolId: publicAdmissionActor.schoolId, userId: publicAdmissionActor.id, action: 'ADMISSION_APPLICATION_CREATED', entity: 'AdmissionFormApplication', entityId: result.applicationNumber, newValue: result })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, 400); } }
    if (pathname.startsWith('/api/admission-applications/') && pathname.endsWith('/update') && request.method === 'PATCH' && publicAdmissionActor) { try { const result = admissionForms.updateApplication(pathname.split('/')[3], await readJson(request), publicAdmissionActor); return json(response, result); } catch (error) { return json(response, { error: error.message }, 400); } }
    if (pathname.startsWith('/api/admission-applications/') && pathname.endsWith('/documents') && request.method === 'POST' && publicAdmissionActor) { try { const result = admissionForms.attachDocument(pathname.split('/')[3], await readJson(request), publicAdmissionActor); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, 400); } }
    if (pathname.startsWith('/api/admission-applications/') && pathname.endsWith('/submit') && request.method === 'POST' && publicAdmissionActor) { try { const id = pathname.split('/')[3]; const body = await readJson(request); const result = admissionForms.submitApplication(id, publicAdmissionActor, admissionForms.activeFeeFor(body.classAppliedFor ?? admissionForms.getApplication(id, publicAdmissionActor)?.section1.classAppliedFor, body.academicYear, body.term)); audit(createAuditLog({ schoolId: publicAdmissionActor.schoolId, userId: publicAdmissionActor.id, action: 'ADMISSION_APPLICATION_SUBMITTED', entity: 'AdmissionFormApplication', entityId: id })); return json(response, result); } catch (error) { return json(response, { error: error.message }, 400); } }
    if (pathname.startsWith('/api/')) {
      if (durableAnnouncements && pathname === '/api/communication/announcements/publish-due' && request.method === 'POST') {
        if (!process.env.OSAAH_ANNOUNCEMENT_CRON_SECRET || request.headers['x-osaah-scheduler-secret'] !== process.env.OSAAH_ANNOUNCEMENT_CRON_SECRET) return json(response, { error: 'Forbidden.' }, 403);
        try { return json(response, await durableAnnouncements.publishDue({ id: 'scheduler', schoolId: serviceSchoolId })); } catch (error) { return json(response, { error: error.message }, error.status ?? 500); }
      }
      let apiActor = null;
      try {
      const user = await auth.authenticateAsync(readCookie(request, 'osaah_session') ?? bearer(request));
      apiActor = user;
      if (pathname.startsWith('/api/attendance/') && !user) return attendanceApiFailure(response, Object.assign(new Error('Authentication required.'), { status: 401, code: 'ATTENDANCE_AUTH_REQUIRED' }), pathname, null);
      if (database?.query && pathname.startsWith('/api/administrators/') && pathname.endsWith('/reset-credentials') && request.method === 'POST') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401);
        if (user.roleKey !== 'PROPRIETOR') return json(response, { error: 'Forbidden.' }, 403);
        return json(response, { error: 'Use the durable Administrator Management password-reset form.' }, 410);
      }
      if (user) {
        try { resolveCurrentSchoolContext(user); }
        catch (error) { return json(response, { error: error.message, code: error.code }, error.status ?? 403); }
      }
      if (pathname === '/api/admin/verify-role-provisioning') {
        if (request.method !== 'GET') return json(response, { error: 'Method not allowed.' }, 405);
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401);
        if (user.portal !== 'school' || user.roleKey !== 'PROPRIETOR') return json(response, { error: 'Forbidden.' }, 403);
        try {
          const accounts = await roleProvisioningDiagnostic.inspect(user.schoolId);
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'ROLE_PROVISIONING_DIAGNOSTIC', entity: 'RoleProvisioningDiagnostic', newValue: { accountCount: accounts.length } }));
          return json(response, { accounts }, 200);
        } catch {
          return json(response, { error: 'Role provisioning diagnostic is unavailable.', code: 'DIAGNOSTIC_UNAVAILABLE' }, 503);
        }
      }
      if (pathname === '/api/admin/provision-role-accounts') {
        if (request.method !== 'POST') return json(response, { error: 'Method not allowed.' }, 405);
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401);
        if (user.portal !== 'school' || user.roleKey !== 'PROPRIETOR') return json(response, { error: 'Forbidden.' }, 403);
        const origin = String(request.headers.origin ?? '');
        let sameOrigin = false;
        try { sameOrigin = Boolean(origin && request.headers.host && new URL(origin).host.toLowerCase() === String(request.headers.host).toLowerCase()); } catch {}
        if (!sameOrigin) return json(response, { error: 'Same-origin request required.' }, 403);
        if (!durableRoleAccountProvisioning) return json(response, { error: 'Durable role provisioning is unavailable.', code: 'PERSISTENCE_UNAVAILABLE' }, 503);
        try {
          const accounts = await durableRoleAccountProvisioning.provision(user.schoolId);
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'ROLE_ACCOUNTS_PROVISIONED', entity: 'RoleAccountProvisioning', newValue: { accountCount: accounts.length, roleKeys: accounts.map((account) => account.role) } }));
          return json(response, { accounts, credentialsShownOnce: true }, 200);
        } catch (error) {
          const code = /^[A-Z0-9_]+$/.test(String(error?.code ?? '')) ? error.code : 'ROLE_ACCOUNT_PROVISIONING_FAILED';
          if (error?.committed) audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'ROLE_ACCOUNTS_PROVISIONED_VERIFICATION_FAILED', entity: 'RoleAccountProvisioning', newValue: { role: error?.details?.role ?? null, code } }));
          return json(response, { error: error?.message ?? 'Role account provisioning failed safely.', code, ...(error?.details ? { details: error.details } : {}) }, error?.status ?? 409);
        }
      }
      if (pathname === '/api/fees/obligations/publish' && request.method === 'POST') { if (!user) return json(response,{error:'UNAUTHENTICATED'},401); if (!feeCollections) return json(response,{error:'PERSISTENCE_UNAVAILABLE'},503); if (!canAccess(user,'fees.write')) return json(response,{error:'Forbidden.'},403); try { const body=await readJson(request); if (body.students || body.studentRows || body.studentIds) return json(response,{error:'Student lists are not accepted.'},400); const customFeeTypeName=String(body.customFeeTypeName??'').trim(); if (body.feeStructureId==='OTHER' && !customFeeTypeName) return json(response,{error:'Specify Fee Type is required when Other is selected.'},400); const input={scope:body.scope,feeStructureId:body.feeStructureId, classId:body.scope==='SPECIFIC_CLASS'?body.classId:null, academicYearId:body.academicYearId??body.academicYear, termId:body.termId??body.term, amountMinor:body.amountMinor, customFeeTypeName:customFeeTypeName||null}; if (customFeeTypeName && database?.execute) { try { await database.execute('UPDATE fee_structures SET custom_fee_type_name=? WHERE id=? AND school_id=?',[customFeeTypeName,input.feeStructureId,user.schoolId]); } catch {} } const result=await feeCollections.publishFeeObligations(input, user); students.listStudents({ requestedSchoolId:user.schoolId }).filter((student)=>!input.classId||student.classId===input.classId).forEach((student)=>dispatchParentMessage({studentId:student.id,category:'FEE_PUBLISHED',title:'Fee published',body:'A fee of GHS '+(Number(input.amountMinor||0)/100).toFixed(2)+' has been published for '+[student.firstName,student.middleName,student.surname].filter(Boolean).join(' ')+', Permanent Student ID '+student.permanentStudentId+'.',idempotencyKey:'FEE_PUBLISHED:'+result.created_count+':'+student.permanentStudentId})); return json(response,{scope:body.scope,eligible_count:result.eligible_count,created_count:result.created_count,skipped_count:result.skipped_count,classId:input.classId??null,academicYear:input.academicYearId??null,term:input.termId??null,customFeeTypeName:customFeeTypeName||null}); } catch(error){ const safe=safeFeeError(error,400); return json(response,safe.body,safe.status); } }
      if (pathname === '/api/parent/fee-obligations' && request.method === 'GET') { if (!user) return json(response,{error:'UNAUTHENTICATED'},401); if (!parentFeeObligations) return json(response,{error:'PERSISTENCE_UNAVAILABLE'},503); try { return json(response,await parentFeeObligations.listForParent(user,Object.fromEntries(new URL(request.url,'http://localhost').searchParams))); } catch(error){ const safe=safeFeeError(error); return json(response,safe.body,safe.status); } }
      if (pathname === '/api/fees/obligations' && request.method === 'GET') { if (!user) return json(response,{error:'UNAUTHENTICATED'},401); if (!feeCollections) return json(response,{error:'PERSISTENCE_UNAVAILABLE'},503); try { return json(response,await feeCollections.listFeeObligations(Object.fromEntries(new URL(request.url,'http://localhost').searchParams),user)); } catch(error){ const safe=safeFeeError(error); return json(response,safe.body,safe.status); } }
      if (pathname.startsWith('/api/fees/obligations/') && request.method === 'GET') { if (!user) return json(response,{error:'UNAUTHENTICATED'},401); if (!feeCollections) return json(response,{error:'PERSISTENCE_UNAVAILABLE'},503); try { const id=pathname.split('/').pop(); const row=await feeCollections.getFeeObligation(id,user); return row?json(response,row):json(response,{error:'Not found.'},404); } catch(error){ const safe=safeFeeError(error); return json(response,safe.body,safe.status); } }
      if (pathname.startsWith('/api/fees/collections/') && pathname !== '/api/fees/collections/reports' && request.method === 'GET') { if (!user) return json(response,{error:'UNAUTHENTICATED'},401); if (!feeCollections) return json(response,{error:'PERSISTENCE_UNAVAILABLE'},503); try { const row=await feeCollections.getCollectionById(pathname.split('/').pop(),user); return row?json(response,row):json(response,{error:'Not found.'},404); } catch(error){ const safe=safeFeeError(error); return json(response,safe.body,safe.status); } } if (pathname.startsWith('/api/fees/collections/') && request.method === 'PATCH') { if (!user) return json(response,{error:'UNAUTHENTICATED'},401); if (!feeCollections) return json(response,{error:'PERSISTENCE_UNAVAILABLE'},503); try { const body=await readJson(request); const allowed=new Set(['amount_received_minor','reason']); if (Object.keys(body).some((key)=>!allowed.has(key))) return json(response,{error:'Unsupported correction field.'},400); return json(response,await feeCollections.correctCollection(pathname.split('/').pop(),{amountReceivedMinor:body.amount_received_minor,reason:body.reason},user)); } catch(error){ const safe=safeFeeError(error,400); return json(response,safe.body,safe.status); } } if (pathname === '/api/fees/collections' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (!feeCollections) return json(response, { error: 'PERSISTENCE_UNAVAILABLE' }, 503); try { const body=await readJson(request); const created=await feeCollections.createCollection(body,user); communication.notify({type:'FEE_COLLECTION',category:'FINANCE',recipientId:user.id,title:'Collection recorded',body:body.collectionType+' collection of GHS '+(Number(body.amountReceivedMinor||0)/100).toFixed(2)+' was recorded for '+(body.classId||'school')+' on '+body.collectionDate+'.',classId:body.classId}, {userId:user.id}); return json(response, created, 201); } catch (error) { const safe=safeFeeError(error,400); return json(response,safe.body,safe.status); } }
      if (pathname === '/api/fees/collections' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (!feeCollections) return json(response, { error: 'PERSISTENCE_UNAVAILABLE' }, 503); try { return json(response, await feeCollections.listCollections(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user)); } catch (error) { const safe=safeFeeError(error); return json(response,safe.body,safe.status); } }
      if (pathname === '/api/fees/collections/reports' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (!feeCollections) return json(response, { error: 'PERSISTENCE_UNAVAILABLE' }, 503); try { return json(response, await feeCollections.aggregateCollections(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user)); } catch (error) { const safe=safeFeeError(error); return json(response,safe.body,safe.status); } }
      if (pathname === '/api/finance/budgets' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (!budgets) return json(response, { error: 'PERSISTENCE_UNAVAILABLE' }, 503); try { return json(response, { budgets: await budgets.list(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user), categories: budgets.categories(), statuses: budgets.statuses() }); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'BUDGET_LIST_FAILED' }, error.status ?? 400); } }
      if (pathname === '/api/finance/budgets' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (!budgets) return json(response, { error: 'PERSISTENCE_UNAVAILABLE' }, 503); try { return json(response, await budgets.create(await readJson(request), user), 201); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'BUDGET_CREATE_FAILED' }, error.status ?? 400); } }
      if (pathname.startsWith('/api/finance/budgets/') && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (!budgets) return json(response, { error: 'PERSISTENCE_UNAVAILABLE' }, 503); try { const item = await budgets.get(pathname.split('/')[4], user); return item ? json(response, item) : json(response, { error: 'Budget not found.' }, 404); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'BUDGET_READ_FAILED' }, error.status ?? 400); } }
      if (pathname.startsWith('/api/finance/budgets/') && request.method === 'PATCH' && !pathname.endsWith('/submit') && !pathname.endsWith('/approve') && !pathname.endsWith('/reject') && !pathname.endsWith('/close')) { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (!budgets) return json(response, { error: 'PERSISTENCE_UNAVAILABLE' }, 503); try { return json(response, await budgets.update(pathname.split('/')[4], await readJson(request), user)); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'BUDGET_UPDATE_FAILED' }, error.status ?? 400); } }
      if (pathname.startsWith('/api/finance/budgets/') && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (!budgets) return json(response, { error: 'PERSISTENCE_UNAVAILABLE' }, 503); const parts = pathname.split('/').filter(Boolean); const action = parts[4]; const target = { submit: 'SUBMITTED', approve: 'APPROVED', reject: 'DRAFT', close: 'CLOSED' }[action]; if (!target) return json(response, { error: 'Unknown budget action.' }, 404); try { return json(response, await budgets.transition(parts[3], target, user)); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'BUDGET_TRANSITION_FAILED' }, error.status ?? 400); } }
      if (generalFinance && pathname.startsWith('/api/finance/income') && request.method === 'GET' && pathname === '/api/finance/income') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); return json(response, { transactions: await generalFinance.income.list(query, user), categories: generalFinance.income.categories(), methods: generalFinance.income.methods(), statuses: generalFinance.income.statuses() }); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'INCOME_LIST_FAILED' }, error.status ?? 400); } }
      if (generalFinance && pathname === '/api/finance/income' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { return json(response, await generalFinance.income.create(await readJson(request), user), 201); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'INCOME_CREATE_FAILED' }, error.status ?? 400); } }
      if (generalFinance && pathname.startsWith('/api/finance/income/') && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const item = await generalFinance.income.get(pathname.split('/')[4], user); return item ? json(response, item) : json(response, { error: 'Income not found.' }, 404); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'INCOME_READ_FAILED' }, error.status ?? 400); } }
      if (generalFinance && pathname.startsWith('/api/finance/income/') && request.method === 'PATCH' && !pathname.endsWith('/void')) { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { return json(response, await generalFinance.income.update(pathname.split('/')[4], await readJson(request), user)); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'INCOME_UPDATE_FAILED' }, error.status ?? 400); } }
      if (generalFinance && pathname.startsWith('/api/finance/income/') && pathname.endsWith('/void') && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const body = await readJson(request); return json(response, await generalFinance.income.void(pathname.split('/')[4], body.reason, user)); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'INCOME_VOID_FAILED' }, error.status ?? 400); } }
      if (generalFinance && pathname === '/api/finance/expenses' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const budgetsForSchool = budgets ? await budgets.list({}, user) : []; return json(response, { transactions: await generalFinance.expenses.list(query, user), categories: generalFinance.expenses.categories(), methods: generalFinance.expenses.methods(), statuses: generalFinance.expenses.statuses(), budgets: budgetsForSchool }); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'EXPENSE_LIST_FAILED' }, error.status ?? 400); } }
      if (generalFinance && pathname === '/api/finance/expenses' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { return json(response, await generalFinance.expenses.create(await readJson(request), user), 201); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'EXPENSE_CREATE_FAILED' }, error.status ?? 400); } }
      if (generalFinance && pathname.startsWith('/api/finance/expenses/') && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const item = await generalFinance.expenses.get(pathname.split('/')[4], user); return item ? json(response, item) : json(response, { error: 'Expense not found.' }, 404); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'EXPENSE_READ_FAILED' }, error.status ?? 400); } }
      if (generalFinance && pathname.startsWith('/api/finance/expenses/') && request.method === 'PATCH' && !pathname.endsWith('/void')) { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { return json(response, await generalFinance.expenses.update(pathname.split('/')[4], await readJson(request), user)); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'EXPENSE_UPDATE_FAILED' }, error.status ?? 400); } }
      if (generalFinance && pathname.startsWith('/api/finance/expenses/') && pathname.endsWith('/void') && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const body = await readJson(request); return json(response, await generalFinance.expenses.void(pathname.split('/')[4], body.reason, user)); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'EXPENSE_VOID_FAILED' }, error.status ?? 400); } }
      if (cashbook && pathname === '/api/finance/cashbook' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const result = await cashbook.getCashbookEntries(query, user); if (query.format) return json(response, reporting.exportReport({ reportType:'CASHBOOK', title:'Cashbook', summary:result.summary, rows:result.entries }, query.format)); return json(response, result); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'CASHBOOK_READ_FAILED' }, error.status ?? 400); } }
      if (cashbook && pathname.startsWith('/api/finance/cashbook/') && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const parts = pathname.split('/').filter(Boolean); return json(response, await cashbook.getCashbookEntryDetails(parts[3], parts[4], user)); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'CASHBOOK_DETAIL_FAILED' }, error.status ?? 400); } }
      if (cashbook && pathname.startsWith('/api/finance/cashbook') && request.method !== 'GET') return json(response, { error: 'Cashbook is read-only. Modify the authoritative source transaction instead.' }, 405);
      if (pathname === '/api/ai/administration/health' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { return json(response, await aiAdministration.health({ actor: user })); } catch (error) { return json(response, { error: error.code ?? 'HEALTH_UNAVAILABLE', message: error.message }, error.status ?? 503); } }
      if (pathname === '/api/ai/actions' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const query = new URL(request.url, 'http://localhost').searchParams; return json(response, { actions: await humanControlledActions.list({ actor: user, status: query.get('status'), limit: query.get('limit'), offset: query.get('offset') }) }); } catch (error) { return json(response, { error: error.code ?? 'ACTION_UNAVAILABLE', message: error.message }, error.status ?? 400); } }
      if (pathname === '/api/ai/actions' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const action = await humanControlledActions.prepare({ ...(await readJson(request)), actor: user }); return json(response, { ...action, assistantMessage: 'Proposed action prepared. Review and approve before execution.' }, 201); } catch (error) { return json(response, { error: error.code ?? 'INVALID_ACTION', message: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/ai/actions/') && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const parts = pathname.split('/'), id = parts[4], operation = parts[5], body = await readJson(request); const method = humanControlledActions[operation]; if (!['submit', 'approve', 'reject', 'execute'].includes(operation) || typeof method !== 'function') return json(response, { error: 'INVALID_ACTION' }, 400); return json(response, await method({ ...body, id, actor: user })); } catch (error) { return json(response, { error: error.code ?? 'INVALID_ACTION', message: error.message }, error.status ?? 400); } }
      if (pathname === '/api/ai/executive-brief' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); try { const brief = await executiveIntelligence.brief({ actor: user }); await executiveIntelligence.refresh({ actor: user }); return json(response, brief); } catch (error) { return json(response, { error: error.code ?? 'EXECUTIVE_INTELLIGENCE_UNAVAILABLE', message: error.status ? error.message : 'Executive Intelligence is currently unavailable.' }, error.status ?? 503); } }
      if (pathname === '/api/ai/executive-feed' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); try { return json(response, { items: executiveIntelligence.feed({ actor: user }) }); } catch (error) { return json(response, { error: error.code ?? 'EXECUTIVE_INTELLIGENCE_UNAVAILABLE', message: error.message }, error.status ?? 503); } }
      if (pathname.startsWith('/api/ai/executive-feed/') && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); try { const parts = pathname.split('/'); const input = { actor: user, id: parts[4], humanInitiated: true }; if (parts[5] === 'acknowledge') return json(response, await executiveIntelligence.acknowledge(input)); if (parts[5] === 'resolve') return json(response, await executiveIntelligence.resolve(input)); return json(response, { error: 'INVALID_REQUEST' }, 400); } catch (error) { return json(response, { error: error.code ?? 'INVALID_REQUEST', message: error.message }, error.status ?? 400); } }
      if (pathname === '/api/ai/knowledge/search' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); try { syncRepositoryKnowledgeSources(schoolKnowledgeIntelligence, { actor: user, schoolProfile: { id: user.schoolId, name: branding.schoolName, location: branding.location, motto: branding.motto }, admissionProspectus, communication, reporting }); const query = new URL(request.url, 'http://localhost').searchParams.get('query'); return json(response, await schoolKnowledgeIntelligence.search({ actor: user, query })); } catch (error) { return json(response, { error: error.code ?? 'KNOWLEDGE_UNAVAILABLE', message: error.status ? error.message : 'School Knowledge Intelligence is currently unavailable.' }, error.status ?? 503); } }
      if (pathname === '/api/ai/operational-status' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); try { return json(response, await operationalIntelligence.dashboard({ actor: user })); } catch (error) { return json(response, { error: error.code ?? 'INTELLIGENCE_UNAVAILABLE', message: error.status === 403 ? error.message : 'Operational intelligence is currently unavailable.' }, error.status ?? 503); } }
      if (pathname === '/api/ai/admissions-workforce-status' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const result = await admissionsWorkforceIntelligence.dashboard({ ...query, actor: user }); if (!result.admissions && !result.workforce) return json(response, { error: 'PERMISSION_DENIED', message: 'Intelligence is unavailable for this role.' }, 403); return json(response, result); } catch (error) { return json(response, { error: error.code ?? 'INTELLIGENCE_UNAVAILABLE', message: error.status === 403 ? error.message : 'Admissions and workforce intelligence is currently unavailable.' }, error.status ?? 503); } }
      if (pathname === '/api/ai/academic-attendance-status' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); return json(response, await academicAttendanceIntelligence.dashboard({ ...query, actor: user })); } catch (error) { return json(response, { error: error.code ?? 'INTELLIGENCE_UNAVAILABLE', message: error.status === 403 ? error.message : 'Academic and attendance intelligence is currently unavailable.' }, error.status ?? 503); } }
      if (pathname === '/api/ai/financial-status' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); try { const query = new URL(request.url, 'http://localhost').searchParams; return json(response, await financialIntelligence.snapshot({ actor: user, academicYearId: query.get('academicYearId'), termId: query.get('termId'), classId: query.get('classId'), studentId: query.get('studentId') })); } catch (error) { return json(response, { error: error.code ?? 'FINANCIAL_DATA_UNAVAILABLE', message: error.status === 403 ? error.message : 'Financial intelligence is currently unavailable.' }, error.status ?? 503); } }
      if (pathname === '/api/ai/conversation/suggestions' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); if (!aiRuntimeEnabled || !aiConversation) return json(response, { error: 'AI_UNAVAILABLE', message: 'The OSAAH AI Assistant is unavailable.' }, 503); try { return json(response, { suggestions: aiConversation.suggestions(user) }); } catch (error) { return json(response, typeof error?.toJSON === 'function' ? error.toJSON() : { error: 'AI_REQUEST_FAILED', message: 'The OSAAH AI Assistant could not complete the request.' }, error?.status ?? 400); } }
      if (pathname === '/api/ai/conversation' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); if (!aiRuntimeEnabled || !aiConversation) return json(response, { error: 'AI_UNAVAILABLE', message: 'The OSAAH AI Assistant is unavailable.' }, 503); try { const body = await readJson(request); return json(response, await aiConversation.send({ authenticatedUser: user, message: body.message, conversationId: body.conversationId, history: body.history })); } catch (error) { return json(response, typeof error?.toJSON === 'function' ? error.toJSON() : { error: 'AI_REQUEST_FAILED', message: 'The OSAAH AI Assistant could not complete the request.' }, error?.status ?? 400); } }
      if (pathname === '/api/ai/conversation/reset' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED', message: 'Authentication is required.' }, 401); if (!aiConversation) return json(response, { error: 'AI_UNAVAILABLE', message: 'The OSAAH AI Assistant is unavailable.' }, 503); try { const body = await readJson(request); return json(response, aiConversation.reset({ authenticatedUser: user, conversationId: body.conversationId })); } catch (error) { return json(response, typeof error?.toJSON === 'function' ? error.toJSON() : { error: 'AI_REQUEST_FAILED', message: 'The OSAAH AI Assistant could not complete the request.' }, error?.status ?? 400); } }
      if (pathname === '/api/ai/gateway' && request.method === 'POST') {
        if (!aiRuntimeEnabled || !aiGateway) return json(response, { error: 'CAPABILITY_UNAVAILABLE', message: 'The AI Gateway is unavailable.' }, 503);
        try { return json(response, await aiGateway.execute({ ...await readJson(request), authenticatedUser: user })); }
        catch (error) { return json(response, typeof error?.toJSON === 'function' ? error.toJSON() : { error: 'INVALID_REQUEST', message: error.message }, error?.status ?? 400); }
      }
      if (pathname === '/api/sms/delivery-callback' && request.method === 'GET') { if (!smsService) return json(response, { error: 'Durable SMS service unavailable.' }, 503); try { const query = new URL(request.url, 'http://localhost').searchParams; return json(response, await smsService.deliveryCallback({ token: query.get('token'), smsId: query.get('sms_id'), status: query.get('status') })); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (!user) return json(response, { error: 'Authentication required.' }, 401);
      if (pathname.startsWith('/api/academic/sample/') && !sampleFixturesEnabled() && !PRODUCTION_SAFE_ACADEMIC_SAMPLE_ENDPOINTS.has(pathname)) return json(response, { error: 'Sample Result / Test Mode is disabled.' }, 403);
      const durableAcademicEndpoints = new Set(['/api/academic/options', '/api/academic/result-students', '/api/academic/score-entry/roster', '/api/academic/mock-scores/roster', '/api/academic/scores', '/api/academic/results/save', '/api/academic/results/saved', '/api/academic/results/publish', '/api/academic/mock-scores', '/api/academic/result/pdf', '/api/academic/mock-result/pdf', '/api/academic/sample/result/pdf', '/api/academic/result', '/api/academic/mock-result', '/api/parent/results']);
      if (process.env.NODE_ENV === 'production' && !durableAcademic && (durableAcademicEndpoints.has(pathname) || pathname.startsWith('/api/subjects/'))) return json(response, { error: 'Durable academic data is unavailable; apply the required migrations and restore database connectivity before retrying.' }, 503);
      if (process.env.NODE_ENV === 'production' && pathname.startsWith('/api/examinations/promotion') && !durablePromotion) return json(response, { error: 'Durable promotion data is unavailable; apply the required migration and restore database connectivity before retrying.' }, 503);
      if (pathname === '/api/sidebar') return json(response, { user: publicUser(user), portal: user.portal, categories: visibleSidebar({ permissions: user.permissions, roleKey: user.roleKey, portal: user.portal, schoolType: user.schoolType, subscription: user.subscription, entitlements: user.entitlements, featureAvailability: user.featureAvailability }), parentCards: user.portal === 'parent' ? parentDashboardModules() : [] });
      if (pathname === '/api/internal-student-registration/student-id' || pathname === '/api/internal-student-registration/existing-student' || pathname === '/api/internal-student-registration') {
        if (pathname !== '/api/internal-student-registration/student-id' && request.method !== 'POST') return json(response, { error: 'Method not allowed.' }, 405);
        if (pathname === '/api/internal-student-registration/student-id' && !['GET', 'POST'].includes(request.method)) return json(response, { error: 'Method not allowed.' }, 405);
        if (!user || user.portal !== 'school') return json(response, { error: user ? 'Forbidden.' : 'UNAUTHENTICATED' }, user ? 403 : 401);
        if (!canAccess(user, 'admissions.write')) return json(response, { error: 'Forbidden.' }, 403);
        if (!internalStudentRegistration) return json(response, { error: 'Internal student registration persistence is unavailable.', code: 'PERSISTENCE_UNAVAILABLE' }, 503);
        let requestBody = null;
        const suppliedRequestId = request.headers['x-vercel-id'] ?? request.headers['x-request-id'];
        const requestId = typeof suppliedRequestId === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(suppliedRequestId) ? suppliedRequestId : randomUUID();
        try {
          if (pathname === '/api/internal-student-registration/student-id') {
            const studentId = new URL(request.url, 'http://localhost').searchParams.get('studentId');
            if (request.method === 'GET') return json(response, await internalStudentRegistration.getRegisteredStudent({ studentId, schoolId: user.schoolId }));
            requestBody = await readJson(request);
            const result = await internalStudentRegistration.assignPermanentId({ studentId: requestBody.studentId, schoolId: user.schoolId, actorId: user.id });
            audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: result.created ? 'STUDENT_ID_ASSIGNED' : 'STUDENT_ID_RETRIEVED', entity: 'Student', entityId: result.studentId, newValue: { permanentStudentId: result.permanentStudentId } }));
            return json(response, result, result.created ? 201 : 200);
          }
          requestBody = await readJson(request);
          if (pathname === '/api/internal-student-registration/existing-student') {
            const student = await internalStudentRegistration.findExistingStudent(requestBody, user.schoolId);
            return json(response, { found: Boolean(student), student: student ? { ...student, id: student.studentId } : null });
          }
          const result = await internalStudentRegistration.register(requestBody, { schoolId: user.schoolId, actorId: user.id, requestId });
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'INTERNAL_STUDENT_REGISTERED', entity: 'Student', entityId: result.student.studentId ?? result.student.id, newValue: { permanentStudentId: result.permanentStudentId, classId: result.classId, admissionType: requestBody.admissionType, created: result.created } }));
          return json(response, result, result.created ? 201 : 200);
        } catch (error) {
          const operation = pathname.endsWith('/student-id') ? request.method === 'GET' ? 'student_id_lookup' : 'student_id_assignment' : pathname.endsWith('/existing-student') ? 'existing_student_lookup' : 'student_registration';
          const diagnostic = internalRegistrationErrorLogFields(error, error.registrationStep, Object.values(requestBody ?? {}));
          console.error('Internal student registration request failed', {
            ...diagnostic,
            operation, requestId, step: diagnostic.failingStep, errorName: diagnostic.name,
            errno: diagnostic.errno, sqlState: diagnostic.sqlState,
            sanitizedSqlMessage: diagnostic.sqlMessage ?? diagnostic.message,
            code: diagnostic.code, responseCode: error.code ?? 'INTERNAL_SERVER_ERROR', responseStatus: error.status ?? 500
          });
          return json(response, { error: error.message ?? 'Student registration failed.', code: error.code ?? 'INTERNAL_SERVER_ERROR', ...(Array.isArray(error.fields) ? { fields: error.fields } : {}) }, error.status ?? 500);
        }
      }
      if (pathname === '/api/school-settings' && request.method === 'GET') { if (!canAccess(user, 'settings.read')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, await schoolSettings.read(user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 500); } }
      if (pathname === '/api/school-settings' && request.method === 'PATCH') { if (!(user.roleKey === 'PROPRIETOR' || user.roleKey === 'SCHOOL_ADMIN' || canAccess(user, 'settings.write'))) return json(response, { error: 'Forbidden.' }, 403); try { const previous = await schoolSettings.read(user); const saved = await schoolSettings.update(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SCHOOL_SETTINGS_UPDATED', entity: 'School', entityId: user.schoolId, previousValue: previous.profile, newValue: saved.profile })); return json(response, saved); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/school-profile' && request.method === 'GET') { try { return json(response, await schoolProfile.read(user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 500); } }
      if (pathname === '/api/school-settings' && request.method === 'GET') { if (!canAccess(user, 'settings.read')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, await schoolSettings.read(user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 500); } }
      if (pathname === '/api/school-settings' && request.method === 'PATCH') { if (!(user.roleKey === 'PROPRIETOR' || user.roleKey === 'SCHOOL_ADMIN' || canAccess(user, 'settings.write'))) return json(response, { error: 'Forbidden.' }, 403); try { const previous = await schoolSettings.read(user); const saved = await schoolSettings.update(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SCHOOL_SETTINGS_UPDATED', entity: 'School', entityId: user.schoolId, previousValue: previous.profile, newValue: saved.profile })); return json(response, saved); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/school-profile' && request.method === 'GET') { try { return json(response, await schoolProfile.read(user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 500); } }
      if (pathname === '/api/school-profile' && request.method === 'PATCH') { try { schoolProfile.assertEdit(user); const body = await readJson(request); const info = body.schoolInformation ?? body; const canonical = Object.fromEntries(['name', 'motto', 'address', 'telephone', 'email', 'website', 'logoPath', 'primaryColour', 'secondaryColour', 'accentColour'].filter((key) => info[key] !== undefined).map((key) => [key, info[key]])); const saved = await schoolSettings.update({ ...canonical, schoolInformation: info }, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SCHOOL_PROFILE_UPDATED', entity: 'School', entityId: user.schoolId, newValue: saved.profile })); return json(response, await schoolProfile.read(user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/shep-activities')) {
        if (user.portal !== 'school' || !canAccess(user, SHEP_PERMISSIONS.view)) return json(response, { error: 'Forbidden.' }, 403);
        const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const parts = pathname.split('/').filter(Boolean); const id = parts[2]; const actor = { id: user.id, schoolId: user.schoolId, roleKey: user.roleKey, permissions: user.permissions, assignedClassIds: user.assignedClassIds, assignedStudentIds: user.assignedStudentIds };
        try {
          if (pathname === '/api/shep-activities/options' && request.method === 'GET') return json(response, shepActivities.options());
          if (pathname === '/api/shep-activities/dashboard' && request.method === 'GET') return json(response, shepActivities.dashboard(query, actor));
          if (pathname === '/api/shep-activities' && request.method === 'GET') return json(response, { activities: shepActivities.list(query, actor) });
          if (pathname === '/api/shep-activities' && request.method === 'POST') { const result = shepActivities.create(await readJson(request), actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SHEP_ACTIVITY_CREATED', entity: 'ShepActivity', entityId: result.id, newValue: result })); return json(response, result, 201); }
          if (pathname === '/api/shep-activities/report' && request.method === 'GET') return json(response, shepActivities.report(query, actor));
          if (pathname === '/api/shep-activities/participants' && request.method === 'POST') return json(response, shepActivities.addParticipant(await readJson(request), actor), 201);
          if (pathname === '/api/shep-activities/referrals' && request.method === 'GET') return json(response, { referrals: shepActivities.listReferrals(query, actor) });
          if (pathname === '/api/shep-activities/referrals' && request.method === 'POST') return json(response, shepActivities.createReferral(await readJson(request), actor), 201);
          if (id && parts[3] === 'participants' && request.method === 'GET') return json(response, { participants: shepActivities.listParticipants(id, actor) });
          if (id && parts[3] === 'referrals' && request.method === 'GET') return json(response, { referrals: shepActivities.listReferrals({ activityId: id }, actor) });
          if (parts[2] === 'referrals' && parts[3] && request.method === 'PATCH') return json(response, shepActivities.updateReferral(parts[3], await readJson(request), actor));
          if (id && request.method === 'GET') return json(response, shepActivities.detail(id, actor));
          if (id && request.method === 'PATCH') return json(response, shepActivities.update(id, await readJson(request), actor));
        } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); }
        return json(response, { error: 'Not found.' }, 404);
      }
      if (pathname.startsWith('/api/subject-register')) {
        if (user.portal !== 'school' || !canAccess(user, SUBJECT_REGISTER_PERMISSIONS.view)) return json(response, { error: 'Forbidden.' }, 403);
        const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const parts = pathname.split('/').filter(Boolean); const id = parts[2]; const actor = { id: user.id, schoolId: user.schoolId, roleKey: user.roleKey, permissions: user.permissions };
        try {
          if (pathname === '/api/subject-register/options' && request.method === 'GET') return json(response, subjectRegister.options(actor));
          if (pathname === '/api/subject-register' && request.method === 'GET') return json(response, { registers: subjectRegister.list(query, actor) });
          if (pathname === '/api/subject-register' && request.method === 'POST') { const result = subjectRegister.register(await readJson(request), actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SUBJECT_REGISTERED', entity: 'SubjectRegister', entityId: result.id, newValue: result })); return json(response, result, 201); }
          if (pathname === '/api/subject-register/bulk' && request.method === 'POST') { const body = await readJson(request); const result = subjectRegister.bulkRegister(body, actor); if (!body.preview) audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SUBJECT_REGISTER_BULK_UPDATED', entity: 'SubjectRegister', newValue: result })); return json(response, { preview: Boolean(body.preview), registers: result }, body.preview ? 200 : 201); }
          if (pathname === '/api/subject-register/copy-preview' && request.method === 'POST') return json(response, { preview: subjectRegister.copyPreview(await readJson(request), actor) });
          if (pathname === '/api/subject-register/history' && request.method === 'GET') return json(response, { history: subjectRegister.history(query, actor) });
          if (id && parts[3] === 'assign-teacher' && request.method === 'POST') { const body = await readJson(request); const result = subjectRegister.assignTeacher(id, body.teacherIds ?? [], actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SUBJECT_REGISTER_TEACHER_ASSIGNED', entity: 'SubjectRegister', entityId: id, newValue: result })); return json(response, result); }
          if (id && parts[3] === 'activate' && request.method === 'POST') return json(response, subjectRegister.activate(id, actor));
          if (id && parts[3] === 'deactivate' && request.method === 'POST') { const result = subjectRegister.deactivate(id, actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SUBJECT_REGISTER_DEACTIVATED', entity: 'SubjectRegister', entityId: id, newValue: result })); return json(response, result); }
        } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); }
        return json(response, { error: 'Not found.' }, 404);
      }
      if (pathname.startsWith('/api/sporting-activities')) {
        if (user.portal !== 'school' || !canAccess(user, SPORTING_PERMISSIONS.view)) return json(response, { error: 'Forbidden.' }, 403);
        const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams);
        const parts = pathname.split('/').filter(Boolean);
        const activityId = parts[2];
        const actor = { id: user.id, schoolId: user.schoolId };
        try {
          if (pathname === '/api/sporting-activities/options' && request.method === 'GET') return json(response, { sports: sportingActivities.listSports(user.schoolId, query.academicYearId), teams: sportingActivities.listTeams(user.schoolId), students: students.listStudents({ requestedSchoolId: user.schoolId }) });
          if (pathname === '/api/sporting-activities' && request.method === 'GET') return json(response, { activities: sportingActivities.listActivities(query, actor), summary: sportingActivities.summary(query, actor) });
          if (pathname === '/api/sporting-activities/sports' && request.method === 'POST' && canAccess(user, SPORTING_PERMISSIONS.create)) { const result = sportingActivities.createSport(await readJson(request), actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'SPORT_CREATED', entity: 'Sport', entityId: result.id, newValue: result })); return json(response, result, 201); }
          if (pathname === '/api/sporting-activities/teams' && request.method === 'POST' && canAccess(user, SPORTING_PERMISSIONS.create)) { const result = sportingActivities.createTeam(await readJson(request), actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'TEAM_CREATED', entity: 'SportTeam', entityId: result.id, newValue: result })); return json(response, result, 201); }
          if (pathname === '/api/sporting-activities' && request.method === 'POST' && canAccess(user, SPORTING_PERMISSIONS.create)) { const result = sportingActivities.createActivity(await readJson(request), actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'SPORTING_ACTIVITY_CREATED', entity: 'SportingActivity', entityId: result.id, newValue: result })); return json(response, result, 201); }
          if (pathname === '/api/sporting-activities/reports' && request.method === 'GET' && canAccess(user, SPORTING_PERMISSIONS.reports)) return json(response, sportingActivities.report(query.type || 'SPORTING_ACTIVITY', query, actor));
          if (activityId && parts.length === 3 && request.method === 'GET') { const result = sportingActivities.getActivity(activityId, actor); return result ? json(response, result) : json(response, { error: 'Not found.' }, 404); }
          if (activityId && parts[3] === 'fixtures' && request.method === 'POST' && canAccess(user, SPORTING_PERMISSIONS.fixtures)) { const result = sportingActivities.createFixture(activityId, await readJson(request), actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'FIXTURE_CREATED', entity: 'SportingFixture', entityId: result.id, newValue: result })); return json(response, result, 201); }
          if (activityId && parts[3] === 'participants' && request.method === 'POST' && canAccess(user, SPORTING_PERMISSIONS.participants)) { const result = sportingActivities.addParticipant(activityId, await readJson(request), actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'PARTICIPATION_RECORDED', entity: 'SportingParticipant', entityId: result.id, newValue: result })); return json(response, result, 201); }
          if (activityId && parts[3] === 'results' && request.method === 'POST' && canAccess(user, SPORTING_PERMISSIONS.results)) { const result = sportingActivities.addResult(activityId, await readJson(request), actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'SPORTING_RESULT_ENTERED', entity: 'SportingResult', entityId: result.id, newValue: result })); return json(response, result, 201); }
          if (activityId && request.method === 'PATCH' && canAccess(user, SPORTING_PERMISSIONS.update)) { const result = sportingActivities.updateActivity(activityId, await readJson(request), actor); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'SPORTING_ACTIVITY_UPDATED', entity: 'SportingActivity', entityId: result.id, newValue: result })); return json(response, result); }
        } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); }
        return json(response, { error: 'Not found.' }, 404);
      }
      if (pathname === '/api/admin/admissions/schema-diagnostic' && request.method === 'GET') {
        if (user.portal !== 'school' || canonicalRoleKey(user.roleKey) !== 'PROPRIETOR') return json(response, { error: 'Forbidden.' }, 403);
        try { return json(response, await inspectAdmissionSchema(database)); }
        catch (error) { return json(response, { error: 'ADMISSION_SCHEMA_DIAGNOSTIC_UNAVAILABLE', code: /^[A-Z0-9_]+$/.test(String(error?.code ?? '')) ? error.code : 'UNKNOWN' }, 503); }
      }
      if (pathname === '/api/admission-applications' && request.method === 'GET') { if (user.portal !== 'parent' && !canAccess(user, 'admissions.read')) return json(response, { error: 'Forbidden.' }, 403); const filters = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const applications = durableAdmissions ? await durableAdmissions.listApplications(filters, user) : admissionForms.listApplications(filters, user); return json(response, { applications: applications.map(presentAdmissionApplication) }); }
      if (pathname === '/api/admission-analytics' && request.method === 'GET') { if (user.portal !== 'school' || !canAccess(user, 'admissions.analytics.read')) return json(response, { error: 'Forbidden.' }, 403); const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); return json(response, admissionForms.admissionAnalytics(query, user, { invoices: fees.listInvoices(), payments: fees.listPayments() })); }
      if (pathname === '/api/admission-applications' && request.method === 'POST') { if (user.portal !== 'parent' && !canAccess(user, 'admissions.write')) return json(response, { error: 'Forbidden.' }, 403); try { const result = durableAdmissions ? await durableAdmissions.createApplication(await readJson(request), user) : admissionForms.createApplication(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ADMISSION_APPLICATION_CREATED', entity: 'AdmissionFormApplication', entityId: result.applicationNumber, newValue: result })); return json(response, presentAdmissionApplication(result), 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/admission-applications/') && pathname.split('/').filter(Boolean).length === 3 && request.method === 'GET') { if (user.portal !== 'parent' && !canAccess(user, 'admissions.read')) return json(response, { error: 'Forbidden.' }, 403); const id = pathname.split('/')[3], result = durableAdmissions ? await durableAdmissions.getApplication(id, user) : admissionForms.getApplication(id, user); return result ? json(response, presentAdmissionApplication(result)) : json(response, { error: 'Not found.' }, 404); }
      if (pathname.startsWith('/api/admission-applications/') && pathname.endsWith('/documents') && request.method === 'GET') { if (user.portal !== 'parent' && !canAccess(user, 'admissions.read')) return json(response, { error: 'Forbidden.' }, 403); const id = pathname.split('/')[3]; const documents = durableAdmissions ? await durableAdmissions.listDocuments(id, user) : admissionForms.listDocuments(id, user); return json(response, { documents: presentAdmissionApplication({ documents }).documents }); }
      if (pathname.startsWith('/api/admission-applications/') && pathname.includes('/documents/') && pathname.endsWith('/download') && request.method === 'GET') {
        if (user.portal !== 'parent' && !canAccess(user, 'admissions.read')) return json(response, { error: 'Forbidden.' }, 403);
        if (!admissionDocumentStorage) return json(response, { error: 'Private admission document storage is not configured.' }, 503);
        const parts = pathname.split('/'), applicationNumber = parts[3], documentId = parts[5];
        const documents = durableAdmissions ? await durableAdmissions.listDocuments(applicationNumber, user) : admissionForms.listDocuments(applicationNumber, user);
        const document = documents.find((item) => item.id === documentId);
        if (!document?.storageKey) return json(response, { error: 'Not found.' }, 404);
        const file = await admissionDocumentStorage.download(document.storageKey);
        if (!file || file.statusCode !== 200 || !file.stream) return json(response, { error: 'Not found.' }, 404);
        const name = String(document.originalName ?? 'admission-document').replace(/[\r\n"\\]/g, '_');
        response.writeHead(200, { 'Content-Type': document.mimeType ?? 'application/octet-stream', ...(document.size ? { 'Content-Length': String(document.size) } : {}), 'Content-Disposition': `attachment; filename="${name}"`, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' });
        const stream = typeof file.stream.pipe === 'function' ? file.stream : Readable.fromWeb(file.stream);
        stream.pipe(response);
        return;
      }
      if (pathname.startsWith('/api/admission-applications/') && pathname.includes('/documents/') && pathname.endsWith('/review') && request.method === 'POST') { if (!canAccess(user, 'admissions.review')) return json(response, { error: 'Forbidden.' }, 403); try { const parts = pathname.split('/'), service = durableAdmissions ?? admissionForms, result = await service.reviewDocument(parts[3], parts[5], await readJson(request), user); return json(response, presentAdmissionApplication({ documents: [result] }).documents[0]); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/admission-applications/') && pathname.endsWith('/offer-acceptance') && request.method === 'POST') { if (user.portal !== 'parent' && !canAccess(user, 'admissions.accept')) return json(response, { error: 'Forbidden.' }, 403); const service = durableAdmissions ?? admissionForms; try { const id = pathname.split('/')[3], result = await service.acceptOffer(id, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ADMISSION_OFFER_ACCEPTED', entity: 'AdmissionFormApplication', entityId: id })); return json(response, presentAdmissionApplication(result)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/admission-applications/') && pathname.endsWith('/update') && request.method === 'PATCH') { if (user.portal !== 'parent' && !canAccess(user, 'admissions.write')) return json(response, { error: 'Forbidden.' }, 403); try { const result = durableAdmissions ? await durableAdmissions.updateApplication(pathname.split('/')[3], await readJson(request), user) : admissionForms.updateApplication(pathname.split('/')[3], await readJson(request), user); return json(response, presentAdmissionApplication(result)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/admission-applications/') && (pathname.endsWith('/documents') || /\/documents\/[^/]+$/.test(pathname)) && ['POST', 'PUT'].includes(request.method)) {
        if (user.portal !== 'parent' && !canAccess(user, 'admissions.write')) return json(response, { error: 'Forbidden.' }, 403);
        if (!admissionDocumentStorage) return json(response, { error: 'Private admission document storage is not configured; no document was uploaded.' }, 503);
        const parts = pathname.split('/'), applicationNumber = parts[3], replacingDocumentId = request.method === 'PUT' ? parts[5] : null;
        try {
          const service = durableAdmissions ?? admissionForms;
          const application = await service.getApplication(applicationNumber, user);
          if (!application) return json(response, { error: 'Application not found.' }, 404);
          const documentType = String(request.headers['x-document-type'] ?? ''), mimeType = String(request.headers['content-type'] ?? '').split(';')[0].trim().toLowerCase();
          const bytes = await readBytes(request, 10 * 1024 * 1024);
          const previous = replacingDocumentId ? (application.documents ?? []).find((item) => item.id === replacingDocumentId) : null;
          if (replacingDocumentId && !previous) return json(response, { error: 'Admission document not found.' }, 404);
          const sha256 = createHash('sha256').update(bytes).digest('hex');
          if (previous?.sha256 === sha256) return json(response, presentAdmissionApplication({ documents: [previous] }).documents[0]);
          if (!previous) { const duplicate = (application.documents ?? []).find((item) => item.documentType === documentType && item.sha256 === sha256); if (duplicate) return json(response, presentAdmissionApplication({ documents: [duplicate] }).documents[0]); }
          const stored = await admissionDocumentStorage.upload({ bytes, mimeType, documentType, schoolId: user.schoolId, applicationId: application.id, originalName: request.headers['x-original-name'] ?? '' });
          let result;
          try {
            result = previous
              ? await service.replaceDocument(applicationNumber, replacingDocumentId, { ...stored, documentType }, user)
              : await service.attachDocument(applicationNumber, { ...stored, documentType }, user);
          } catch (error) { await admissionDocumentStorage.remove(stored.storageKey); throw error; }
          if (previous?.storageKey) await admissionDocumentStorage.remove(previous.storageKey).catch(() => {});
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: previous ? 'ADMISSION_DOCUMENT_REPLACED' : 'ADMISSION_DOCUMENT_UPLOADED', entity: 'AdmissionDocument', entityId: result.id }));
          return json(response, presentAdmissionApplication({ documents: [result] }).documents[0], previous ? 200 : 201);
        } catch (error) { return json(response, { error: error.message }, error.status ?? 400); }
      }
      if (pathname.startsWith('/api/admission-applications/') && pathname.endsWith('/documents') && request.method === 'GET') { if (user.portal !== 'parent' && !canAccess(user, 'admissions.read')) return json(response, { error: 'Forbidden.' }, 403); const id = pathname.split('/')[3]; return json(response, presentAdmissionApplication({ documents: durableAdmissions ? await durableAdmissions.listDocuments(id, user) : admissionForms.listDocuments(id, user) })); }
      if (pathname.startsWith('/api/admission-applications/') && pathname.endsWith('/submit') && request.method === 'POST') { if (user.portal !== 'parent' && !canAccess(user, 'admissions.write')) return json(response, { error: 'Forbidden.' }, 403); try { const id = pathname.split('/')[3], existing = durableAdmissions ? await durableAdmissions.getApplication(id, user) : admissionForms.getApplication(id, user); const fee = admissionForms.activeFeeFor(existing?.section1.className ?? existing?.section1.classAppliedFor, existing?.academicYear, existing?.admissionTerm); const structures = durableAdmissions ? await admissionFeeStructures(user, existing) : []; const feeAssessment = durableAdmissions ? assessAdmissionFees({ structures, schoolId: user.schoolId, classId: existing?.section1.classAppliedFor, academicYearId: existing?.section1.academicYearId, termId: existing?.section1.termId }) : null; const result = durableAdmissions ? await durableAdmissions.submitApplication(id, user, fee, feeAssessment) : admissionForms.submitApplication(id, user, fee); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ADMISSION_APPLICATION_SUBMITTED', entity: 'AdmissionFormApplication', entityId: id })); return json(response, presentAdmissionApplication(result)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/admission-applications/') && pathname.endsWith('/review') && request.method === 'POST') {
        if (!canAccess(user, 'admissions.review')) return json(response, { error: 'Forbidden.' }, 403);
        try {
          const id = pathname.split('/')[3], body = await readJson(request);
          if (body.status === 'ACCEPTED' && !canAccess(user, 'admissions.accept')) return json(response, { error: 'Forbidden.' }, 403);
          if (body.status === 'REJECTED' && !canAccess(user, 'admissions.reject')) return json(response, { error: 'Forbidden.' }, 403);
          const result = durableAdmissions ? await durableAdmissions.reviewApplication(id, body, user) : admissionForms.reviewApplication(id, body, user);
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: result.status === 'ACCEPTED' ? 'ADMISSION_ACCEPTED' : result.status === 'REJECTED' ? 'ADMISSION_REJECTED' : 'ADMISSION_REVIEWED', entity: 'AdmissionFormApplication', entityId: id, newValue: result }));
          return json(response, { ...presentAdmissionApplication(result), student: null });
        } catch (error) { return json(response, { error: error.message }, error.status ?? 400); }
      }
      if (pathname.startsWith('/api/admission-applications/') && pathname.endsWith('/enroll') && request.method === 'POST') {
        if (!canAccess(user, 'admissions.review') || !canAccess(user, 'admissions.accept')) return json(response, { error: 'Forbidden.' }, 403);
        if (!durableAdmissions || !admissionEnrollment) return json(response, { error: 'Durable enrollment is unavailable.' }, 503);
        try {
          const id = pathname.split('/')[3], application = await durableAdmissions.getApplication(id, user);
          if (!application || !['ACCEPTED', 'ENROLLMENT'].includes(application.status)) return json(response, { error: 'An approved application is required before enrollment.' }, 409);
          if (!application.workflow?.offer?.acceptedAt) return json(response, { error: 'The admission offer must be accepted before enrollment.' }, 409);
          const enrollment = await admissionEnrollment.enroll({ applicationId: application.id, applicationNumber: application.applicationNumber, actorId: user.id });
          const result = await durableAdmissions.attachStudent(id, enrollment.student, user);
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ADMISSION_ENROLLED', entity: 'AdmissionFormApplication', entityId: id, newValue: { studentId: enrollment.student.id, permanentStudentId: enrollment.student.permanent_student_id ?? enrollment.student.permanentStudentId } }));
          return json(response, { ...presentAdmissionApplication(result), student: enrollment.student, created: enrollment.created });
        } catch (error) { return json(response, { error: error.code === 'ENROLLMENT_FAILED' ? 'Enrollment could not be completed.' : error.message }, error.status ?? 400); }
      }
      if (pathname === '/api/admission-fees' && request.method === 'GET') { if (user.portal !== 'parent' && !canAccess(user, 'fees.read') && !canAccess(user, 'admissions.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { fees: admissionForms.listFeeStructures({ publishedOnly: user.portal === 'parent' }) }); }
      if (pathname === '/api/admission-fees/quote' && request.method === 'GET') { if (user.portal !== 'parent' && !canAccess(user, 'fees.read') && !canAccess(user, 'admissions.read')) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; const fee = admissionForms.activeFeeFor(query.get('classAppliedFor'), query.get('academicYear'), query.get('term')); return fee ? json(response, { fee }) : json(response, { error: 'No published fee structure found.' }, 404); }
      if (pathname === '/api/admission-fees' && request.method === 'POST') { if (!canAccess(user, 'fees.write')) return json(response, { error: 'Forbidden.' }, 403); try { const result = admissionForms.createFeeStructure(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ADMISSION_FEE_STRUCTURE_CHANGED', entity: 'AdmissionFeeStructure', entityId: result.id, newValue: result })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, 400); } }
      if (pathname.startsWith('/api/admission-fees/') && request.method === 'PATCH' && !pathname.endsWith('/publish')) { if (!canAccess(user, 'fees.write')) return json(response, { error: 'Forbidden.' }, 403); try { const id = pathname.split('/')[3]; const before = admissionForms.listFeeStructures().find((fee) => fee.id === id); const result = admissionForms.updateFeeStructure(id, await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ADMISSION_FEE_STRUCTURE_CHANGED', entity: 'AdmissionFeeStructure', entityId: result.id, previousValue: before, newValue: result })); return json(response, result); } catch (error) { return json(response, { error: error.message }, 400); } }
      if (pathname === '/api/admission-fees/publish' && request.method === 'POST') { if (!canAccess(user, 'fees.write')) return json(response, { error: 'Forbidden.' }, 403); try { const result = admissionForms.publishFeeStructure((await readJson(request)).id, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ADMISSION_FEE_PUBLISHED', entity: 'AdmissionFeeStructure', entityId: result.id, newValue: result })); return json(response, result); } catch (error) { return json(response, { error: error.message }, 400); } }
      if (pathname === '/api/admission-prospectus/options' && request.method === 'GET') { if (user.portal !== 'parent' && !(canAccess(user, PROSPECTUS_PERMISSION) || canAccess(user, 'admissions.read'))) return json(response, { error: 'Forbidden.' }, 403); const options = admissionProspectus.listOptions(); if (user.portal === 'school' && !options.academicYears.length) { const year = new Date().getFullYear(); options.academicYears = [{ id: String(year), name: `${year}/${year + 1}` }]; } return json(response, options); }
      if (pathname === '/api/admission-workflow/options' && request.method === 'GET') {
        if (user.portal !== 'school' || !canAccess(user, 'admissions.read')) return json(response, { error: 'Forbidden.' }, 403);
        try {
          let classes = await attendanceClassOptions({ ...user, roleKey: null });
          classes = classes.filter((item) => canonicalClassId(item.name));
          let academicYears = [], terms = [];
          if (database?.query) {
            [academicYears, terms] = await Promise.all([
              database.query('SELECT id,name,starts_on AS startsOn,ends_on AS endsOn,is_current AS isCurrent FROM academic_years WHERE school_id=? ORDER BY starts_on DESC,id', [user.schoolId]),
              database.query('SELECT t.id,t.academic_year_id AS academicYearId,t.name FROM terms t JOIN academic_years y ON y.id=t.academic_year_id WHERE y.school_id=? ORDER BY t.starts_on,t.id', [user.schoolId])
            ]);
          }
          if (!database?.query) return json(response, { error: 'Database-backed admission options are unavailable.', code: 'PERSISTENCE_UNAVAILABLE' }, 503);
          academicYears = academicYears.map((item) => ({ ...item, admissionYear: String(item.name ?? item.id).match(/^\d{4}/)?.[0] ?? null }));
          return json(response, { classes, academicYears, terms, transferPreviousClasses: TRANSFER_PREVIOUS_CLASS_OPTIONS, documentStorageAvailable: Boolean(admissionDocumentStorage) });
        } catch (error) { return json(response, { error: 'Unable to load admission options.' }, error.status ?? 503); }
      }
      if (pathname === '/api/admission-prospectus/template' && request.method === 'GET') { if (!canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); return json(response, { template: DEFAULT_PROSPECTUS_TEMPLATE }); }
      if (pathname === '/api/academic/options' && request.method === 'GET') { if (!canAccess(user, 'academics.read') && !canAccess(user, 'results.read') && !canAccess(user, 'examinations.read') && !canAccess(user, 'subjects.read') && !canAccess(user, 'subjects.manage') && !canAccess(user, 'mock.results.read') && !canAccess(user, 'mock.results.generate')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, durableAcademic ? await durableAcademic.options(user) : academicResults.options(user)); } catch (error) { console.error('[Academic options] request failed', { schoolId: user.schoolId, userId: user.id, message: error.message, stack: error.stack }); return json(response, { error: error.message === 'Forbidden.' ? 'Forbidden.' : 'Unable to load academic options. Please try again.' }, error.message === 'Forbidden.' ? 403 : 500); } }
      if (pathname === '/api/academic/result-students' && request.method === 'GET') {
        const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams);
        const mockContext = String(query.resultType ?? query.examination ?? '').toUpperCase() === 'MOCK';
        const hasResultAccess = canAccess(user, 'results.read') || canAccess(user, 'results.generate') || canAccess(user, 'examinations.read');
        const hasMockAccess = canAccess(user, 'mock.results.read') || canAccess(user, 'mock.results.generate');
        if (!hasResultAccess && !(mockContext && hasMockAccess)) return json(response, { error: 'Forbidden.' }, 403);
        try {
          const classId = String(query.classId ?? '').trim();
          const academicYear = String(query.academicYear ?? '').trim();
          const term = String(query.term ?? '').trim();
          if (!classId || !academicYear || !term) return json(response, { students: [] });
          if (user.roleKey === 'TEACHER' && user.assignedClassIds?.length && !user.assignedClassIds.includes(classId)) return json(response, { error: 'Forbidden.' }, 403);
          if (mockContext && !durableAcademic && !canonicalClassId(classId)) throw new Error('Mock examinations are available for JHS 1, JHS 2, and JHS 3 only.');
          const sampleMode = isSampleModeEnabled(query);
          let studentsForResult;
          if (sampleMode) {
            if (user.portal !== 'school') return json(response, { error: 'Forbidden.' }, 403);
            const context = durableAcademic ? await durableAcademic.resultContext(query, user) : { className: classId };
            if (!canonicalClassId(context.className)) throw new Error('The selected class is not configured for sample results.');
            students.seedSampleStudents?.();
            studentsForResult = students.listStudents({ requestedSchoolId: user.schoolId, includeTestRecords: true })
              .filter((student) => student.isTestRecord && isConfiguredTestStudentId(student.permanentStudentId))
              .map((student) => ({ id: student.id, studentId: student.id, indexNumber: student.permanentStudentId, permanentStudentId: student.permanentStudentId, name: [student.firstName, student.middleName, student.surname].filter(Boolean).join(' '), classId, isTestRecord: true }));
          } else {
            studentsForResult = durableAcademic
              ? await durableAcademic.resultStudents(query, user)
              : students.listEligibleStudents({ requestedSchoolId: user.schoolId, academicYearId: academicYear, classId, termId: term, includeTestRecords: false })
                .filter((student) => student.schoolId === user.schoolId)
                .map((student) => ({ id: student.id, studentId: student.id, indexNumber: student.permanentStudentId, permanentStudentId: student.permanentStudentId, name: [student.firstName, student.middleName, student.surname].filter(Boolean).join(' '), classId: student.classId, isTestRecord: false }));
          }
          return json(response, { students: studentsForResult });
        } catch (error) {
          console.error('[Result students] request failed', { schoolId: user.schoolId, userId: user.id, message: error.message, stack: error.stack });
          return json(response, { error: error.message === 'Forbidden.' ? 'Forbidden.' : 'Unable to load students for the selected result context.' }, error.message === 'Forbidden.' ? 403 : 400);
        }
      }
      if (pathname === '/api/academic/score-entry/roster' && request.method === 'GET') { if (!canAccess(user, 'marks.write') && !canAccess(user, 'results.read')) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const sampleMode = isSampleModeEnabled(query); if (sampleMode && user.portal !== 'school') return json(response, { error: 'Forbidden.' }, 403); if (sampleMode && !durableAcademic) students.seedSampleStudents?.(); const roster = durableAcademic ? (sampleMode ? await durableAcademic.sampleScoreEntryRoster(query, user) : await durableAcademic.roster(query, user)) : academicResults.scoreEntryRoster(query, user); return json(response, { students: roster }); } catch (error) { console.error('[Score Entry roster] request failed', { schoolId: user.schoolId, userId: user.id, message: error.message, stack: error.stack }); return json(response, { error: error.message === 'Forbidden.' ? 'Forbidden.' : 'Unable to load students. Please try again.' }, error.status ?? (error.message === 'Forbidden.' || error.message === 'Class is outside your assignment.' ? 403 : /^(?:Academic year|Term|Class|Subject) is required\.$/.test(error.message) ? 400 : 500)); } }
      if (pathname === '/api/academic/mock-scores/roster' && request.method === 'GET') { if (!canAccess(user, 'mock.scores.read') && !canAccess(user, 'mock.scores.write')) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const sampleMode = isSampleModeEnabled(query); if (sampleMode && user.portal !== 'school') return json(response, { error: 'Forbidden.' }, 403); let roster; if (sampleMode) { const normalized = await normalizedSampleMockScoreInput(query, user); roster = academicResults.mockScoreEntryRoster(normalized.input, normalized.actor); } else roster = durableAcademic ? await durableAcademic.mockRoster(query, user) : academicResults.mockScoreEntryRoster(query, user); return json(response, { students: roster }); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/academic/scores' && request.method === 'GET') { if (!canAccess(user, 'results.read') && !canAccess(user, 'marks.write')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, { scores: durableAcademic ? await durableAcademic.listScores(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user) : academicResults.listScores(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user) }); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/scores' && request.method === 'POST') { if (!canAccess(user, 'marks.write')) return json(response, { error: 'Forbidden.' }, 403); try { const body = await readJson(request); let result;
if (durableAcademic && isSampleModeEnabled(body)) {
  const sampleContext = await durableAcademic.sampleScoreEntryContext(body, user);
  if (!sampleContext.students.some((student) => String(student.studentId) === String(body.studentId))) throw Object.assign(new Error('Student is not in the selected sample Score Entry roster.'), { status: 400 });
  const sampleClassId = canonicalClassId(sampleContext.class.name);
  if (!sampleClassId) throw Object.assign(new Error('Selected class is not available in the sample Score Entry catalogue.'), { status: 400 });
  const sampleActor = user.roleKey === 'TEACHER' ? { ...user, assignedClassIds: (user.assignedClassIds ?? []).map((id) => String(id) === String(sampleContext.class.id) ? sampleClassId : id) } : user;
  const matchingSubjects = subjects.list({ classId: sampleClassId }, sampleActor).filter((subject) => String(subject.name).trim().toLocaleLowerCase('en') === String(sampleContext.subject.name).trim().toLocaleLowerCase('en') && subject.active !== false && subject.isScoring !== false && Number(subject.isScoring) !== 0);
  if (matchingSubjects.length !== 1) throw Object.assign(new Error('Selected subject is not uniquely configured for the sample class.'), { status: 400 });
  const sampleSubject = matchingSubjects[0];
  const scoreActor = user.roleKey === 'TEACHER' ? { ...sampleActor, assignedSubjectIds: (user.assignedSubjectIds ?? []).map((id) => String(id) === String(sampleContext.subject.id) ? sampleSubject.id : id) } : sampleActor;
  result = academicResults.saveScore({ ...body, classId: sampleClassId, subjectId: sampleSubject.id }, scoreActor);
} else if (durableAcademic) {
  result = await durableAcademic.saveScore(body, user);
} else {
  result = academicResults.saveScore(body, user);
} audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SCORE_SAVED', entity: isSampleModeEnabled(body) ? 'SampleAcademicScore' : 'AcademicScore', entityId: result.id })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/academic/results/save' && request.method === 'POST') { if (!canAccess(user, 'marks.write') && !canAccess(user, 'results.write') && !canAccess(user, 'mock.scores.write')) return json(response, { error: 'Forbidden.' }, 403); try { const body = await readJson(request); const result = body.isSample === true && body.examination === 'MOCK' ? sampleResults.saveMock(body, user) : durableAcademic ? await durableAcademic.saveResult(body, user) : academicResults.saveResult(body, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'RESULT_SAVED', entity: 'AcademicResult', entityId: result.id, newValue: { status: result.status, version: result.version, studentId: result.studentId } })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/results/saved' && request.method === 'GET') { if (!canAccess(user, 'results.read') && !canAccess(user, 'marks.write')) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); return json(response, { result: durableAcademic ? await durableAcademic.savedResultFor(query, user) : academicResults.savedResultFor(query, user) }); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/results/publish' && request.method === 'POST') { if (!canAccess(user, 'results.publish')) return json(response, { error: 'Forbidden.' }, 403); try { const body = await readJson(request); const result = body.isSample === true && body.examination === 'MOCK' ? await sampleResults.publish(body, user) : durableAcademic ? await durableAcademic.publishResults(body, user) : academicResults.publishResults(body, user); if (!result.isSample) dispatchClassNotification(result.classId, 'RESULT_PUBLISHED', 'Result published', (student) => `Dear Parent, the ${result.term} result for ${[student.firstName, student.middleName, student.surname].filter(Boolean).join(' ')}, Permanent Student ID ${student.permanentStudentId}, has been published. Please log in to the Parent Portal to view the result slip.`, `RESULT_PUBLISHED:${result.id}:${result.academicYear}:${result.term}`); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'RESULTS_PUBLISHED', entity: 'AcademicResultPublication', entityId: result.id, newValue: result })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/results/publication' && request.method === 'GET') { if (!canAccess(user, 'results.read') && user.portal !== 'parent') return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; return json(response, { publication: academicResults.publicationFor(Object.fromEntries(query)) }); }
      if (pathname === '/api/parent/results' && request.method === 'GET') { if (user.portal !== 'parent' || !canAccess(user, 'children.read')) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams, permanentStudentId = query.get('permanentStudentId'); const student = await authorizeParentStudent({ actor: user, permanentStudentId, students, admissionEnrollment }); if (!student) return json(response, { error: PARENT_UNLINKED_MESSAGE }, 403); const classId = query.get('classId') ?? student.classId, academicYear = query.get('academicYear'), term = query.get('term'), isMock = String(query.get('resultType') ?? query.get('examination') ?? '').toUpperCase() === 'MOCK', mockLabel = query.get('mockLabel'); await assertResultReadable({ classId, academicYear, term, studentId: student.id, resultType: isMock ? 'MOCK' : 'TERMINAL', mockLabel }, user); const publication = durableAcademic ? await durableAcademic.publicationFor({ classId, academicYear, term, studentId: student.id, examination: isMock ? 'MOCK' : 'TERMINAL', mockLabel }, { ...user, permissions: new Set(['results.read', 'results.generate']) }) : academicResults.publicationFor({ classId, academicYear, term, isSample: Boolean(student.isTestRecord), studentId: student.id, examination: isMock ? 'MOCK' : 'TERMINAL', mockLabel }); if (publication?.status !== 'PUBLISHED') return json(response, { error: 'Result is not published.' }, 404); try { const result = durableAcademic ? await durableAcademic.result({ studentId: student.id, classId, academicYear, term, mockLabel }, { ...user, roleKey: 'HEADTEACHER', permissions: new Set(['results.read', 'results.generate']), schoolId: user.schoolId }) : academicResults.result({ studentId: student.id, classId, academicYear, term, mockLabel }, { ...user, roleKey: 'HEADTEACHER', permissions: new Set(['*']), schoolId: user.schoolId }); return json(response, result); } catch (error) { return json(response, { error: 'Result is unavailable.' }, 404); } }
      if (pathname === '/api/transcripts' && request.method === 'POST') { if (!['HEADTEACHER', 'ASSISTANT_HEADTEACHER', 'PROPRIETOR'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { const result = transcripts.generate(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'TRANSCRIPT_GENERATED', entity: 'StudentTranscript', entityId: result.id, newValue: { transcriptReference: result.transcriptReference, version: result.version.versionNumber, studentId: result.studentId } })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, 400); } }
      if (pathname.startsWith('/api/transcripts/') && pathname.endsWith('/publish') && request.method === 'POST') { if (!['HEADTEACHER', 'ASSISTANT_HEADTEACHER', 'PROPRIETOR'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { const result = transcripts.publish(pathname.split('/')[3], user); const snapshot = result.version.academicSnapshot; dispatchParentMessage({ studentId: snapshot.studentId, category: 'TRANSCRIPT_AVAILABLE', title: 'Official transcript available', body: `Dear Parent, an official transcript for ${snapshot.studentName}, Permanent Student ID ${snapshot.permanentStudentId}, is now available. Please log in to the Parent Portal or contact the school.`, idempotencyKey: `TRANSCRIPT_PUBLISHED:${result.transcriptReference}:V${result.version.versionNumber}` }); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'TRANSCRIPT_PUBLISHED', entity: 'StudentTranscript', entityId: result.id, newValue: { transcriptReference: result.transcriptReference, version: result.version.versionNumber } })); return json(response, result); } catch (error) { return json(response, { error: error.message }, 400); } }
      if (pathname.startsWith('/api/transcripts/') && pathname.endsWith('/revoke') && request.method === 'POST') { if (!['HEADTEACHER', 'ASSISTANT_HEADTEACHER', 'PROPRIETOR'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { const result = transcripts.revoke(pathname.split('/')[3], (await readJson(request)).reason, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'TRANSCRIPT_REVOKED', entity: 'StudentTranscript', entityId: result.id, newValue: { transcriptReference: result.transcriptReference, version: result.version.versionNumber } })); return json(response, result); } catch (error) { return json(response, { error: error.message }, 400); } }
      if (pathname === '/api/transcripts/view' && request.method === 'GET') { if (user.portal !== 'parent' && !['HEADTEACHER', 'ASSISTANT_HEADTEACHER', 'PROPRIETOR'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, transcripts.getForStudent(new URL(request.url, 'http://localhost').searchParams.get('permanentStudentId'), user)); } catch (error) { return json(response, { error: error.message }, 403); } }
      if (pathname === '/api/transcripts/verify' && request.method === 'GET') { const query = new URL(request.url, 'http://localhost').searchParams; return json(response, transcripts.verify(query.get('reference'), query.get('token'))); }
      if (pathname.startsWith('/api/transcripts/') && pathname.endsWith('/pdf') && request.method === 'GET') { if (user.portal !== 'parent' && !['HEADTEACHER', 'ASSISTANT_HEADTEACHER', 'PROPRIETOR'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { const query = new URL(request.url, 'http://localhost').searchParams; const file = await transcripts.pdf(pathname.split('/')[3], query.get('version') ?? 1, user); response.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `inline; filename="${file.filename}"` }); response.end(file.content); return; } catch (error) { return json(response, { error: error.message }, 403); } }
      if (pathname === '/api/academic/results/block-status' && request.method === 'GET') { if (!['TEACHER', 'PROPRIETOR', 'HEADTEACHER', 'ACCOUNTANT_BURSAR'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const resultType = String(query.resultType ?? 'TERMINAL').toUpperCase() === 'MOCK' ? 'MOCK' : 'TERMINAL'; if (user.roleKey === 'TEACHER' && !user.assignedClassIds?.map(String).includes(String(query.classId ?? ''))) return json(response, { error: 'Class is outside your assignment.' }, 403); if (!canAccess(user, resultType === 'MOCK' ? 'mock.results.read' : 'results.read') && !canAccess(user, resultType === 'MOCK' ? 'mock.results.generate' : 'results.generate')) return json(response, { error: 'Forbidden.' }, 403); const input = { ...query, resultType, studentId: query.studentId || null }; const status = resultBlocking?.getStatus ? await resultBlocking.getStatus(input, user) : { status: academicResults.blockFor?.(input)?.status === 'BLOCKED' ? 'BLOCKED' : 'UNBLOCKED' }; return json(response, status); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/academic/results/blocks' && request.method === 'GET') { if (!['PROPRIETOR', 'HEADTEACHER', 'ACCOUNTANT_BURSAR'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, { blocks: resultBlocking ? await resultBlocking.listBlocks(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user) : academicResults.listBlocks(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user) }); } catch (error) { return json(response, { error: error.message }, 403); } }
      if (pathname === '/api/academic/results/blocks' && request.method === 'POST') { if (!['TEACHER', 'HEADTEACHER', 'ACCOUNTANT_BURSAR'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { const body = await readJson(request); const affectedStudents = body.studentId ? 1 : (durableAcademic ? (await durableAcademic.resultStudents({ ...body, resultType: body.resultType ?? 'TERMINAL' }, user)).length : 0); const result = resultBlocking ? await resultBlocking.blockResults(body, user) : academicResults.blockResults(body, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'RESULTS_BLOCKED', entity: 'AcademicResultBlock', entityId: result.id, newValue: result })); return json(response, { ...result, affectedStudents }, 201); } catch (error) { return json(response, { error: error.message, code: error.code }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/academic/results/unblock' && request.method === 'POST') { if (!['PROPRIETOR', 'HEADTEACHER'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { const body = await readJson(request); const affectedStudents = body.studentId ? 1 : (durableAcademic ? (await durableAcademic.resultStudents({ ...body, resultType: body.resultType ?? 'TERMINAL' }, user)).length : 0); const result = resultBlocking?.unblockResults ? await resultBlocking.unblockResults(body, user) : academicResults.unblockResults(body, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'RESULTS_UNBLOCKED', entity: 'AcademicResultBlock', entityId: result.id, newValue: result })); return json(response, { ...result, affectedStudents }); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/academic/results/unblock-requests' && request.method === 'GET') { if (!['PROPRIETOR', 'HEADTEACHER'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, { requests: resultBlocking ? await resultBlocking.listUnblockRequests(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user) : academicResults.listUnblockRequests(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user) }); } catch (error) { return json(response, { error: error.message }, 403); } }
      if (pathname === '/api/academic/results/unblock-requests' && request.method === 'POST') { if (!['TEACHER', 'ACCOUNTANT_BURSAR', 'HEADTEACHER'].includes(user.roleKey)) return json(response, { error: 'Forbidden.' }, 403); try { const result = resultBlocking ? await resultBlocking.requestUnblock(await readJson(request), user) : academicResults.requestUnblock(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'RESULTS_UNBLOCK_REQUESTED', entity: 'AcademicResultUnblockRequest', entityId: result.id, newValue: result })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname.startsWith('/api/academic/results/unblock-requests/') && request.method === 'POST') { if (user.roleKey !== 'HEADTEACHER') return json(response, { error: 'Forbidden.' }, 403); try { const result = resultBlocking ? await resultBlocking.decideUnblock(pathname.split('/').filter(Boolean).at(-1), (await readJson(request)).decision, user) : academicResults.decideUnblock(pathname.split('/').filter(Boolean).at(-1), (await readJson(request)).decision, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: `RESULTS_UNBLOCK_${result.status}`, entity: 'AcademicResultUnblockRequest', entityId: result.id, newValue: result })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/mock-scores' && request.method === 'GET') { if (!canAccess(user, 'mock.scores.read') && !canAccess(user, 'mock.scores.write')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, { scores: durableAcademic ? await durableAcademic.listScores(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user, { mock: true }) : academicResults.listScores(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user, { mock: true }) }); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/mock-scores' && request.method === 'POST') { if (!canAccess(user, 'mock.scores.write')) return json(response, { error: 'Forbidden.' }, 403); try { const body = await readJson(request); let result; if (isSampleModeEnabled(body)) { const normalized = await normalizedSampleMockScoreInput(body, user); const roster = academicResults.mockScoreEntryRoster(normalized.input, normalized.actor); if (!roster.some((student) => String(student.studentId) === String(body.studentId) && student.isTestRecord)) throw Object.assign(new Error('Student is not in the selected sample Mock Score roster.'), { status: 400 }); result = academicResults.saveMockScore({ ...normalized.input, studentId: body.studentId }, normalized.actor); } else result = durableAcademic ? await durableAcademic.saveMockScore(body, user) : academicResults.saveMockScore(body, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'MOCK_SCORE_SAVED', entity: 'MockAcademicScore', entityId: result.id })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/academic/sample/mock-generate' && request.method === 'POST') { if (user.portal !== 'school' || (!canAccess(user, 'mock.scores.write') && !canAccess(user, 'mock.results.generate'))) return json(response, { error: 'Forbidden.' }, 403); try { students.seedSampleStudents?.(); const result = sampleResults.generateMock(await readJson(request), user); const sampleLifecycle = await sampleResults.persistGeneratedState(result, user); return json(response, { result: { ...result, sampleLifecycle } }, 201); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/sample/mock-reset' && request.method === 'POST') { if (user.portal !== 'school' || !canAccess(user, 'mock.scores.write')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, await sampleResults.resetMock(await readJson(request), user)); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/sample/generate' && request.method === 'POST') { if (user.portal !== 'school' || (!canAccess(user, 'results.generate') && !canAccess(user, 'marks.write'))) return json(response, { error: 'Forbidden.' }, 403); try { students.seedSampleStudents?.(); const { input: sampleInput, className } = await normalizedSampleResultInput(await readJson(request), user); const result = sampleResults.generate(sampleInput, user); const sampleLifecycle = await sampleResults.persistGeneratedState(result, user); return json(response, { result: { ...result, classId: className, academicYear: sampleInput.academicYear, term: sampleInput.term, studentIndexNumber: result.studentIndexNumber ?? result.permanentStudentId, sampleLifecycle } }, 201); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/sample/result/pdf' && request.method === 'POST') {
        try {
          const body = await readJson(request);
          const sampleStudentId = String(body.sampleStudentId ?? '').trim();
          if (!isConfiguredTestStudentId(sampleStudentId)) return json(response, { error: 'A configured sample student is required.' }, 400);
          const isMock = String(body.resultType ?? '').toUpperCase() === 'MOCK';
          if (isMock ? (!canAccess(user, 'mock.results.generate') && !canAccess(user, 'mock.scores.write')) : (!canAccess(user, 'results.generate') && !canAccess(user, 'marks.write'))) return json(response, { error: 'Forbidden.' }, 403);
          if (user.portal !== 'school') return json(response, { error: 'Forbidden.' }, 403);
          students.seedSampleStudents?.();
          const { input, className } = await normalizedSampleResultInput({ ...body, studentId: sampleStudentId, examinationType: isMock ? 'MOCK' : 'TERMINAL' }, user);
          const generated = isMock
            ? sampleResults.generateMock({ ...input, mockLabel: body.mockLabel || '1st Mock' }, user)
            : sampleResults.generate(input, user);
          await sampleResults.persistGeneratedState(generated, user);
          const result = { ...generated, isSample: true, classId: className, academicYear: input.academicYear, term: input.term, studentIndexNumber: generated.studentIndexNumber ?? generated.permanentStudentId };
          const buffer = await resultPdf.pdf(result);
          response.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${resultPdf.filename(result)}"`, 'Content-Length': buffer.length, 'Cache-Control': 'no-store' });
          return response.end(buffer);
        } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); }
      }
      if (pathname === '/api/academic/sample/publish' && request.method === 'POST') { if (user.portal !== 'school' || !canAccess(user, 'results.publish')) return json(response, { error: 'Forbidden.' }, 403); try { const { input } = await normalizedSampleResultInput(await readJson(request), user); return json(response, await sampleResults.publish(input, user)); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/sample/state' && request.method === 'GET') { if (user.portal !== 'school') return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const isMock = String(query.examinationType ?? '').toUpperCase() === 'MOCK'; const canRead = canAccess(user, 'results.read') || canAccess(user, 'results.generate') || canAccess(user, 'results.publish') || isMock && (canAccess(user, 'mock.scores.read') || canAccess(user, 'mock.scores.write') || canAccess(user, 'mock.results.read')); if (!canRead) return json(response, { error: 'Forbidden.' }, 403); const { input } = await normalizedSampleResultInput(query, user); return json(response, { sample: await sampleResults.state({ ...input, permanentStudentId: query.permanentStudentId, examinationType: query.examinationType ?? 'TERMINAL', mockLabel: query.mockLabel }, user) }); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/academic/sample/reset' && request.method === 'POST') { if (user.portal !== 'school' || !canAccess(user, 'results.publish')) return json(response, { error: 'Forbidden.' }, 403); try { const { input } = await normalizedSampleResultInput(await readJson(request), user); return json(response, await sampleResults.reset(input, user)); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      async function assertResultReadable(query, actor) {
        const input = { ...query, studentId: query.studentId ?? null };
        if (resultBlocking?.assertReadable) return resultBlocking.assertReadable(input, actor);
        const block = academicResults.blockFor?.(input);
        if (block?.status === 'BLOCKED') throw Object.assign(new Error('This result is temporarily blocked by the school. Please contact the school office.'), { status: 403, code: 'RESULT_BLOCKED' });
      }
      if (pathname === '/api/academic/result/pdf' && request.method === 'GET') { if (!canAccess(user, 'results.read') && !canAccess(user, 'results.generate')) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); await assertResultReadable(query, user); const result = durableAcademic ? await durableAcademic.result(query, user) : academicResults.result(query, user); const buffer = await resultPdf.pdf(result); response.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${resultPdf.filename(result)}"`, 'Content-Length': buffer.length, 'Cache-Control': 'no-store' }); return response.end(buffer); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/academic/mock-result/pdf' && request.method === 'GET') { if (!canAccess(user, 'mock.results.read') && !canAccess(user, 'mock.results.generate')) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); await assertResultReadable({ ...query, resultType: 'MOCK' }, user); const result = durableAcademic ? await durableAcademic.result(query, user, { mock: true }) : academicResults.result(query, user, { mock: true }); const buffer = await resultPdf.pdf(result); response.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${resultPdf.filename(result)}"`, 'Content-Length': buffer.length, 'Cache-Control': 'no-store' }); return response.end(buffer); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/academic/result' && request.method === 'GET') { if (!canAccess(user, 'results.read') && !canAccess(user, 'results.generate')) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); await assertResultReadable(query, user); return json(response, { result: durableAcademic ? await durableAcademic.result(query, user) : academicResults.result(query, user) }); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/academic/mock-result' && request.method === 'GET') { if (!canAccess(user, 'mock.results.read') && !canAccess(user, 'mock.results.generate')) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); await assertResultReadable({ ...query, resultType: 'MOCK' }, user); return json(response, { result: durableAcademic ? await durableAcademic.result(query, user, { mock: true }) : academicResults.result(query, user, { mock: true }) }); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/academic/broadsheet' && request.method === 'GET') { if (!canAccess(user, 'results.read')) return json(response, { error: 'Forbidden.' }, 403); if (!durableAcademic && process.env.NODE_ENV === 'production' && !isSampleModeEnabled(new URL(request.url, 'http://localhost').searchParams)) return json(response, { error: 'Durable Broadsheet data is unavailable.' }, 503); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const sampleMode = isSampleModeEnabled(query); if (sampleMode && user.portal !== 'school') return json(response, { error: 'Forbidden.' }, 403); const rows = sampleMode ? sampleResults.broadsheet(query, user) : durableAcademic ? await durableAcademic.broadsheet(query, user) : academicResults.broadsheet(query, user, { mock: false }); return json(response, { rows }); } catch (error) { console.error('[Broadsheet] request failed', { schoolId: user.schoolId, userId: user.id, message: error.message }); return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/academic/mock-broadsheet' && request.method === 'GET') { if (!canAccess(user, 'mock.results.read')) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const sampleMode = isSampleModeEnabled(query); if (sampleMode && user.portal !== 'school') return json(response, { error: 'Forbidden.' }, 403); const rows = sampleMode ? sampleResults.broadsheet(query, user, { mock: true }) : durableAcademic ? await durableAcademic.mockBroadsheet(query, user) : academicResults.broadsheet(query, user, { mock: true }); return json(response, { rows }); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/academic/header' && request.method === 'GET') return json(response, { asset: RESULT_HEADER_ASSET });
      if (pathname === '/api/subjects/configure-defaults' && request.method === 'POST') { if (!canAccess(user, 'subjects.manage')) return json(response, { error: 'Forbidden.' }, 403); if (!durableAcademic) return json(response, { error: 'Database-backed subject configuration is unavailable.' }, 503); try { const result = await durableAcademic.configureDefaultSubjects(user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'DEFAULT_SUBJECTS_CONFIGURED', entity: 'SubjectConfiguration', entityId: String(result.configurationVersion), newValue: result })); return json(response, result); } catch (error) { console.error('[Subjects] default configuration failed', { schoolId: user.schoolId, userId: user.id, message: error.message, stack: error.stack }); return json(response, { error: error.message === 'Forbidden.' ? 'Forbidden.' : error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/subjects/configuration' && request.method === 'GET') { if (!canAccess(user, 'subjects.read') && !canAccess(user, 'subjects.manage') && !canAccess(user, 'academics.read')) return json(response, { error: 'Forbidden.' }, 403); if (!durableAcademic) return json(response, { error: 'Durable subject configuration is unavailable.' }, 503); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); return json(response, await durableAcademic.subjectConfiguration(user, query)); } catch (error) { return json(response, { error: error.message === 'Forbidden.' ? 'Forbidden.' : error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 500)); } }
      if (pathname === '/api/subjects' && request.method === 'GET') { if (!canAccess(user, 'subjects.read') && !canAccess(user, 'academics.read')) return json(response, { error: 'Forbidden.' }, 403); if (!durableAcademic && process.env.NODE_ENV === 'production') return json(response, { error: 'Durable subject data is unavailable.' }, 503); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const hasTermFilter = Boolean(query.termId || query.term); const hasYearFilter = Boolean(query.academicYearId || query.academicYear); const hasPeriodFilter = hasTermFilter || hasYearFilter; if (hasTermFilter && (!query.classId || !hasYearFilter)) return json(response, { error: 'Academic year, term, and class are all required to load registered subjects.' }, 400); if (hasYearFilter && !query.classId) return json(response, { error: 'Class is required when filtering subjects by academic year.' }, 400); let configured = durableAcademic ? (String(query.mock ?? '').toLowerCase() === 'true' ? await durableAcademic.mockSubjectCatalog(user) : (hasPeriodFilter ? (await durableAcademic.subjectCascade(query, user)).subjects : await durableAcademic.listSubjects(query, user))) : subjects.list(query, user); if (!durableAcademic && query.classId && query.academicYearId && query.termId) { const registered = subjectRegister?.registeredSubjects?.({ academicYearId: query.academicYearId, termId: query.termId, classId: query.classId }, user); if (registered) configured = configured.filter((subject) => registered.includes(subject.id)); } return json(response, { subjects: configured }); } catch (error) { console.error('[Subjects] list request failed', { schoolId: user.schoolId, userId: user.id, message: error.message, stack: error.stack }); return json(response, { error: error.message === 'Forbidden.' ? 'Forbidden.' : 'Unable to load subjects. Please try again.' }, error.status ?? (error.message === 'Forbidden.' ? 403 : 500)); } }
      if (pathname.match(/^\/api\/subjects\/[^/]+\/assignments$/) && request.method === 'GET') { if (!canAccess(user, 'subjects.read') && !canAccess(user, 'academics.read')) return json(response, { error: 'Forbidden.' }, 403); try { const subjectId = pathname.split('/')[3]; return json(response, { assignments: durableAcademic ? await durableAcademic.listAssignments(subjectId, user) : [] }); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.match(/^\/api\/subjects\/[^/]+\/assignments$/) && request.method === 'POST') { if (!canAccess(user, 'subjects.manage')) return json(response, { error: 'Forbidden.' }, 403); try { const subjectId = pathname.split('/')[3]; const result = durableAcademic ? await durableAcademic.assignSubject({ ...(await readJson(request)), subjectId }, user) : null; if (!result) return json(response, { error: 'Durable subject assignments are unavailable.' }, 503); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SUBJECT_ASSIGNED_TO_CLASS', entity: 'SubjectClassAssignment', entityId: result.id, newValue: result })); return json(response, result, result.created ? 201 : 200); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.match(/^\/api\/subjects\/[^/]+\/assignments$/) && request.method === 'DELETE') { if (!canAccess(user, 'subjects.manage')) return json(response, { error: 'Forbidden.' }, 403); try { if (!durableAcademic) return json(response, { error: 'Durable subject assignments are unavailable.' }, 503); const subjectId = pathname.split('/')[3]; const query = new URL(request.url, 'http://localhost').searchParams; const result = await durableAcademic.deactivateSubjectAssignment({ subjectId, classId: query.get('classId'), academicYearId: query.get('academicYearId') || query.get('academicYear') }, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SUBJECT_UNASSIGNED_FROM_CLASS', entity: 'SubjectClassAssignment', entityId: result.id, newValue: result })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/subjects' && request.method === 'POST') { if (!canAccess(user, 'subjects.manage')) return json(response, { error: 'Forbidden.' }, 403); if (!durableAcademic && process.env.NODE_ENV === 'production') return json(response, { error: 'Durable subject data is unavailable.' }, 503); try { const result = durableAcademic ? await durableAcademic.createSubject(await readJson(request), user) : subjects.create(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SUBJECT_CREATED', entity: 'Subject', entityId: result.id, newValue: result })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname.startsWith('/api/subjects/') && request.method === 'PATCH') { if (!canAccess(user, 'subjects.manage')) return json(response, { error: 'Forbidden.' }, 403); if (!durableAcademic && process.env.NODE_ENV === 'production') return json(response, { error: 'Durable subject data is unavailable.' }, 503); try { const result = durableAcademic ? await durableAcademic.updateSubject(pathname.split('/')[3], await readJson(request), user) : subjects.update(pathname.split('/')[3], await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SUBJECT_UPDATED', entity: 'Subject', entityId: result.id, newValue: result })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname.startsWith('/api/subjects/') && pathname.endsWith('/deactivate') && request.method === 'POST') { if (!canAccess(user, 'subjects.manage')) return json(response, { error: 'Forbidden.' }, 403); if (!durableAcademic && process.env.NODE_ENV === 'production') return json(response, { error: 'Durable subject data is unavailable.' }, 503); try { const result = durableAcademic ? await durableAcademic.deactivateSubject(pathname.split('/')[3], user) : subjects.deactivate(pathname.split('/')[3], user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SUBJECT_DEACTIVATED', entity: 'Subject', entityId: result.id, newValue: result })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/result-signatures' && request.method === 'GET') { if (!canAccess(user, 'signatures.manage')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { signatures: signatures.list(user), options: signatures.options(user) }); }
      if (pathname === '/api/result-signatures' && request.method === 'POST') { if (!canAccess(user, 'signatures.manage')) return json(response, { error: 'Forbidden.' }, 403); try { const result = signatures.upload(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'SIGNATURE_UPLOADED', entity: 'ResultSignature', entityId: result.id })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname.startsWith('/api/result-signatures/') && request.method === 'DELETE') { if (!canAccess(user, 'signatures.manage')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, signatures.remove(pathname.split('/')[3], user)); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/admission-prospectus' && request.method === 'GET') { if (user.portal !== 'parent' && !canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, { prospectuses: admissionProspectus.list(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user) }); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/admission-prospectus' && request.method === 'POST') { if (!canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); try { const result = admissionProspectus.create(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'PROSPECTUS_CREATED', entity: 'AdmissionProspectus', entityId: result.id })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname.startsWith('/api/admission-prospectus/') && request.method === 'GET') { const parts = pathname.split('/').filter(Boolean); if (parts[3] === 'document') { if (user.portal !== 'parent' && !canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); } else if (user.portal !== 'parent' && !canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); const result = admissionProspectus.get(parts[2], user); return result ? json(response, { prospectus: result }) : json(response, { error: 'Not found.' }, 404); }
      if (pathname.startsWith('/api/admission-prospectus/') && request.method === 'PATCH') { if (!canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); try { const result = admissionProspectus.update(pathname.split('/')[3], await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'PROSPECTUS_UPDATED', entity: 'AdmissionProspectus', entityId: result.id })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname.startsWith('/api/admission-prospectus/') && pathname.endsWith('/document') && request.method === 'POST') { if (!canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); try { const parts = pathname.split('/').filter(Boolean); const result = admissionProspectus.upload(parts[2], await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'PROSPECTUS_DOCUMENT_UPLOADED', entity: 'AdmissionProspectus', entityId: result.id })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname.startsWith('/api/admission-prospectus/') && pathname.endsWith('/replace') && request.method === 'POST') { if (!canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); try { const parts = pathname.split('/').filter(Boolean); const result = admissionProspectus.replaceDocument(parts[2], await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'PROSPECTUS_DOCUMENT_REPLACED', entity: 'AdmissionProspectus', entityId: result.id })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname.startsWith('/api/admission-prospectus/') && pathname.endsWith('/publish') && request.method === 'POST') { if (!canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); try { const result = admissionProspectus.publish(pathname.split('/')[3], user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'PROSPECTUS_PUBLISHED', entity: 'AdmissionProspectus', entityId: result.id })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname.startsWith('/api/admission-prospectus/') && pathname.endsWith('/unpublish') && request.method === 'POST') { if (!canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); try { const result = admissionProspectus.unpublish(pathname.split('/')[3], user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'PROSPECTUS_UNPUBLISHED', entity: 'AdmissionProspectus', entityId: result.id })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname.startsWith('/api/admission-prospectus/') && request.method === 'DELETE') { if (!canAccess(user, PROSPECTUS_PERMISSION)) return json(response, { error: 'Forbidden.' }, 403); try { const result = admissionProspectus.remove(pathname.split('/')[3], user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'PROSPECTUS_ARCHIVED', entity: 'AdmissionProspectus', entityId: pathname.split('/')[3] })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/staff-management' && request.method === 'GET') { if (user.portal !== 'school' || user.roleKey !== 'PROPRIETOR' && (user.roleKey !== 'SCHOOL_ADMIN' || !canAccess(user, 'staff.manage'))) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, { staff: await auth.listStaff(user.schoolId) }); } catch (error) { console.error('Staff directory lookup failed', { code: error?.code ?? 'UNKNOWN', errno: error?.errno ?? null, sqlState: error?.sqlState ?? null }); return json(response, { error: 'Staff directory is temporarily unavailable.', code: 'STAFF_DIRECTORY_UNAVAILABLE' }, 503); } }
      if (pathname === '/api/staff-directory' && request.method === 'GET') { if (!canAccess(user, 'staff.read')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, { staff: await auth.listStaff(user.schoolId) }); } catch (error) { console.error('Staff directory lookup failed', { code: error?.code ?? 'UNKNOWN', errno: error?.errno ?? null, sqlState: error?.sqlState ?? null }); return json(response, { error: 'Staff directory is temporarily unavailable.', code: 'STAFF_DIRECTORY_UNAVAILABLE' }, 503); } }
      if (pathname === '/api/staff-management' && request.method === 'POST') { if (user.portal !== 'school' || user.roleKey !== 'PROPRIETOR' && (user.roleKey !== 'SCHOOL_ADMIN' || !canAccess(user, 'staff.manage'))) return json(response, { error: 'Forbidden.' }, 403); try { const input = await readJson(request); const requestedRole = String(input.primaryRole ?? input.roleKey ?? '').trim().toUpperCase().replace(/[\s-]+/g, '_'); if (['SCHOOL_ADMIN', 'ADMINISTRATOR'].includes(requestedRole) && user.roleKey !== 'PROPRIETOR') return json(response, { error: 'Only the proprietor can create a School Administrator.' }, 403); const result = await auth.registerStaff(input, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'STAFF_CREATED', entity: 'StaffAccount', entityId: result.staff.id, newValue: result.staff })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/staff-management/')) { if (user.portal !== 'school' || user.roleKey !== 'PROPRIETOR' && (user.roleKey !== 'SCHOOL_ADMIN' || !canAccess(user, 'staff.manage'))) return json(response, { error: 'Forbidden.' }, 403); const parts = pathname.split('/').filter(Boolean); const targetId = parts[2]; if (request.method === 'GET' && parts.length === 3) return json(response, { staff: await auth.getStaff(targetId, user.schoolId) }); if (parts[3] === 'disable' && request.method === 'POST') { if (targetId === user.id) return json(response, { error: 'You cannot deactivate the account currently managing the system.' }, 409); const ok = await auth.setAccountStatus(targetId, false, user.schoolId); if (!ok) return json(response, { error: 'Not found.' }, 404); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'STAFF_DISABLED', entity: 'StaffAccount', entityId: targetId })); return json(response, { ok: true }); } if (parts[3] === 'revoke' && request.method === 'POST') { if (targetId === user.id) return json(response, { error: 'You cannot remove the account currently managing the system.' }, 409); const ok = await auth.revokeAccount(targetId, user.schoolId); if (!ok) return json(response, { error: 'Not found.' }, 404); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'STAFF_REVOKED', entity: 'StaffAccount', entityId: targetId })); return json(response, { ok: true }); } if (parts[3] === 'reset-credentials' && request.method === 'POST') { const result = await auth.resetStaffCredentials(targetId, user.schoolId); if (!result) return json(response, { error: 'Not found.' }, 404); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'STAFF_CREDENTIAL_RESET', entity: 'StaffAccount', entityId: targetId })); return json(response, result); } if (parts[3] === 'role' && request.method === 'POST') { try { const body = await readJson(request); const requestedRole = String(body.primaryRole ?? body.roleKey ?? '').trim().toUpperCase().replace(/[\s-]+/g, '_'); if (['SCHOOL_ADMIN', 'ADMINISTRATOR'].includes(requestedRole) && user.roleKey !== 'PROPRIETOR') return json(response, { error: 'Only the proprietor can assign School Administrator access.' }, 403); const result = await auth.changeStaffRole(targetId, body.primaryRole ?? body.roleKey, user.schoolId); if (!result) return json(response, { error: 'Invalid staff or role.' }, 400); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'STAFF_ROLE_CHANGED', entity: 'StaffAccount', entityId: targetId, previousValue: { role: result.previousRole }, newValue: { role: result.newRole } })); return json(response, result); } catch (error) { return json(response, { error: error.message }, 400); } } if (parts[3] === 'assignment' && request.method === 'POST') { const result = await auth.assignStaff(targetId, await readJson(request), user.schoolId); if (!result) return json(response, { error: 'Not found.' }, 404); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'STAFF_UPDATED', entity: 'StaffAccount', entityId: targetId, newValue: result })); return json(response, { staff: result }); } if (request.method === 'PATCH' && parts.length === 3) { try { const result = await auth.updateStaff(targetId, await readJson(request), user.schoolId); if (!result) return json(response, { error: 'Not found.' }, 404); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'STAFF_UPDATED', entity: 'StaffAccount', entityId: targetId, newValue: result })); return json(response, { staff: result }); } catch (error) { return json(response, { error: error.message }, 400); } } return json(response, { error: 'Not found.' }, 404); }
      if (pathname === '/api/administrators' && request.method === 'GET') { if (user.roleKey !== 'PROPRIETOR') return json(response, { error: 'Forbidden.' }, 403); return json(response, { administrators: await auth.listAdministrators(user.schoolId) }); }
      if (pathname === '/api/administrator-credentials/reset' && request.method === 'POST') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401);
        if (user.roleKey !== 'PROPRIETOR') return json(response, { error: 'Forbidden.' }, 403);
        try {
          const body = await readJson(request);
          if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).some((key) => !['email', 'newPassword'].includes(key))) return json(response, { error: 'Only email and newPassword are accepted.' }, 400);
          const result = await auth.resetAdministratorCredentialsByEmail(body.email, body.newPassword, user.schoolId);
          if (!result) return json(response, { error: 'Not found.' }, 404);
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'ADMINISTRATOR_CREDENTIAL_RESET', entity: 'User', entityId: result.userId, newValue: { passwordUpdated: true, sessionsRevoked: result.sessionsRevoked } }));
          return json(response, { ok: true, sessionsRevoked: result.sessionsRevoked });
        } catch (error) {
          const safeCodes = new Set(['INVALID_PASSWORD', 'INVALID_EMAIL', 'INVALID_SCHOOL', 'ADMINISTRATOR_NOT_FOUND', 'AMBIGUOUS_ADMINISTRATOR', 'ADMINISTRATOR_CHANGED', 'PERSISTENCE_UNAVAILABLE']);
          const safe = safeCodes.has(error?.code);
          return json(response, { error: safe ? error.message : 'Administrator credential reset failed.', code: safe ? error.code : 'ADMINISTRATOR_CREDENTIAL_RESET_FAILED' }, safe ? error.status : 500);
        }
      }
      if (pathname === '/api/administrators' && request.method === 'POST') { if (user.roleKey !== 'PROPRIETOR') return json(response, { error: 'Forbidden.' }, 403); try { const result = await auth.createAdministrator(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'ADMINISTRATOR_CREATED', entity: 'AdministratorAssignment', entityId: result.administrator.id, newValue: result.administrator })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message, code: error.code }, error.status ?? 400); } }
      if (pathname.startsWith('/api/administrators/')) { if (user.roleKey !== 'PROPRIETOR') return json(response, { error: 'Forbidden.' }, 403); const parts = pathname.split('/').filter(Boolean); const targetId = parts[2]; const target = await auth.getAdministrator(targetId, user.schoolId); if (!target) return json(response, { error: 'Not found.' }, 404); if (request.method === 'GET' && parts.length === 3) return json(response, { administrator: target }); if (parts[3] === 'disable' && request.method === 'POST') { if (targetId === user.id) return json(response, { error: 'You cannot deactivate the account currently managing the system.' }, 409); const ok = await auth.setAccountStatus(targetId, false, user.schoolId); if (!ok) return json(response, { error: 'Not found.' }, 404); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'ADMINISTRATOR_DISABLED', entity: 'AdministratorAssignment', entityId: targetId })); return json(response, { ok: true }); } if (parts[3] === 'revoke' && request.method === 'POST') { if (targetId === user.id) return json(response, { error: 'You cannot remove the account currently managing the system.' }, 409); const ok = await auth.revokeAccount(targetId, user.schoolId); if (!ok) return json(response, { error: 'Not found.' }, 404); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'ADMINISTRATOR_REVOKED', entity: 'AdministratorAssignment', entityId: targetId })); return json(response, { ok: true }); } if (parts[3] === 'reset-credentials' && request.method === 'POST') { const result = await auth.resetAdministratorCredentials(targetId, user.schoolId); if (!result) return json(response, { error: 'Not found.' }, 404); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'ADMINISTRATOR_CREDENTIAL_RESET', entity: 'AdministratorAssignment', entityId: targetId })); return json(response, result); } if (request.method === 'PATCH' && parts.length === 3) { try { const result = await auth.updateAdministrator(targetId, await readJson(request), user.schoolId); if (!result) return json(response, { error: 'Not found.' }, 404); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'ADMINISTRATOR_UPDATED', entity: 'AdministratorAssignment', entityId: targetId, newValue: result })); return json(response, { administrator: result }); } catch (error) { return json(response, { error: error.message }, 400); } } return json(response, { error: 'Not found.' }, 404); }
      if (pathname === '/api/sidebar/health') { if (!canAccess(user, 'users.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, sidebarHealth()); }
      if (pathname === '/api/students/link-existing' && request.method === 'POST') {
        if (!existingStudentLinking) return json(response, { error: 'Existing-student linking persistence is unavailable.' }, 503);
        try {
          const result = await existingStudentLinking.link(await readJson(request), user);
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'EXISTING_STUDENT_LINKED', entity: 'Student', entityId: result.student.id, newValue: { createdProfile: result.createdProfile, createdEnrollment: result.createdEnrollment, permanentStudentId: result.student.permanentStudentId } }));
          return json(response, result, result.createdEnrollment || result.createdProfile ? 201 : 200);
        } catch (error) { return json(response, { error: error.message, code: error.code }, error.status ?? 400); }
      }
      if (pathname === '/api/students' && request.method === 'POST') { if (!canAccess(user, 'students.write')) return json(response, { error: 'Forbidden.' }, 403); const student = students.createStudent({ ...(await readJson(request)), schoolId: user.schoolId }); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'Student', entityId: student.id, newValue: student })); return json(response, student, 201); }
      if (pathname === '/api/students/search') { if (!canAccess(user, 'students.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { students: durableStudentProfile ? await durableStudentProfile.search(new URL(request.url, 'http://localhost').searchParams.get('q'), user) : students.search(new URL(request.url, 'http://localhost').searchParams.get('q'), { ...user, requestedSchoolId: user.schoolId }) }); }
      if (pathname === '/api/students/master-record' && request.method === 'GET') { if (!canAccess(user, 'students.read')) return json(response, { error: 'Forbidden.' }, 403); const permanentStudentId = new URL(request.url, 'http://localhost').searchParams.get('permanentStudentId'); const record = students.academicMasterRecord(permanentStudentId, { actor: user, attendance, results: academicResults, fees }); return record ? json(response, record) : json(response, { error: 'Not found.' }, 404); }
      if (pathname === '/api/attendance/options' && request.method === 'GET') {
        if (user.portal === 'parent' || (!canAccess(user, 'attendance.read') && !canAccess(user, 'staff.attendance.read'))) return attendanceApiFailure(response, Object.assign(new Error('Forbidden.'), { status: 403, code: 'ATTENDANCE_FORBIDDEN' }), '/api/attendance/options', user);
        try {
          let academicYears, terms, classes;
          if (!database?.query) {
            academicYears = ACADEMIC_YEAR_OPTIONS.map((name) => ({ id: name, name }));
            terms = TERM_OPTIONS.map((name) => ({ id: name, name }));
            classes = await attendanceClassOptions(user);
          } else {
            [academicYears, terms, classes] = await Promise.all([
              database.query('SELECT id,name,starts_on AS startsOn,ends_on AS endsOn,is_current AS isCurrent FROM academic_years WHERE school_id=? ORDER BY starts_on DESC,id', [user.schoolId]),
              database.query('SELECT t.id,t.academic_year_id AS academicYearId,t.name,t.starts_on AS startsOn,t.ends_on AS endsOn,t.is_current AS isCurrent FROM terms t JOIN academic_years y ON y.id=t.academic_year_id WHERE y.school_id=? ORDER BY t.starts_on ASC,t.id', [user.schoolId]),
              attendanceClassOptions(user)
            ]);
          }
          const data = { today: await attendanceRegister.today(user), academicYears, terms, classes, canCorrect: canAccess(user, 'attendance.correct') };
          return json(response, { success: true, data, ...data, message: 'Attendance options loaded successfully.' });
        } catch (error) { return attendanceApiFailure(response, error, '/api/attendance/options', user); }
      }
      if (pathname === '/api/attendance/reports/canonical' && request.method === 'GET') { const reportType = new URL(request.url, 'http://localhost').searchParams.get('reportType')?.toUpperCase(); if (user.portal === 'parent' || !(reportType === 'STAFF' ? canAccess(user, 'attendance.read') && canAccess(user, 'staff.attendance.read') : canAccess(user, 'attendance.read'))) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; const filters = Object.fromEntries(['reportType', 'period', 'academicYear', 'term', 'classId', 'date', 'week', 'month', 'startDate', 'endDate', 'gender', 'status', 'role'].map((key) => [key, query.get(key) ?? undefined])); try { return json(response, await attendanceReports.report(filters, user)); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'ATTENDANCE_REPORT_ERROR' }, error.status ?? 400); } }
      if (pathname === '/api/attendance/reports/export' && request.method === 'GET') { const reportType = new URL(request.url, 'http://localhost').searchParams.get('reportType')?.toUpperCase(); if (user.portal === 'parent' || !(reportType === 'STAFF' ? canAccess(user, 'attendance.read') && canAccess(user, 'staff.attendance.read') : canAccess(user, 'attendance.read'))) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; const format = query.get('format') ?? 'PDF'; const filters = Object.fromEntries(['reportType', 'period', 'academicYear', 'term', 'classId', 'date', 'week', 'month', 'startDate', 'endDate', 'gender', 'status', 'role'].map((key) => [key, query.get(key) ?? undefined])); try { const exported = await attendanceReports.exportReport(filters, user, format); response.writeHead(200, { 'Content-Type': exported.contentType, 'Content-Disposition': `attachment; filename="${exported.filename}"`, 'Content-Length': exported.content.length, 'Cache-Control': 'no-store' }); return response.end(exported.content); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'ATTENDANCE_REPORT_EXPORT_ERROR' }, error.status ?? 400); } }
      if (pathname === '/api/attendance/reports/print' && request.method === 'GET') { const reportType = new URL(request.url, 'http://localhost').searchParams.get('reportType')?.toUpperCase(); if (user.portal === 'parent' || !(reportType === 'STAFF' ? canAccess(user, 'attendance.read') && canAccess(user, 'staff.attendance.read') : canAccess(user, 'attendance.read'))) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; const filters = Object.fromEntries(['reportType', 'period', 'academicYear', 'term', 'classId', 'date', 'week', 'month', 'startDate', 'endDate', 'gender', 'status', 'role'].map((key) => [key, query.get(key) ?? undefined])); try { const report = await attendanceReports.report(filters, user); const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character])); const headers = Object.keys(report.rows?.[0] ?? { message: 'No observations' }); const body = (report.rows?.length ? report.rows : [{ message: 'No authoritative observations for this scope.' }]).map((row) => `<tr>${headers.map((header) => `<td>${escapeHtml(row[header])}</td>`).join('')}</tr>`).join(''); const html = `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(report.title)}</title><style>body{font:12px Arial;color:#111;margin:28px}h1{margin:0 0 4px}p{color:#555}.meta{border-bottom:2px solid #102a43;padding-bottom:12px;margin-bottom:16px}table{border-collapse:collapse;width:100%;font-size:10px}th,td{border:1px solid #bbb;padding:5px;text-align:left;vertical-align:top}th{background:#eef2f5}@media print{button{display:none}}</style></head><body><button onclick="window.print()">Print</button><div class="meta"><h1>${escapeHtml(report.school.name)}</h1><h2>${escapeHtml(report.title)}</h2><p>${escapeHtml(report.period.label)} · ${escapeHtml(report.filters.academicYear ?? 'All academic years')} · ${escapeHtml(report.filters.term ?? 'All terms')}</p><p>Generated ${escapeHtml(report.generatedAt)} · Source: ${escapeHtml(report.source)}</p></div><table><thead><tr>${headers.map((header) => `<th>${escapeHtml(header)}</th>`).join('')}</tr></thead><tbody>${body}</tbody></table></body></html>`; response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); return response.end(html); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'ATTENDANCE_REPORT_PRINT_ERROR' }, error.status ?? 400); } }
      if (pathname === '/api/attendance/reports' && request.method === 'GET') { if (user.portal === 'parent' || !canAccess(user, 'attendance.read')) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; const filters = Object.fromEntries(['period', 'academicYear', 'term', 'classId', 'date', 'week', 'month'].map((key) => [key, query.get(key) ?? undefined])); try { const rows = attendanceRepository ? await attendanceRepository.listStudentRecords({ schoolId: user.schoolId }) : attendance.listStudentRecords().filter((record) => record.schoolId === user.schoolId); const source = { listStudentRecords: () => rows }; const report = createAttendanceAggregationService({ attendance: source, students, schoolId: user.schoolId }).report(filters); return json(response, report); } catch (error) { return json(response, { error: error.message }, 400); } }
      if (pathname === '/api/attendance/register' && request.method === 'GET') {
        if (user.portal === 'parent' || !canAccess(user, 'attendance.read')) return attendanceApiFailure(response, Object.assign(new Error('Forbidden.'), { status: 403, code: 'ATTENDANCE_FORBIDDEN' }), '/api/attendance/register', user);
        try {
          const query = new URL(request.url, 'http://localhost').searchParams;
          const requestedClassId = query.get('classId');
          const academicYear = query.get('academicYear');
          const term = query.get('term');
          const date = query.get('date');
          const sampleMode = query.get('sampleMode') === 'true';
          if (!requestedClassId || !academicYear || !term || !date) throw Object.assign(new Error('Class, Academic Year, Term, and Date are required.'), { status: 400, code: 'ATTENDANCE_SCOPE_REQUIRED' });
          const period = await attendanceRegister.resolvePeriod({ schoolId: user.schoolId, academicYear, term, date });
          const classOption = await resolveAttendanceClass(user, requestedClassId);
          if (!classOption) throw Object.assign(new Error('Class not found.'), { status: 404, code: 'ATTENDANCE_CLASS_NOT_FOUND' });
          const classId = String(classOption.id);
          const canonicalClass = canonicalClassId(classOption.name) ?? classOption.name;
          const assigned = (user.assignedClassIds ?? []).map((value) => canonicalClassId(value) ?? String(value));
          if (user.roleKey === 'TEACHER' && (!assigned.length || (!assigned.includes(classId) && !assigned.includes(String(classOption.name)) && !assigned.includes(canonicalClass)))) throw Object.assign(new Error('Forbidden.'), { status: 403, code: 'ATTENDANCE_CLASS_FORBIDDEN' });
          const rows = await attendanceRegister.enrolledStudents({ schoolId: user.schoolId, classId, className: classOption.name, canonicalClassName: canonicalClass, period, sampleMode, actor: user });
          let existingAttendance = [];
          if (sampleMode) {
            const sampleStudents = students.listStudents({ requestedSchoolId: user.schoolId, includeTestRecords: true }).filter((student) => student.isTestRecord && rows.some((row) => row.studentId === student.id));
            const fixtureRecords = await Promise.all(sampleStudents.map(async (student) => attendanceRegister.savedSampleAttendance({ student, classId, period, actor: user })));
            const studentByPermanentId = new Map(sampleStudents.map((student) => [student.permanentStudentId, student.id]));
            existingAttendance = fixtureRecords.flat().map((record) => ({ ...record, studentId: studentByPermanentId.get(record.permanentStudentId ?? record.studentId) ?? record.studentId }));
          } else if (attendanceRepository) {
            existingAttendance = await attendanceRepository.listStudentRecords({ schoolId: user.schoolId, academicYear: period.yearName, term: period.termName, date, classId });
          } else {
            const sameClass = (value) => String(value ?? '') === classId || String(value ?? '') === String(classOption.name) || canonicalClassId(value) === canonicalClass;
            existingAttendance = attendance.listStudentRecords().filter((record) => record.schoolId === user.schoolId && record.academicYear === period.yearName && record.term === period.termName && record.date === date && sameClass(record.classId));
          }
          const existingByStudent = new Map(existingAttendance.map((record) => [record.studentId, record]));
          const register = rows.map((student, index) => {
            const saved = existingByStudent.get(student.studentId);
            return { number: index + 1, studentId: student.studentId, permanentStudentId: student.permanentStudentId, studentName: [student.firstName, student.middleName, student.surname].filter(Boolean).join(' '), gender: student.gender ?? null, attendanceDate: date, status: saved?.status ?? '', reason: saved?.reason ?? null, arrivalTime: saved?.arrivalTime ?? null, departureTime: saved?.departureTime ?? null, version: saved?.version ?? null, isTestRecord: Boolean(student.isTestRecord) };
          });
          const data = { classId, className: classOption.name, academicYear: period.yearName, term: period.termName, date, sampleMode, canCorrect: canAccess(user, 'attendance.correct'), register };
          return json(response, { success: true, data, ...data, message: 'Register loaded successfully.' });
        } catch (error) { return attendanceApiFailure(response, error, '/api/attendance/register', user); }
      }
      if (pathname === '/api/attendance/students' && request.method === 'POST') { if (user.portal === 'parent' || !canAccess(user, 'attendance.write')) return json(response, { error: 'Forbidden.' }, 403); const body = await readJson(request); const correction = Boolean(body.correction); if (correction && !canAccess(user, 'attendance.correct')) return json(response, { error: 'Attendance corrections require authorization.' }, 403); const enrolled = students.getStudent(body.studentId, { requestedSchoolId: user.schoolId }); if (!enrolled) return json(response, { error: 'Student not found.' }, 404); if (enrolled.isTestRecord && attendanceRepository) return attendanceApiFailure(response, Object.assign(new Error('Use the isolated Sample / Test attendance register for sample students.'), { status: 400, code: 'ATTENDANCE_SAMPLE_MODE_REQUIRED' }), '/api/attendance/students', user); const historicalEnrollment = enrolled.history?.find((entry) => String(entry.academicYearId ?? '') === String(body.academicYear) && String(entry.termId ?? '') === String(body.term) && entry.classId === body.classId); if (!enrolled.isTestRecord && !historicalEnrollment && enrolled.classId !== body.classId) return json(response, { error: 'Student is not enrolled in the selected historical class.' }, 400); const input = { ...body, schoolId: user.schoolId, isTestRecord: Boolean(enrolled.isTestRecord) }; const record = attendanceRepository ? await attendanceRepository.saveStudentAttendance(input, user, { correction, expectedVersion: body.expectedVersion ?? null }) : attendance.saveStudentAttendance(input, user, { correction, expectedVersion: body.expectedVersion ?? null }); if (!record.isTestRecord && record.provenance !== 'TEST') dispatchAttendanceNotification(record, { correction }); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: correction ? 'CORRECT' : 'CREATE', entity: 'StudentAttendance', entityId: record.id, newValue: record })); return json(response, record, 201); }
      if (pathname === '/api/attendance/students/sync' && request.method === 'POST') {
        if (user.portal === 'parent' || !canAccess(user, 'attendance.write')) return attendanceApiFailure(response, Object.assign(new Error('Forbidden.'), { status: 403, code: 'ATTENDANCE_FORBIDDEN' }), '/api/attendance/students/sync', user);
        try {
          const body = await readJson(request);
          if (!Array.isArray(body.entries) || !body.entries.length || body.entries.length > 500) throw Object.assign(new Error('Provide between one and 500 attendance entries.'), { status: 400, code: 'ATTENDANCE_ENTRIES_INVALID' });
          const first = body.entries[0];
          const sameScope = body.entries.every((entry) => String(entry.classId) === String(first.classId) && String(entry.academicYear) === String(first.academicYear) && String(entry.term) === String(first.term) && String(entry.date) === String(first.date));
          if (!sameScope) throw Object.assign(new Error('A register save must use one class, academic year, term, and date.'), { status: 400, code: 'ATTENDANCE_SCOPE_MIXED' });
          const ids = body.entries.map((entry) => String(entry.studentId));
          if (new Set(ids).size !== ids.length) throw Object.assign(new Error('The register contains a duplicate student. Reload it before saving.'), { status: 400, code: 'ATTENDANCE_DUPLICATE_STUDENT' });
          const isSample = body.sampleMode === true;
          if (!isSample && body.entries.some((entry) => entry.version !== undefined && entry.version !== null && entry.version !== '') && !canAccess(user, 'attendance.correct')) throw Object.assign(new Error('Attendance corrections require authorization.'), { status: 403, code: 'ATTENDANCE_CORRECTION_FORBIDDEN' });
          const period = await attendanceRegister.resolvePeriod({ schoolId: user.schoolId, academicYear: first.academicYear, term: first.term, date: first.date });
          const classOption = await resolveAttendanceClass(user, first.classId);
          if (!classOption) throw Object.assign(new Error('Class not found.'), { status: 404, code: 'ATTENDANCE_CLASS_NOT_FOUND' });
          const canonicalClass = canonicalClassId(classOption.name) ?? classOption.name;
          const assigned = (user.assignedClassIds ?? []).map((value) => canonicalClassId(value) ?? String(value));
          if (user.roleKey === 'TEACHER' && (!assigned.length || (!assigned.includes(String(classOption.id)) && !assigned.includes(String(classOption.name)) && !assigned.includes(canonicalClass)))) throw Object.assign(new Error('Forbidden.'), { status: 403, code: 'ATTENDANCE_CLASS_FORBIDDEN' });
          const entries = [];
          for (const entry of body.entries) {
            const normalizedStatus = String(entry.status ?? '').toUpperCase();
            const normalizedMethod = String(entry.method ?? 'MANUAL').toUpperCase();
            if (!STUDENT_STATUSES.includes(normalizedStatus)) throw Object.assign(new Error('Choose a valid attendance status for every student.'), { status: 400, code: 'ATTENDANCE_STATUS_INVALID' });
            if (!ATTENDANCE_METHODS.includes(normalizedMethod)) throw Object.assign(new Error('Choose a valid attendance method for every student.'), { status: 400, code: 'ATTENDANCE_METHOD_INVALID' });
            if (STUDENT_REASON_STATUSES.includes(normalizedStatus) && !String(entry.reason ?? '').trim()) throw Object.assign(new Error(`A reason is required for ${normalizedStatus.replaceAll('_', ' ')}.`), { status: 400, code: 'ATTENDANCE_REASON_REQUIRED' });
            if (String(entry.reason ?? '').length > 500) throw Object.assign(new Error('Attendance reasons cannot exceed 500 characters.'), { status: 400, code: 'ATTENDANCE_REASON_TOO_LONG' });
            for (const [field, label] of [['arrivalTime', 'arrival'], ['departureTime', 'departure']]) if (entry[field] != null && entry[field] !== '' && !/^([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/.test(String(entry[field]))) throw Object.assign(new Error(`Invalid ${label} time.`), { status: 400, code: 'ATTENDANCE_TIME_INVALID' });
            if (entry.version !== undefined && entry.version !== null && entry.version !== '' && (!Number.isSafeInteger(Number(entry.version)) || Number(entry.version) < 1)) throw Object.assign(new Error('Attendance version is invalid. Reload the register before saving.'), { status: 400, code: 'ATTENDANCE_VERSION_INVALID' });
            const normalized = { ...entry, status: normalizedStatus, method: normalizedMethod, classId: String(classOption.id), academicYear: period.yearName, term: period.termName, date: period.date, source: isSample ? 'TEST' : 'MANUAL' };
            if (isSample) {
              const sample = students.getStudent(entry.studentId, { requestedSchoolId: user.schoolId });
              if (!sample?.isTestRecord) throw Object.assign(new Error('Sample / Test Mode accepts only configured sample students.'), { status: 400, code: 'ATTENDANCE_SAMPLE_STUDENT_INVALID' });
              normalized.isTestRecord = true;
            } else {
              if (attendanceRepository && !(await attendanceRegister.isEnrolled({ schoolId: user.schoolId, studentId: entry.studentId, classId: String(classOption.id), period }))) throw Object.assign(new Error('Student is not actively enrolled in the selected class and academic period.'), { status: 400, code: 'ATTENDANCE_ENROLLMENT_INVALID' });
              if (!attendanceRepository) {
                const student = students.getStudent(entry.studentId, { requestedSchoolId: user.schoolId });
                const enrolled = student && !student.isTestRecord && student.history?.some((item) => String(item.academicYearId ?? '') === String(period.yearName) && String(item.termId ?? '') === String(period.termName) && String(item.classId) === String(classOption.id));
                if (!enrolled) throw Object.assign(new Error('Student is not actively enrolled in the selected class and academic period.'), { status: 400, code: 'ATTENDANCE_ENROLLMENT_INVALID' });
              }
              normalized.isTestRecord = false;
            }
            entries.push(normalized);
          }
          let records;
          if (isSample) records = await attendanceRegister.saveSampleAttendance(entries, user, period);
          else if (attendanceRepository?.saveStudentAttendanceBatch) records = await attendanceRepository.saveStudentAttendanceBatch(entries, user, (entry) => ({ correction: entry.version !== undefined && entry.version !== null && entry.version !== '', expectedVersion: entry.version == null || entry.version === '' ? null : Number(entry.version) }));
          else {
            const saveOptions = (entry) => ({ correction: entry.version !== undefined && entry.version !== null && entry.version !== '', expectedVersion: entry.version == null || entry.version === '' ? null : Number(entry.version) });
            for (const entry of entries) if (!entry.isTestRecord) {
              const prior = attendance.getRecord(entry);
              const options = saveOptions(entry);
              if (prior && !options.correction) throw Object.assign(new Error('Attendance already recorded. Reload the register before saving.'), { status: 409, code: 'ATTENDANCE_DUPLICATE' });
              if (prior && options.expectedVersion !== null && Number(prior.version) !== Number(options.expectedVersion)) throw Object.assign(new Error('Attendance conflict: the server record is newer. Reload the register before saving.'), { status: 409, code: 'ATTENDANCE_VERSION_CONFLICT' });
              if (!prior && options.expectedVersion !== null) throw Object.assign(new Error('Attendance conflict: the server record changed. Reload the register before saving.'), { status: 409, code: 'ATTENDANCE_VERSION_CONFLICT' });
            }
            records = entries.map((entry) => attendance.saveStudentAttendance(entry, user, saveOptions(entry)));
          }
          records.filter((record) => !record.isTestRecord && record.provenance !== 'TEST').forEach((record) => dispatchAttendanceNotification(record, { correction: true }));
          records.forEach((record) => audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: record.isTestRecord ? 'SAMPLE_ATTENDANCE_SAVED' : 'ATTENDANCE_SAVED', entity: record.isTestRecord ? 'SampleStudentAttendance' : 'StudentAttendance', entityId: record.id, newValue: { date: record.date, classId: record.classId, version: record.version, status: record.status } })));
          return json(response, { success: true, data: { synced: records }, synced: records, message: `${records.length} attendance record(s) saved successfully.` });
        } catch (error) { return attendanceApiFailure(response, error, '/api/attendance/students/sync', user); }
      }
      if (pathname === '/api/class-database/options' && request.method === 'GET') { try { const options = classDatabase.options(user); const academicYears = database?.query ? (await feeSetupOptions(user)).academicYears.map((item) => item.name ?? item.id) : ['2024/2025', '2025/2026', '2026/2027', '2027/2028', '2028/2029']; return json(response, { ...options, academicYears: academicYears.length ? academicYears : options.academicYears }); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/class-database' && request.method === 'GET') { try { const query = new URL(request.url, 'http://localhost').searchParams; return json(response, { rows: await durableClassDatabaseList({ classId: query.get('classId') ?? '', academicYear: query.get('academicYear') ?? '', search: query.get('search') ?? '' }, user) }); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/class-database/completed/options' && request.method === 'GET') { try { return json(response, classDatabase.completedOptions(user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/class-database/completed' && request.method === 'GET') { try { const query = new URL(request.url, 'http://localhost').searchParams; return json(response, { rows: classDatabase.listCompleted({ completionYear: query.get('completionYear') ?? '', search: query.get('search') ?? '' }, user) }); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/fee-setup/options' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { return json(response, await feeSetupOptions(user)); } catch (error) { audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'FEE_SETUP_OPTIONS_FAILED', entity: 'FeeSetup', newValue: { code: error.code ?? 'OPTIONS_UNAVAILABLE' } })); return json(response, { error: error.status === 403 ? 'Forbidden.' : 'Unable to load Fee Setup data. Please try again.' }, error.status ?? 503); } }
      if (pathname === '/api/fees/structures' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { authorizeFinancial(user, 'READ', 'feeStructures'); const query = new URL(request.url, 'http://localhost').searchParams; const status = query.get('status') ?? 'PUBLISHED'; const academicYearId = query.get('academicYearId') ?? ''; const termId = query.get('termId') ?? ''; if (database?.query && academicYearId) { const years = await database.query('SELECT id FROM academic_years WHERE id=? AND school_id=?', [academicYearId, user.schoolId]); if (!years.length) return json(response, { error: 'Invalid academic year context.', code: 'INVALID_ACADEMIC_CONTEXT' }, 400); } if (database?.query && termId) { const terms = academicYearId ? await database.query('SELECT id FROM terms WHERE id=? AND academic_year_id=?', [termId, academicYearId]) : await database.query('SELECT t.id FROM terms t JOIN academic_years y ON y.id=t.academic_year_id WHERE t.id=? AND y.school_id=?', [termId, user.schoolId]); if (!terms.length) return json(response, { error: 'Invalid term context.', code: 'INVALID_ACADEMIC_CONTEXT' }, 400); } if (status.toUpperCase() === 'PUBLISHED' && feeCollections?.listPublishedFeeStructures) { const structures = await feeCollections.listPublishedFeeStructures({ academicYearId, termId }, user); return json(response, { structures }); } const structures = (fees.listStructures?.(user) ?? []).filter((item) => (!status || String(item.status ?? '').toUpperCase() === String(status).toUpperCase()) && (!academicYearId || item.academicYearId === academicYearId) && (!termId || item.termId === termId)); return json(response, { structures }); } catch (error) { const safe = safeFeeError(error); return json(response, { ...safe.body, code: error.code ?? 'FEE_STRUCTURE_READ_FAILED' }, safe.status); } }
      if (pathname === '/api/fees/invoices' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { authorizeFinancial(user, 'READ', 'invoices'); const query = new URL(request.url, 'http://localhost').searchParams; const studentId = query.get('studentId'); const status = query.get('status'); const invoices = fees.listInvoices(user).filter((item) => (!studentId || item.studentId === studentId || item.permanentStudentId === studentId) && (!status || item.status === status)); return json(response, { invoices }); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/fees/payments' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const query = new URL(request.url, 'http://localhost').searchParams; const filters = { studentId: query.get('studentId'), status: query.get('status') }; const payments = durableFeeReader ? await durableFeeReader.listPayments(filters, user) : (authorizeFinancial(user, 'READ', 'payments'), fees.listPayments(user).filter((item) => (!filters.studentId || item.studentId === filters.studentId || item.permanentStudentId === filters.studentId) && (!filters.status || item.status === filters.status))); return json(response, { payments }); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/fees/receipts' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const query = new URL(request.url, 'http://localhost').searchParams; const filters = { studentId: query.get('studentId'), status: query.get('status') }; const receipts = durableFeeReader ? await durableFeeReader.listReceipts(filters, user) : (authorizeFinancial(user, 'READ', 'receipts'), fees.listPayments(user).filter((item) => (!filters.studentId || item.studentId === filters.studentId || item.permanentStudentId === filters.studentId) && (!filters.status || item.status === filters.status))); return json(response, { receipts }); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/fees/types' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (!canAccess(user, 'fees.read') && !canAccess(user, 'fees.configure') && !canAccess(user, 'fees.write')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, { feeTypes: await canonicalFeeTypes(user) }); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/fees/types' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (!canAccess(user, 'fees.configure') && !canAccess(user, 'fees.write')) return json(response, { error: 'Forbidden.' }, 403); try { const created = feeTypes.register(await readJson(request), user); if (database?.execute) await database.execute('INSERT INTO fee_types (id,school_id,code,name,category,description,is_active,is_system,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)', [created.id, user.schoolId, created.code, created.name, created.category, created.description ?? null, true, false, created.createdAt, created.updatedAt]); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'FEE_TYPE_CREATED', entity: 'FeeType', entityId: created.id, newValue: created })); return json(response, created, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/classes' && request.method === 'GET') { if (!user) return json(response,{error:'UNAUTHENTICATED'},401); if (!canAccess(user,'students.read') && !canAccess(user,'fees.read') && !canAccess(user,'fees.configure')) return json(response,{error:'Forbidden.'},403); try { const options = await feeSetupOptions({ ...user, permissions: new Set([...(user.permissions ?? []), 'fees.read']) }); return json(response,{classes:options.classes}); } catch (error) { return json(response,{error: error.status === 403 ? 'Forbidden.' : 'Unable to load classes. Please try again.'}, error.status ?? 503); } } if (pathname === '/api/attendance/students' && request.method === 'GET') { const query = new URL(request.url, 'http://localhost').searchParams; const filters = { academicYear: query.get('academicYear') ?? undefined, term: query.get('term') ?? undefined, date: query.get('date') ?? undefined, classId: query.get('classId') ?? undefined, subjectId: query.get('subjectId') ?? undefined }; const ids = user.portal === 'parent' ? new Set((await parentStudentsForRequest(user)).flatMap((child) => [child.id, child.studentId, child.studentProfileId, child.permanentStudentId]).filter(Boolean)) : user.roleKey === 'TEACHER' ? new Set(user.assignedStudentIds ?? []) : null; if (user.portal !== 'parent' && !canAccess(user, 'attendance.read')) return json(response, { error: 'Forbidden.' }, 403); if (attendanceRepository) { const records = await attendanceRepository.listStudentRecords({ schoolId: user.schoolId, ...filters }); const scoped = records.filter((record) => !ids || ids.has(record.studentId)); const counts = Object.fromEntries(STUDENT_STATUSES.map((status) => [status, scoped.filter((record) => record.status === status).length])); const presentLike = counts.PRESENT + counts.LATE; return json(response, { ...filters, total: scoped.length, counts, attendancePercentage: scoped.length ? Math.round((presentLike / scoped.length) * 10000) / 100 : 0, records: scoped }); } return json(response, attendance.summary({ ...filters, studentIds: ids ? [...ids] : undefined })); }
      if (pathname === '/api/attendance/alerts' && request.method === 'GET') { if (user.portal === 'parent' || !canAccess(user, 'attendance.read')) return json(response, { error: 'Forbidden.' }, 403); try { const assignedClasses = user.roleKey === 'TEACHER' ? new Set(user.assignedClassIds ?? []) : null; const source = attendanceRepository ? await (attendanceRepository.listStudentAlertRecords ?? attendanceRepository.listStudentRecords).call(attendanceRepository, { schoolId: user.schoolId }) : attendance.listStudentRecords(); const seen = new Set(); const alerts = source.filter((record) => record.schoolId === user.schoolId && ['ABSENT', 'UNEXCUSED_ABSENCE', 'SICK_ABSENCE'].includes(record.status) && (!assignedClasses || assignedClasses.has(record.classId))).map((record) => ({ ...record, student: students.getStudent(record.studentId, { requestedSchoolId: user.schoolId }) })).filter((record) => record.student && !record.student.isTestRecord).filter((record) => { const key = record.id ?? `${record.schoolId}:${record.date}:${record.studentId}:${record.subjectId ?? ''}`; if (seen.has(key)) return false; seen.add(key); return true; }).map((record) => ({ studentId: record.studentId, permanentStudentId: record.student.permanentStudentId, studentName: [record.student.firstName, record.student.middleName, record.student.surname].filter(Boolean).join(' '), classId: record.classId ?? record.student.classId, date: record.date, academicYear: record.academicYear, term: record.term, status: record.status })); return json(response, { alerts }); } catch (error) { console.error('[Attendance alerts] request failed', { schoolId: user.schoolId, userId: user.id, message: error.message }); return json(response, { error: 'Unable to load attendance alerts. Please retry.' }, 503); } }
      if (pathname === '/api/attendance/staff' && request.method === 'POST') {
        if (!canAccess(user, 'staff.attendance.write')) return json(response, { error: 'Forbidden.' }, 403);
        const body = await readJson(request);
        if (!body.staffId || !body.academicYear || !body.term || !body.date || !(body.type || body.status)) return json(response, { error: 'Staff member, Academic Year, Term, Date, and Attendance Status are required.' }, 400);
        if (!isCalendarDate(body.date)) return json(response, { error: 'Enter a valid attendance date.' }, 400);
        let registered;
        let validScope;
        try {
          registered = await isRegisteredAttendanceStaff(body.staffId, user.schoolId);
          if (registered) validScope = await isValidStaffAttendanceScope(user.schoolId, body.academicYear, body.term);
        } catch {
          return json(response, { error: 'Staff attendance options are unavailable. Please try again.' }, 503);
        }
        if (!registered) return json(response, { error: 'Registered staff member not found.' }, 404);
        if (!validScope) return json(response, { error: 'Select a configured Academic Year and Term.' }, 400);
        try {
          const input = { ...body, schoolId: user.schoolId, source: 'MANUAL', leaveRequestId: null };
          const filters = { schoolId: user.schoolId, academicYear: body.academicYear, term: body.term, date: body.date, staffId: body.staffId };
          const scopedRecords = attendanceRepository ? await attendanceRepository.listStaffRecords(filters) : attendance.listStaffRecords(filters);
          const existing = attendanceRepository ? await attendanceRepository.findStaffAttendance(input, user) : attendance.findStaffAttendance(input);
          if (scopedRecords.some((record) => record.source === 'LEAVE_RECONCILIATION' && record.status === 'ON_LEAVE')) return json(response, { error: 'Approved leave controls attendance for this date. Update the leave request to change it.' }, 409);
          if (body.id && (!existing || existing.id !== body.id || !scopedRecords.some((record) => record.id === body.id))) return json(response, { error: 'The attendance record has changed. Reload the register before updating.' }, 409);
          if (body.id && body.expectedUpdatedAt == null) return json(response, { error: 'Reload the register before updating; this client is missing the required record version.' }, 409);
          if (body.id) {
            const expectedUpdatedAt = Date.parse(body.expectedUpdatedAt);
            const currentUpdatedAt = Date.parse(existing?.updatedAt ?? '');
            if (!Number.isFinite(expectedUpdatedAt) || !Number.isFinite(currentUpdatedAt) || expectedUpdatedAt !== currentUpdatedAt) return json(response, { error: 'The attendance record has changed. Reload the register before updating.' }, 409);
          }
          if (!body.id && scopedRecords.some((record) => record.type === String(body.type ?? body.status).toUpperCase() || record.status === String(body.status ?? '').toUpperCase())) return json(response, { error: 'Attendance already exists for this staff member and status. Reload the register to update it.' }, 409);
          const record = body.id
            ? attendanceRepository ? await attendanceRepository.upsertStaffAttendance(input, user, { forceStatus: true }) : attendance.upsertStaffAttendance(input, user, { forceStatus: true })
            : attendanceRepository ? await attendanceRepository.saveStaffAttendance(input, user) : attendance.saveStaffAttendance(input, user);
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: body.id ? 'UPDATE' : 'CREATE', entity: 'StaffAttendance', entityId: record.id, newValue: { ...record, actorRoleKey: user.roleKey } }));
          return json(response, record, body.id ? 200 : 201);
        } catch (error) {
          const conflict = /already recorded|duplicate|changed/i.test(error.message);
          return json(response, { error: conflict ? 'Attendance already exists or has changed. Reload the register and try again.' : 'Attendance could not be saved. Check the date, academic period, and status.' }, conflict ? 409 : 400);
        }
      }
      if ((pathname === '/api/attendance/staff' || pathname === '/api/attendance/staff/report') && request.method === 'GET') {
        if (!canAccess(user, 'staff.attendance.read')) return json(response, { error: 'Forbidden.' }, 403);
        const query = new URL(request.url, 'http://localhost').searchParams;
        const filters = { schoolId: user.schoolId, academicYear: query.get('academicYear') ?? undefined, term: query.get('term') ?? undefined, date: query.get('date') ?? undefined };
        try {
          const records = attendanceRepository ? await attendanceRepository.listStaffRecords(filters) : attendance.listStaffRecords().filter((record) => record.schoolId === user.schoolId && (!filters.academicYear || record.academicYear === filters.academicYear) && (!filters.term || record.term === filters.term) && (!filters.date || record.date === filters.date));
          const staffMembers = await registeredAttendanceStaff(user.schoolId);
          const statusLabels = { PRESENT: 'Present', ABSENT: 'Absent', LATE: 'Late', CHECKED_IN: 'Checked In', CHECKED_OUT: 'Checked Out', ON_LEAVE: 'On Leave', EXCUSED: 'Excused' };
          const counts = Object.fromEntries(STAFF_ATTENDANCE_STATUSES.map((status) => [status, records.filter((record) => record.status === status).length]));
          const attendanceOptions = STAFF_ATTENDANCE_STATUSES.map((status) => ({ status, type: typeFromStaffAttendanceStatus(status), label: statusLabels[status] ?? status }));
          return json(response, { staff: staffMembers, records, total: records.length, counts, statuses: statusLabels, attendanceOptions });
        } catch {
          return json(response, { error: 'Staff attendance register is unavailable. Please try again.' }, 503);
        }
      }
      if (pathname === '/api/attendance/students/overview' && request.method === 'GET') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401);
        if (user.portal === 'parent' || user.portal === 'student' || !canAccess(user, 'attendance.read')) return json(response, { error: 'Forbidden.' }, 403);
        if (!studentAttendanceOverview) return json(response, { error: 'Student attendance reporting is unavailable.' }, 503);
        const query = new URL(request.url, 'http://localhost').searchParams;
        const filters = Object.fromEntries(['academicYear', 'term', 'classId', 'week', 'month', 'startDate', 'endDate', 'gender', 'status', 'asOfDate'].map((key) => [key, query.get(key) ?? undefined]));
        try {
          return json(response, await studentAttendanceOverview.overview(filters, user));
        } catch (error) {
          return json(response, { error: error.message ?? 'Student attendance overview is unavailable.' }, error.status ?? 400);
        }
      }
      if (pathname === '/api/attendance/overview/analytics' && request.method === 'GET') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401);
        if (user.portal === 'parent' || user.portal === 'student' || !canAccess(user, 'attendance.read')) return json(response, { error: 'Forbidden.' }, 403);
        if (!attendanceAnalytics) return json(response, { error: 'Attendance analytics is unavailable.' }, 503);
        const query = new URL(request.url, 'http://localhost').searchParams;
        const filters = Object.fromEntries(['academicYear', 'term', 'week', 'month', 'startDate', 'endDate', 'classId', 'gender', 'role', 'status', 'asOfDate'].map((key) => [key, query.get(key) ?? undefined]));
        try {
          return json(response, await attendanceAnalytics.overview(filters, user));
        } catch (error) {
          return json(response, { error: error.message ?? 'Attendance analytics is unavailable.' }, error.status ?? 400);
        }
      }
      if (pathname === '/api/attendance/staff/overview' && request.method === 'GET') {
        if (!canAccess(user, 'staff.attendance.read')) return json(response, { error: 'Forbidden.' }, 403);
        const query = new URL(request.url, 'http://localhost').searchParams;
        const filters = Object.fromEntries(['academicYear', 'term', 'week', 'month', 'startDate', 'endDate', 'role', 'status', 'asOfDate'].map((key) => [key, query.get(key) ?? undefined]));
        try {
          return json(response, await staffAttendanceOverview.overview(filters, user));
        } catch (error) {
          return json(response, { error: error.message ?? 'Staff attendance overview is unavailable.' }, error.status ?? 400);
        }
      }
      if (pathname === '/api/attendance/notifications' && request.method === 'POST') { if (user.portal !== 'parent') return json(response, { error: 'Forbidden.' }, 403); return json(response, attendance.setNotificationSettings(user.id, await readJson(request))); }
      if (pathname === '/api/examinations/dashboard') { if (!canAccess(user, 'examinations.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, examinations.dashboard()); }
      if (pathname === '/api/examinations/timetables' && request.method === 'GET') { if (!(user.portal === 'parent' || canAccess(user, 'examinations.read'))) return json(response, { error: 'Forbidden.' }, 403); return json(response, { timetables: examinations.listTimetables(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user), canManage: ['HEADTEACHER', 'ASSISTANT_HEADTEACHER', 'SCHOOL_ADMIN'].includes(user.roleKey) }); }
      if (pathname === '/api/examinations/timetables' && request.method === 'POST') { try { const result = examinations.saveTimetable(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'SAVE', entity: 'ExaminationTimetable', entityId: result.id, newValue: result })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/examinations/timetables/') && pathname.endsWith('/publish') && request.method === 'POST') { try { const result = examinations.publishTimetable(pathname.split('/')[4], user); dispatchClassNotification(result.classId, 'EXAM_TIMETABLE_PUBLISHED', 'Examination timetable published', (student) => `Dear Parent, the examination timetable for ${student.classId}'s class has been published. Please log in to the Parent Portal to view it.`, `EXAM_TIMETABLE_PUBLISHED:${result.id}:${result.updatedAt ?? result.publishedAt}`); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'PUBLISH', entity: 'ExaminationTimetable', entityId: result.id, newValue: result })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/examinations' && request.method === 'POST') { if (!canAccess(user, 'examinations.write')) return json(response, { error: 'Forbidden.' }, 403); return json(response, examinations.createExamination(await readJson(request)), 201); }
      if (pathname.startsWith('/api/examinations/') && pathname.endsWith('/items') && request.method === 'POST') { if (!canAccess(user, 'examinations.write')) return json(response, { error: 'Forbidden.' }, 403); const body = await readJson(request); return json(response, examinations.addExamItem(pathname.split('/')[3], body.type, body.item), 201); }
      if (pathname === '/api/examinations/grading' && request.method === 'POST') { if (!canAccess(user, 'examinations.write')) return json(response, { error: 'Forbidden.' }, 403); const body = await readJson(request); return json(response, examinations.setGradingSystem(body.key, body.boundaries)); }
      if (pathname === '/api/examinations/marks' && request.method === 'POST') { if (!canAccess(user, 'marks.write')) return json(response, { error: 'Forbidden.' }, 403); const body = await readJson(request); if (user.roleKey === 'TEACHER' && user.assignedStudentIds.length && !user.assignedStudentIds.includes(body.studentId)) return json(response, { error: 'Student is outside your assignment.' }, 403); const mark = examinations.enterMarks(body, user, { correction: Boolean(body.correction) }); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: body.correction ? 'CORRECT' : 'ENTER', entity: 'ExaminationMark', entityId: mark.id, newValue: mark })); return json(response, mark, 201); }
      if (pathname.startsWith('/api/examinations/marks/') && pathname.endsWith('/state') && request.method === 'POST') { if (!canAccess(user, 'results.read')) return json(response, { error: 'Forbidden.' }, 403); const parts = pathname.split('/').filter(Boolean); const body = await readJson(request); const mark = examinations.transitionResult(parts[3], parts[4], parts[5], body.state, { ...user, canApprove: canAccess(user, 'results.approve') }); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'STATE_CHANGE', entity: 'ExaminationMark', entityId: mark.id, newValue: mark })); return json(response, mark); }
      if (pathname === '/api/examinations/report' && request.method === 'GET') { if (!canAccess(user, 'results.read')) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; return json(response, { report: examinations.report(query.get('examId'), query.get('studentId')) }); }
      if (pathname === '/api/examinations/promotion/options' && request.method === 'GET') { if (!canAccess(user, 'promotion.write') && !canAccess(user, 'promotion.read')) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); return json(response, durablePromotion ? await durablePromotion.options(query, user) : examinations.promotionOptions(query, user)); } catch (error) { return json(response, { error: error.message }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/examinations/promotion/results' && request.method === 'GET') { if (!canAccess(user, 'promotion.write') && !canAccess(user, 'promotion.read')) return json(response, { error: 'Forbidden.' }, 403); try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); return json(response, { rows: examinations.promotionResults(query, user) }); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/examinations/promotion' && request.method === 'POST') { if (!canAccess(user, 'promotion.write')) return json(response, { error: 'Forbidden.' }, 403); try { const body = await readJson(request); const result = durablePromotion ? await durablePromotion.bulkDecide({ ...body, studentIds: body.studentIds ?? (body.studentId ? [body.studentId] : []) }, user) : (body.studentIds?.length > 1 ? examinations.bulkPromote({ ...body, decisions: body.studentIds.map((studentId) => ({ studentId, decision: body.decision })) }, user) : [examinations.promote(body.studentIds?.[0] ?? body.studentId, body.academicYearId, body.decision, user, body.comment, { classId: body.classId, termId: body.termId })]); result.forEach((item) => audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'PROMOTION', entity: 'PromotionDecision', entityId: item.id, newValue: item }))); return json(response, { decisions: result }, 201); } catch (error) { return json(response, { error: error.message, code: error.code, details: error.details }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/examinations/promotion/bulk' && request.method === 'POST') { if (!canAccess(user, 'promotion.write')) return json(response, { error: 'Forbidden.' }, 403); try { const body = await readJson(request); const result = durablePromotion ? await durablePromotion.bulkDecide(body, user) : examinations.bulkPromote({ ...body, decisions: body.decisions ?? (body.studentIds ?? []).map((studentId) => ({ studentId, decision: body.decision })) }, user); result.forEach((item) => audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'PROMOTION', entity: 'PromotionDecision', entityId: item.id, newValue: item }))); return json(response, { decisions: result }, 201); } catch (error) { return json(response, { error: error.message, code: error.code, details: error.details }, error.status ?? (error.message === 'Forbidden.' ? 403 : 400)); } }
      if (pathname === '/api/examinations/completion' && request.method === 'POST') { if (!canAccess(user, 'promotion.write')) return json(response, { error: 'Forbidden.' }, 403); try { const body = await readJson(request); const result = examinations.complete(body.studentId, { completionYear: body.completionYear, academicYearId: body.academicYearId, termId: body.termId }, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'COMPLETE', entity: 'CompletedStudent', entityId: result.studentId, newValue: result })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/fees/structures' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const body = await readJson(request); authorizeFinancial(user, 'CREATE', 'feeStructures'); const result = fees.addFee(body, user); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/fees/publish' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const body = await readJson(request); authorizeFinancial(user, 'PUBLISH', 'feeStructures'); const result = fees.publishFee(body.id, user); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/fees/invoices' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const body = await readJson(request); authorizeFinancial(user, 'CREATE', 'invoices'); assertInputSchool(user, body); if (!students.getStudent(body.studentId, { requestedSchoolId: user.schoolId })) throw new FinancialAuthorizationError('Student is outside the authenticated school.', 'CROSS_SCHOOL_ACCESS', 403); const result = fees.invoice(body, user); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/fees/payments' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const body = await readJson(request); const result = durableFeePayments ? await durableFeePayments.record(body, user) : (() => { authorizeFinancial(user, 'CREATE', 'payments'); assertInputSchool(user, body); return fees.pay(body, user); })(); dispatchPaymentNotification(result); return json(response, result, result.duplicate ? 200 : 201); } catch (error) { return json(response, { error: error.message, code: error.code ?? 'PAYMENT_FAILED' }, error.status ?? 400); } }
      if (pathname === '/api/fees/notifications/balance' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { authorizeFinancial(user, 'READ', 'studentFees'); const body = await readJson(request); assertInputSchool(user, body); if (body.studentId && !students.getStudent(body.studentId, { requestedSchoolId: user.schoolId })) throw new FinancialAuthorizationError('Student is outside the authenticated school.', 'CROSS_SCHOOL_ACCESS', 403); const invoices = fees.listInvoices(user).filter((invoice) => invoice.balance > 0 && (!body.studentId || invoice.studentId === body.studentId)); const studentIds = [...new Set(invoices.map((invoice) => invoice.studentId))]; for (const studentId of studentIds) { const student = students.getStudent(studentId, { requestedSchoolId: user.schoolId }); if (!student) continue; const balance = invoices.filter((invoice) => invoice.studentId === studentId).reduce((sum, invoice) => sum + Number(invoice.balance), 0); dispatchParentMessage({ studentId, category: 'FEES_BALANCE', title: 'Outstanding fee balance', body: `Dear Parent, ${[student.firstName, student.middleName, student.surname].filter(Boolean).join(' ')}, Permanent Student ID ${student.permanentStudentId}, has an outstanding school fee balance of GHS ${balance.toFixed(2)}. Kindly contact the school for further information.`, balance, idempotencyKey: `BALANCE:${student.permanentStudentId}:${body.reference ?? new Date().toISOString().slice(0, 10)}` }); } return json(response, { queuedStudents: studentIds.length }); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/fees/receipts/change' && request.method === 'POST') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); try { const body = await readJson(request); authorizeFinancial(user, 'VOID_REVERSE', 'receipts'); assertInputSchool(user, body); return json(response, fees.changeReceipt(body.receiptNumber, body.action, user, body.reason)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/fees/receipts/') && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); const parts = pathname.split('/').filter(Boolean); const receiptNumber = parts[3]; const format = parts[4] ?? 'json'; if (user.portal !== 'parent') { try { authorizeFinancial(user, 'PRINT_EXPORT', 'receipts'); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } } try { const receipt = durableFeeReader ? await receiptBranding.getDurable(receiptNumber, user, durableFeeReader) : receiptBranding.get(receiptNumber, user); if (format === 'preview') { response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'private, no-store' }); return response.end(receiptBranding.markup(receipt)); } if (format === 'pdf') { const content = await receiptBranding.pdf(receipt); response.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${safeReceiptFilename(receipt.receiptNumber)}"`, 'Cache-Control': 'private, no-store' }); return response.end(content); } return json(response, { receipt }); } catch (error) { const status = error.message === 'Forbidden.' ? 403 : error.message === 'Receipt not found.' ? 404 : 500; return json(response, { error: status === 500 ? 'Receipt could not be generated.' : error.message }, status); } }
      if (pathname === '/api/fees/statements' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); const query = new URL(request.url, 'http://localhost').searchParams; const studentId = query.get('studentId'); if (user.portal === 'parent') { const linkedStudents = await parentStudentsForRequest(user); if (!linkedStudents.some((child) => [child.id, child.studentId, child.studentProfileId, child.permanentStudentId].includes(studentId))) return json(response, { error: 'Forbidden.' }, 403); } else { try { authorizeFinancial(user, 'READ', 'studentFees'); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } } return json(response, fees.statement(studentId, user.portal === 'parent' ? user.id : null, user.portal === 'parent' ? null : user, { academicYearId: query.get('academicYearId'), termId: query.get('termId'), classId: query.get('classId') })); }
      if (pathname === '/api/finance/gateway' && request.method === 'POST') { if (!canAccess(user, 'finance.write')) return json(response, { error: 'Forbidden.' }, 403); const body = await readJson(request); return json(response, fees.configureGateway(body.name, body.publicConfig ?? {})); }
      if (durableAnnouncements && pathname === '/api/communication/announcements/options' && request.method === 'GET') { try { return json(response, await durableAnnouncements.options(user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (durableAnnouncements && pathname === '/api/communication/announcements' && request.method === 'GET') { try { return json(response, { announcements: await durableAnnouncements.list(user) }); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (durableAnnouncements && pathname === '/api/communication/announcements' && request.method === 'POST') { try { return json(response, await durableAnnouncements.create(await readJson(request), user), 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (durableAnnouncements && pathname.startsWith('/api/communication/announcements/') && pathname.endsWith('/read') && request.method === 'POST') { try { return json(response, await durableAnnouncements.markRead(pathname.split('/')[4], user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/communication/announcements' && request.method === 'GET') { if (!canAccess(user, 'communication.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { announcements: communication.listAnnouncements(user.portal === 'parent' ? { ...user, children: await parentStudentsForRequest(user) } : user) }); }
      if (pathname === '/api/communication/announcements' && request.method === 'POST') { if (!canAccess(user, 'communication.write')) return json(response, { error: 'Forbidden.' }, 403); const result = communication.announce(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'Announcement', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/communication/notifications' && request.method === 'GET') { if (!canAccess(user, 'communication.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { notifications: communication.listNotifications(user.portal === 'parent' ? { ...user, children: await parentStudentsForRequest(user) } : user) }); }
      if (pathname.startsWith('/api/communication/notifications/') && pathname.endsWith('/read') && request.method === 'POST') { if (user.portal !== 'parent' || !canAccess(user, 'communication.read')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, communication.markNotificationRead(pathname.split('/')[4], user)); } catch (error) { return json(response, { error: error.message }, 404); } }
      if (pathname === '/api/communication/notifications/read-all' && request.method === 'POST') { if (user.portal !== 'parent' || !canAccess(user, 'communication.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, communication.markAllNotificationsRead(user, (await readJson(request)).studentId ?? null)); }
      if (pathname === '/api/communication/notifications/preferences' && request.method === 'POST') { if (user.portal !== 'parent') return json(response, { error: 'Forbidden.' }, 403); return json(response, communication.setPreferences(user.id, await readJson(request))); }
      if (pathname === '/api/communication/messages' && request.method === 'GET') { if (!canAccess(user, 'messages.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { messages: communication.listMessages(user, user.portal === 'parent' ? (await parentStudentsForRequest(user)).flatMap((child) => [child.id, child.studentId, child.studentProfileId, child.permanentStudentId]) : user.assignedStudentIds) }); }
      if (pathname === '/api/communication/messages' && request.method === 'POST') { if (!canAccess(user, 'messages.write')) return json(response, { error: 'Forbidden.' }, 403); try { const body = await readJson(request); const linked = user.portal === 'parent' ? await parentStudentsForRequest(user) : null; const result = communication.sendMessage(body, user, { authorizedStudentIds: linked ? linked.flatMap((child) => [child.id, child.studentId, child.studentProfileId, child.permanentStudentId]) : user.assignedStudentIds, authorizedParentIds: user.assignedParentIds ?? [], authorizedRecipientIds: linked ? parentAuthorizedStaffIds(user, linked) : user.authorizedStaffIds ?? [] }); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'SEND', entity: 'Message', entityId: result.id, newValue: result })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/academic-calendar/options' && request.method === 'GET') { if (!user || !canAccess(user, 'calendar.read')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, await academicCalendar.options(user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/academic-calendar' && request.method === 'GET') { if (!user || !canAccess(user, 'calendar.read')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, await academicCalendar.list(Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/academic-calendar' && request.method === 'POST') { if (!user || !canAccess(user, 'calendar.write')) return json(response, { error: 'Forbidden.' }, 403); try { const result = await academicCalendar.create(await readJson(request), user); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/academic-calendar/') && request.method === 'GET') { if (!user || !canAccess(user, 'calendar.read')) return json(response, { error: 'Forbidden.' }, 403); try { const result = await academicCalendar.get(pathname.split('/').pop(), user); return result ? json(response, result) : json(response, { error: 'Academic Calendar event not found.' }, 404); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/academic-calendar/') && request.method === 'PATCH') { if (!user || !canAccess(user, 'calendar.write')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, await academicCalendar.update(pathname.split('/').pop(), await readJson(request), user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/academic-calendar/') && pathname.endsWith('/publish') && request.method === 'POST') { if (!user || !canAccess(user, 'calendar.write')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, await academicCalendar.publish(pathname.split('/')[3], user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/academic-calendar/') && pathname.endsWith('/cancel') && request.method === 'POST') { if (!user || !canAccess(user, 'calendar.write')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, await academicCalendar.cancel(pathname.split('/')[3], user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname.startsWith('/api/academic-calendar/') && request.method === 'DELETE') { if (!user || !canAccess(user, 'calendar.write')) return json(response, { error: 'Forbidden.' }, 403); try { return json(response, await academicCalendar.remove(pathname.split('/').pop(), user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/communication/calendar' && request.method === 'GET') { if (!canAccess(user, 'calendar.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { events: communication.listCalendar(user) }); }
      if (pathname === '/api/communication/calendar' && request.method === 'POST') { if (!canAccess(user, 'calendar.write')) return json(response, { error: 'Forbidden.' }, 403); const result = communication.addCalendarEvent(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'CalendarEvent', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname.startsWith('/api/sms/')) {
        if (!smsAuthorized(user)) return json(response, { error: 'Forbidden.' }, 403);
        if (!smsService) return json(response, { error: 'Durable SMS storage is unavailable.' }, 503);
        try {
          if (pathname === '/api/sms/options' && request.method === 'GET') return json(response, await smsService.options(user));
          if (pathname === '/api/sms/preview' && request.method === 'POST') return json(response, await smsService.preview(await readJson(request), user));
          if (pathname === '/api/sms/drafts' && request.method === 'POST') return json(response, await smsService.saveDraft(await readJson(request), user), 201);
          if (pathname === '/api/sms/send' && request.method === 'POST') { const result = await smsService.send(await readJson(request), user); return json(response, result, ['FAILED','REJECTED','SUBMISSION_UNKNOWN'].includes(result.status) ? 502 : 202); }
          if (pathname === '/api/sms/history' && request.method === 'GET') return json(response, { messages: await smsService.listHistory(user) });
          if (pathname.startsWith('/api/sms/history/') && request.method === 'GET') { const item = await smsService.getHistoryItem(decodeURIComponent(pathname.split('/').pop()), user); return item ? json(response, item) : json(response, { error: 'SMS history item not found.' }, 404); }
        } catch (error) { return json(response, { error: error.message, code: error.code }, error.status ?? 400); }
        return json(response, { error: 'Not found.' }, 404);
      }
      if (pathname === '/api/developer/communication/providers' && request.method === 'GET') { try { return json(response, { providers: communicationEngine.listProviders(user) }); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/developer/communication/providers' && request.method === 'POST') { try { return json(response, communicationEngine.configure(await readJson(request), user), 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/developer/communication/test' && request.method === 'POST') { try { const body = await readJson(request); return json(response, await communicationEngine.testConnection(body.providerId, user, body)); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/communication/outbox' && request.method === 'POST') { try { return json(response, communicationEngine.enqueue(await readJson(request), user), 202); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } }
      if (pathname === '/api/communication/webhook' && request.method === 'POST') return json(response, communicationEngine.webhook(await readJson(request)));
      if (pathname === '/api/communication/announcements/preview' && request.method === 'POST') { try { return json(response, announcementPreview(await readJson(request), user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/communication/announcements/dispatch' && request.method === 'POST') { try { const result = dispatchAnnouncement(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ANNOUNCEMENT_DISPATCHED', entity: 'CommunicationAnnouncement', entityId: result.queuedRecipients, newValue: { emergency: result.emergency, channel: result.channel, queuedRecipients: result.queuedRecipients } })); return json(response, result, 202); } catch (error) { return json(response, { error: error.message }, error.status ?? 403); } }
      if (pathname === '/api/library' && request.method === 'GET') { if (!canAccess(user, 'library.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, operations.list('LIBRARY', user, new URL(request.url, 'http://localhost').searchParams.get('studentId'))); }
      if (pathname === '/api/library/books' && request.method === 'POST') { if (!canAccess(user, 'library.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.createBook(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'LibraryBook', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/library/loans' && request.method === 'POST') { if (!canAccess(user, 'library.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.borrowBook(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'BORROW', entity: 'LibraryLoan', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname.startsWith('/api/library/loans/') && pathname.endsWith('/return') && request.method === 'POST') { if (!canAccess(user, 'library.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.returnBook(pathname.split('/')[4], user, (await readJson(request)).condition); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'RETURN', entity: 'LibraryLoan', entityId: result.id, newValue: result })); return json(response, result); }
      if (pathname === '/api/transport' && request.method === 'GET') { if (!canAccess(user, 'transport.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, operations.list('TRANSPORT', user, new URL(request.url, 'http://localhost').searchParams.get('studentId'))); }
      if (pathname === '/api/transport/vehicles' && request.method === 'POST') { if (!canAccess(user, 'transport.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.createVehicle(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'TransportVehicle', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/transport/routes' && request.method === 'POST') { if (!canAccess(user, 'transport.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.createRoute(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'TransportRoute', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/transport/assignments' && request.method === 'POST') { if (!canAccess(user, 'transport.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.assignTransport(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ASSIGN', entity: 'TransportAssignment', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/hostel' && request.method === 'GET') { if (!canAccess(user, 'hostel.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, operations.list('HOSTEL', user, new URL(request.url, 'http://localhost').searchParams.get('studentId'))); }
      if (pathname === '/api/hostel/spaces' && request.method === 'POST') { if (!canAccess(user, 'hostel.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.addHostelSpace(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'HostelSpace', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/hostel/allocations' && request.method === 'POST') { if (!canAccess(user, 'hostel.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.allocateBoarder(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ALLOCATE', entity: 'HostelAllocation', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/welfare/health' && request.method === 'GET') { const studentId = new URL(request.url, 'http://localhost').searchParams.get('studentId'); if (user.portal === 'parent') { const linkedStudents = await parentStudentsForRequest(user); if (studentId && !linkedStudents.some((child) => [child.id, child.studentId, child.studentProfileId, child.permanentStudentId].includes(studentId))) return json(response, { error: 'Forbidden.' }, 403); return json(response, operations.list('HEALTH', { ...user, children: linkedStudents }, studentId)); } if (!canAccess(user, 'health.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, operations.list('HEALTH', user, studentId)); }
      if (pathname === '/api/welfare/health' && request.method === 'POST') { if (!canAccess(user, 'health.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.recordHealth(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'HealthRecord', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/welfare/health/visits' && request.method === 'POST') { if (!canAccess(user, 'health.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.recordHealthVisit(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'HealthVisit', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/welfare/discipline' && request.method === 'GET') { if (!canAccess(user, 'discipline.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, operations.list('DISCIPLINE', user, new URL(request.url, 'http://localhost').searchParams.get('studentId'))); }
      if (pathname === '/api/welfare/discipline' && request.method === 'POST') { if (!canAccess(user, 'discipline.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.recordIncident(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'WelfareIncident', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/welfare/counselling' && request.method === 'GET') { if (!canAccess(user, 'counselling.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, operations.list('COUNSELLING', user, new URL(request.url, 'http://localhost').searchParams.get('studentId'))); }
      if (pathname === '/api/welfare/counselling' && request.method === 'POST') { if (!canAccess(user, 'counselling.write')) return json(response, { error: 'Forbidden.' }, 403); const result = operations.recordCounselling(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'CounsellingRecord', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/inventory' && request.method === 'GET') { if (!canAccess(user, 'inventory.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, resources.list('INVENTORY', user)); }
      if (pathname === '/api/inventory/items' && request.method === 'POST') { if (!canAccess(user, 'inventory.write')) return json(response, { error: 'Forbidden.' }, 403); const result = resources.addInventory(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'InventoryItem', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/inventory/movements' && request.method === 'POST') { if (!canAccess(user, 'inventory.write')) return json(response, { error: 'Forbidden.' }, 403); const result = resources.moveStock(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'STOCK_MOVEMENT', entity: 'InventoryMovement', entityId: result.movement.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/assets' && request.method === 'GET') { if (!canAccess(user, 'assets.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, resources.list('ASSETS', user)); }
      if (pathname === '/api/assets' && request.method === 'POST') { if (!canAccess(user, 'assets.write')) return json(response, { error: 'Forbidden.' }, 403); const result = resources.addAsset(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'Asset', entityId: result.assetId, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/procurement' && request.method === 'GET') { if (!canAccess(user, 'procurement.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, resources.list('PROCUREMENT', user)); }
      if (pathname === '/api/procurement/requests' && request.method === 'POST') { if (!canAccess(user, 'procurement.write')) return json(response, { error: 'Forbidden.' }, 403); const result = resources.requestPurchase(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'PurchaseRequest', entityId: result.requestNumber, newValue: result })); return json(response, result, 201); }
      if (pathname.startsWith('/api/procurement/requests/') && pathname.endsWith('/state') && request.method === 'POST') { if (!canAccess(user, 'procurement.write')) return json(response, { error: 'Forbidden.' }, 403); const result = resources.advancePurchase(pathname.split('/')[4], (await readJson(request)).state, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'STATE_CHANGE', entity: 'PurchaseRequest', entityId: result.requestNumber, newValue: result })); return json(response, result); }
      if (pathname === '/api/property' && request.method === 'GET') { if (!canAccess(user, 'property.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, resources.list('PROPERTY', user)); }
      if (pathname === '/api/property' && request.method === 'POST') { if (!canAccess(user, 'property.write')) return json(response, { error: 'Forbidden.' }, 403); const result = resources.addProperty(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'SchoolProperty', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/property/maintenance' && request.method === 'POST') { if (!(canAccess(user, 'property.write') || canAccess(user, 'property.request'))) return json(response, { error: 'Forbidden.' }, 403); const result = resources.requestMaintenance(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'PropertyMaintenance', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname.startsWith('/api/property/maintenance/') && pathname.endsWith('/status') && request.method === 'POST') { if (!canAccess(user, 'property.write')) return json(response, { error: 'Forbidden.' }, 403); const result = resources.updateMaintenance(pathname.split('/')[4], (await readJson(request)).status, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'UPDATE', entity: 'PropertyMaintenance', entityId: result.id, newValue: result })); return json(response, result); }
      if (pathname === '/api/compliance' && request.method === 'GET') { if (!canAccess(user, 'compliance.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { records: compliance.list('compliance', user), inspections: compliance.list('inspections', user) }); }
      if (pathname === '/api/compliance' && request.method === 'POST') { if (!canAccess(user, 'compliance.write')) return json(response, { error: 'Forbidden.' }, 403); const result = compliance.addCompliance(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'ComplianceRecord', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/compliance/inspections' && request.method === 'POST') { if (!canAccess(user, 'compliance.write')) return json(response, { error: 'Forbidden.' }, 403); const result = compliance.addInspection(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'ComplianceInspection', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/documents' && request.method === 'GET') { if (!canAccess(user, 'documents.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { documents: compliance.list('documents', user) }); }
      if (pathname === '/api/documents' && request.method === 'POST') { if (!canAccess(user, 'documents.write')) return json(response, { error: 'Forbidden.' }, 403); const result = compliance.uploadDocument(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'UPLOAD', entity: 'Document', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname.startsWith('/api/documents/') && pathname.endsWith('/versions') && request.method === 'POST') { if (!canAccess(user, 'documents.write')) return json(response, { error: 'Forbidden.' }, 403); const result = compliance.addVersion(pathname.split('/')[3], await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'VERSION', entity: 'Document', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname.startsWith('/api/documents/') && pathname.endsWith('/download') && request.method === 'GET') { if (!canAccess(user, 'documents.read')) return json(response, { error: 'Forbidden.' }, 403); const result = compliance.getDocument(pathname.split('/')[3], user); return result ? json(response, { document: result, download: true }) : json(response, { error: 'Not found.' }, 404); }
      if (pathname === '/api/compliance/emis/export' && request.method === 'GET') { if (!canAccess(user, 'compliance.read')) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; return json(response, { format: query.get('format') ?? 'json', export: compliance.exportCensus(Object.fromEntries(query), query.get('format') ?? 'json') }); }
      if (pathname === '/api/privacy' && request.method === 'GET') { if (!canAccess(user, 'privacy.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { consents: compliance.list('consents', user), requests: compliance.list('requests', user), retention: compliance.list('retention', user), officers: compliance.list('officers', user), breaches: compliance.list('breaches', user) }); }
      if (pathname === '/api/privacy/consents' && request.method === 'POST') { if (!canAccess(user, 'privacy.write')) return json(response, { error: 'Forbidden.' }, 403); const result = compliance.addConsent(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CONSENT', entity: 'PrivacyConsent', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/privacy/requests' && request.method === 'POST') { if (!canAccess(user, 'privacy.write')) return json(response, { error: 'Forbidden.' }, 403); const result = compliance.addPrivacyRequest(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'PrivacyRequest', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/privacy/retention' && request.method === 'POST') { if (!canAccess(user, 'privacy.write')) return json(response, { error: 'Forbidden.' }, 403); const result = compliance.addRetention(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'RetentionPolicy', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/privacy/officers' && request.method === 'POST') { if (!canAccess(user, 'privacy.write')) return json(response, { error: 'Forbidden.' }, 403); const result = compliance.addOfficer(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'APPOINT', entity: 'DataProtectionOfficer', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/privacy/breaches' && request.method === 'POST') { if (!canAccess(user, 'privacy.write')) return json(response, { error: 'Forbidden.' }, 403); const result = compliance.addBreach(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'REPORT', entity: 'DataBreach', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/reports/academic' && request.method === 'GET') { if (!(canAccess(user, 'academics.read') || canAccess(user, 'reports.read'))) return json(response, { error: 'Forbidden.' }, 403); const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); try { return json(response, reporting.buildAcademicReport(query, user, { students, attendance, examinations, fees })); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/reports/academic/export' && request.method === 'GET') { if (!(canAccess(user, 'academics.read') || canAccess(user, 'reports.read'))) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; try { const report = reporting.buildAcademicReport(Object.fromEntries(query), user, { students, attendance, examinations, fees }); return json(response, reporting.exportReport(report, query.get('format') ?? 'csv')); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/reports/financial' && request.method === 'GET') { if (!(canAccess(user, 'finance.read') || canAccess(user, 'fees.read') || canAccess(user, 'reports.read'))) return json(response, { error: 'Forbidden.' }, 403); const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); try { return json(response, (reporting.buildFinancialReportAsync ? await reporting.buildFinancialReportAsync(query, user, { fees, generalFinance }) : reporting.buildFinancialReport(query, user, { fees }))); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/reports/financial/export' && request.method === 'GET') { if (!(canAccess(user, 'finance.read') || canAccess(user, 'fees.read') || canAccess(user, 'reports.read'))) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; try { const report = (reporting.buildFinancialReportAsync ? await reporting.buildFinancialReportAsync(Object.fromEntries(query), user, { fees, generalFinance }) : reporting.buildFinancialReport(Object.fromEntries(query), user, { fees })); return json(response, reporting.exportReport(report, query.get('format') ?? 'csv')); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname.startsWith('/api/reports/') && request.method === 'GET') { if (!canAccess(user, 'reports.read')) return json(response, { error: 'Forbidden.' }, 403); const parts = pathname.split('/').filter(Boolean); try { return json(response, reporting.buildReport(parts[2], Object.fromEntries(new URL(request.url, 'http://localhost').searchParams), user, { students, attendance, examinations, fees })); } catch (error) { return json(response, { error: error.message }, error.message === 'Forbidden.' ? 403 : 400); } }
      if (pathname === '/api/official-documents' && request.method === 'GET') { if (!canAccess(user, 'documents.generate')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { documents: reporting.listDocuments(user) }); }
      if (pathname === '/api/official-documents' && request.method === 'POST') { if (!canAccess(user, 'documents.generate')) return json(response, { error: 'Forbidden.' }, 403); const result = reporting.generateOfficialDocument(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'GENERATE', entity: 'OfficialDocument', entityId: result.documentNumber, newValue: { ...result, pdf: undefined, verificationCode: undefined } })); return json(response, result, 201); }
      if (pathname === '/api/staff' && request.method === 'POST') { if (!canAccess(user, 'staff.write')) return json(response, { error: 'Forbidden.' }, 403); const result = staff.createProfile(await readJson(request)); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'StaffProfile', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname === '/api/staff/leave' && request.method === 'GET') { if (!canAccess(user, 'leave.read') && !canAccess(user, 'staff.read')) return json(response, { error: 'Forbidden.' }, 403); const query = new URL(request.url, 'http://localhost').searchParams; return json(response, { leave: staff.listLeave(query.get('staffId') ?? undefined, { state: query.get('state') ?? undefined, academicYear: query.get('academicYear') ?? undefined, term: query.get('term') ?? undefined }) }); }
      if (pathname.startsWith('/api/staff/') && pathname.endsWith('/assignments') && request.method === 'POST') { if (!canAccess(user, 'staff.write')) return json(response, { error: 'Forbidden.' }, 403); const result = staff.assign(pathname.split('/')[3], await readJson(request)); return json(response, result, 201); }
      if (pathname.startsWith('/api/staff/') && pathname.endsWith('/leave') && request.method === 'POST') { const body = await readJson(request); if (user.portal !== 'school' || (body.staffId !== user.id && !canAccess(user, 'leave.write'))) return json(response, { error: 'Forbidden.' }, 403); const result = staff.applyLeave(body); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'StaffLeave', entityId: result.id, newValue: result })); return json(response, result, 201); }
      if (pathname.startsWith('/api/staff/leave/') && pathname.endsWith('/audit') && request.method === 'GET') { if (!canAccess(user, 'leave.read') && !canAccess(user, 'staff.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { audit: await staffLeaveReconciler.auditFor(pathname.split('/')[4], user.schoolId) }); }
      if (pathname.startsWith('/api/staff/leave/') && request.method === 'PATCH') { if (!canAccess(user, 'leave.write')) return json(response, { error: 'Forbidden.' }, 403); const result = staff.updateLeave(pathname.split('/')[3], await readJson(request), user); const reconciliation = await staffLeaveReconciler.reconcileLeave(result, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'UPDATE', entity: 'StaffLeave', entityId: result.id, newValue: { result, reconciliation } })); return json(response, { ...result, reconciliation }); }
      if (pathname.startsWith('/api/staff/leave/') && pathname.endsWith('/decision') && request.method === 'POST') { if (!canAccess(user, 'leave.approve') && !canAccess(user, 'leave.write')) return json(response, { error: 'Forbidden.' }, 403); const body = await readJson(request); const result = staff.decideLeave(pathname.split('/')[3], body.state, user, { cancellationReason: body.cancellationReason }); const reconciliation = await staffLeaveReconciler.reconcileLeave(result, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'DECIDE', entity: 'StaffLeave', entityId: result.id, newValue: { result, reconciliation } })); return json(response, { ...result, reconciliation }); }
      if (pathname.startsWith('/api/staff/') && request.method === 'GET') { if (!canAccess(user, 'staff.read') && pathname.split('/')[2] !== user.id) return json(response, { error: 'Forbidden.' }, 403); const result = staff.getProfile(pathname.split('/')[3] ?? pathname.split('/')[2], { confidential: canAccess(user, 'hr.confidential.read'), requestedSchoolId: user.schoolId }); return result ? json(response, result) : json(response, { error: 'Not found.' }, 404); }
      if (pathname.startsWith('/api/students/')) { const parts = pathname.split('/').filter(Boolean); const studentId = parts[2]; if (parts[3] === 'class' && request.method === 'POST') { if (!canAccess(user, 'students.write')) return json(response, { error: 'Forbidden.' }, 403); return json(response, students.assignClass(studentId, await readJson(request))); } if (parts[3] === 'parents' && request.method === 'POST') { if (!canAccess(user, 'students.write')) return json(response, { error: 'Forbidden.' }, 403); return json(response, students.linkParent(studentId, await readJson(request)), 201); } if (request.method === 'PATCH' && parts.length === 3) { if (!canAccess(user, 'students.write')) return json(response, { error: 'Forbidden.' }, 403); try { const record = durableStudentProfile ? await durableStudentProfile.update(studentId, await readJson(request), user) : null; return record ? json(response, record) : json(response, { error: 'Durable student profile persistence is unavailable.' }, 503); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); } } if (request.method === 'GET') { if (!canAccess(user, 'students.read')) return json(response, { error: 'Forbidden.' }, 403); const record = durableStudentProfile ? await durableStudentProfile.getStudent(studentId, user) : students.getStudent(studentId, { allowHealth: canAccess(user, 'health.read'), requestedSchoolId: user.schoolId }); return record ? json(response, record) : json(response, { error: 'Not found.' }, 404); } }
      if (pathname === '/api/admissions' && request.method === 'GET') { if (!canAccess(user, 'admissions.read')) return json(response, { error: 'Forbidden.' }, 403); return json(response, { admissions: students.listAdmissions() }); }
      if (pathname === '/api/admissions' && request.method === 'POST') { if (!canAccess(user, 'admissions.write')) return json(response, { error: 'Forbidden.' }, 403); const application = students.createAdmission(await readJson(request)); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'CREATE', entity: 'AdmissionApplication', entityId: application.applicationNumber, newValue: application })); return json(response, application, 201); }
      if (pathname.startsWith('/api/admissions/') && pathname.endsWith('/decision') && request.method === 'POST') { if (!canAccess(user, 'admissions.review')) return json(response, { error: 'Forbidden.' }, 403); const applicationNumber = pathname.split('/')[3]; const body = await readJson(request); if ((body.decision === 'ACCEPTED' && !canAccess(user, 'admissions.accept')) || (body.decision === 'REJECTED' && !canAccess(user, 'admissions.reject'))) return json(response, { error: 'Forbidden.' }, 403); try { const application = students.decideAdmission(applicationNumber, body.decision, body.year); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: body.decision === 'ACCEPTED' ? 'ADMISSION_ACCEPTED' : 'ADMISSION_REJECTED', entity: 'AdmissionApplication', entityId: applicationNumber, newValue: application })); return json(response, application); } catch (error) { return json(response, { error: error.message }, 400); } }
      if (pathname.startsWith('/api/admissions/') && pathname.endsWith('/advance') && request.method === 'POST') { if (!canAccess(user, 'admissions.write')) return json(response, { error: 'Forbidden.' }, 403); const applicationNumber = pathname.split('/')[3]; const application = students.advanceAdmission(applicationNumber, (await readJson(request)).stage); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ADVANCE', entity: 'AdmissionApplication', entityId: applicationNumber, newValue: application })); return json(response, application); }
      if (pathname === '/api/assignments' && request.method === 'GET') {
        if (user.portal !== 'school' || (!canAccess(user, 'academics.read') && !canAccess(user, 'marks.write'))) return json(response, { error: 'Forbidden.' }, 403);
        try { return json(response, { assignments: await assignments.listForStaff(user, Object.fromEntries(new URL(request.url, 'http://localhost').searchParams)) }); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); }
      }
      if (pathname === '/api/assignments/options' && request.method === 'GET') {
        if (user.portal !== 'school' || (!canAccess(user, 'academics.read') && !canAccess(user, 'marks.write'))) return json(response, { error: 'Forbidden.' }, 403);
        try { return json(response, await assignments.options(user)); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); }
      }
      if (pathname === '/api/assignments' && request.method === 'POST') {
        if (user.portal !== 'school' || (!canAccess(user, 'marks.write') && !canAccess(user, 'academics.read'))) return json(response, { error: 'Forbidden.' }, 403);
        try { const result = await assignments.create(await readJson(request), user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ASSIGNMENT_CREATED', entity: 'Assignment', entityId: result.id, newValue: result })); return json(response, result, 201); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); }
      }
      if (pathname.startsWith('/api/assignments/') && pathname.endsWith('/publish') && request.method === 'POST') {
        if (user.portal !== 'school' || (!canAccess(user, 'marks.write') && !canAccess(user, 'academics.read'))) return json(response, { error: 'Forbidden.' }, 403);
        try { const id = pathname.split('/')[3]; const result = await assignments.publish(id, user); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ASSIGNMENT_PUBLISHED', entity: 'Assignment', entityId: id, newValue: result })); return json(response, result); } catch (error) { return json(response, { error: error.message }, error.status ?? 400); }
      }
      if (pathname === '/api/parent/options' && request.method === 'GET') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (user.portal !== 'parent' || !canAccess(user, 'children.read')) return json(response, { error: 'Forbidden.' }, 403);
        try { return json(response, await parentDashboard.options(user)); }
        catch (error) { return parentApiError(response, error, 'options'); }
      }
      if (pathname === '/api/parent/children' && request.method === 'GET') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (user.portal !== 'parent' || !canAccess(user, 'children.read')) return json(response, { error: 'Forbidden.' }, 403);
        try { return json(response, { children: await parentDashboard.listChildren(user) }); }
        catch (error) { return parentApiError(response, error, 'children'); }
      }
      if (pathname === '/api/parent/records' && request.method === 'GET') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (user.portal !== 'parent' || !canAccess(user, 'children.read')) return json(response, { error: 'Forbidden.' }, 403);
        try { return json(response, await parentDashboard.loadRecord(user, Object.fromEntries(new URL(request.url, 'http://localhost').searchParams))); }
        catch (error) { return parentApiError(response, error, 'records'); }
      }
      if (pathname === '/api/parent/assignments/pdf' && request.method === 'GET') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (user.portal !== 'parent' || !canAccess(user, 'children.read')) return json(response, { error: 'Forbidden.' }, 403);
        try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); const student = await parentDashboard.resolveChild(user, query.permanentStudentId); const content = await assignments.pdf(query.assignmentId, user, { ...student, name: parentDashboard.childSummary(student).name }); response.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': 'attachment; filename="OSAAH_Assignment.pdf"', 'Cache-Control': 'private, no-store' }); return response.end(content); } catch (error) { return parentApiError(response, error, 'assignment-pdf'); }
      }
      if (pathname === '/api/parent/results/pdf' && request.method === 'GET') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (user.portal !== 'parent' || !canAccess(user, 'children.read')) return json(response, { error: 'Forbidden.' }, 403);
        try {
          const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams);
          const record = await parentDashboard.loadRecord(user, { ...query, recordType: 'published-results' });
          const content = await resultPdf.pdf(record.result);
          response.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${resultPdf.filename(record.result)}"`, 'Cache-Control': 'private, no-store' });
          return response.end(content);
        } catch (error) { return parentApiError(response, error, 'results-pdf'); }
      }
      if (pathname === '/api/parent/components' && request.method === 'GET') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (user.portal !== 'parent' || !canAccess(user, 'children.read')) return json(response, { error: 'Forbidden.' }, 403);
        try { const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams); return json(response, await parentDashboard.component(user, query.moduleKey, query)); }
        catch (error) { return parentApiError(response, error, 'components'); }
      }
      if (pathname === '/api/parent/lookup' && request.method === 'GET') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (user.portal !== 'parent' || !canAccess(user, 'children.read')) return json(response, { error: 'Forbidden.' }, 403);
        const query = Object.fromEntries(new URL(request.url, 'http://localhost').searchParams);
        try {
          const student = await parentDashboard.loadRecord(user, { ...query, recordType: 'student-summary' });
          const feesForChild = await parentDashboard.loadRecord(user, { ...query, recordType: 'fees' });
          let result = { published: false };
          try { result = { published: true, data: (await parentDashboard.loadRecord(user, { ...query, recordType: 'published-results' })).result }; }
          catch (error) { if (error.status !== 404) throw error; }
          return json(response, { student: { ...student.student, ...(student.context ?? {}) }, fees: { ...feesForChild.summary, receipts: feesForChild.receipts ?? [] }, result });
        } catch (error) { return parentApiError(response, error, 'lookup'); }
      }
      if (pathname === '/api/parent/children/resolve' && request.method === 'GET') { if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (user.portal !== 'parent' || !canAccess(user, 'children.read')) return json(response, { error: 'Forbidden.' }, 403); const permanentStudentId = new URL(request.url, 'http://localhost').searchParams.get('permanentStudentId'); const child = await authorizeParentStudent({ actor: user, permanentStudentId, students, admissionEnrollment, testParentSchoolId: serviceSchoolId }); return child ? json(response, { child: parentDashboard.childSummary(child) }) : json(response, { error: PARENT_UNLINKED_MESSAGE }, 403); }
      if (pathname === '/api/parent/receipts' && request.method === 'GET') {
        if (!user) return json(response, { error: 'UNAUTHENTICATED' }, 401); if (user.portal !== 'parent' || !canAccess(user, 'children.read')) return json(response, { error: 'Forbidden.' }, 403);
        try {
          const rows = durableFeeReader ? await durableFeeReader.listReceipts({}, user) : receiptBranding.listForParent(user);
          const receipts = durableFeeReader ? await Promise.all(rows.map((row) => receiptBranding.getDurable(row.receiptNumber, user, durableFeeReader))) : rows;
          return json(response, { receipts });
        } catch (error) { return parentApiError(response, error, 'receipts'); }
      }
      if (pathname === '/api/management') { if (!canAccess(user, 'users.read')) return json(response, { error: 'Forbidden.' }, 403); audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, action: 'ACCESS', entity: 'ManagementDashboard' })); return json(response, { authorized: true, schoolId: user.schoolId }); }
      if (pathname === '/api/single-school/overview' && request.method === 'GET') {
        if (user.portal !== 'school' || (!canAccess(user, 'students.read') && !canAccess(user, 'users.read') && !canAccess(user, 'academics.read') && !canAccess(user, 'attendance.read') && !canAccess(user, 'finance.read') && !canAccess(user, 'fees.read'))) return json(response, { error: 'Forbidden.' }, 403);
        try { return json(response, await singleSchoolOverview.getOverview(user)); } catch (error) { return json(response, { error: error.message ?? 'Single-School Panel is temporarily unavailable.' }, error.status ?? 503); }
      }
      if (pathname === '/api/users' && request.method === 'GET') {
        if (user.portal !== 'school' || !canAccess(user, 'users.read')) return json(response, { error: 'Forbidden.' }, 403);
        try {
          const users = await userDirectory.listFor(user);
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'ACCESS', entity: 'UserDirectory' }));
          return json(response, { users });
        } catch (error) {
          return json(response, { error: error.message ?? 'User directory service is unavailable.' }, error.status ?? 503);
        }
      }
      if (pathname.startsWith('/api/users/') && pathname.endsWith('/credentials/reissue') && request.method === 'POST') {
        const canManageCredentials = canAccess(user, 'users.credentials.manage') || ['PROPRIETOR', 'SCHOOL_ADMIN'].includes(user.roleKey);
        if (user.portal !== 'school' || !canManageCredentials) return json(response, { error: 'Forbidden.' }, 403);
        const targetId = pathname.split('/').filter(Boolean)[2];
        try {
          const result = await auth.resetUserCredentials(targetId, user.schoolId);
          if (!result) return json(response, { error: 'Account not found.' }, 404);
          audit(createAuditLog({ schoolId: user.schoolId, userId: user.id, roleId: user.roleKey, action: 'CREDENTIALS_REISSUED', entity: 'User', entityId: result.userId, newValue: { targetUsername: result.username, targetRoleKey: result.roleKey, mustChangePassword: true } }));
          return json(response, { ok: true, user: { id: result.userId, username: result.username, email: result.email, staffId: result.staffId, roleKey: result.roleKey }, temporaryPassword: result.temporaryPassword, mustChangePassword: true });
        } catch (error) {
          return json(response, { error: error.message ?? 'Credentials could not be reissued.', code: error.code ?? 'CREDENTIAL_REISSUE_FAILED' }, error.status ?? 400);
        }
      }
      return pathname.startsWith('/api/attendance/')
        ? attendanceApiFailure(response, Object.assign(new Error('Attendance endpoint not found.'), { status: 404, code: 'ATTENDANCE_ENDPOINT_NOT_FOUND' }), pathname, apiActor)
        : json(response, { error: 'Not found.' }, 404);
      } catch (error) {
        if (pathname.startsWith('/api/attendance/')) return attendanceApiFailure(response, error, pathname, apiActor);
        throw error;
      }
    }
    if (pathname === '/website') { response.writeHead(302, { Location: '/#public-school-website', 'Cache-Control': 'no-store' }); return response.end(); }
    const pageAliases = { '/dashboard': '/index.html', '/parent-dashboard': '/index.html', '/developer/communication-setup': '/communication-setup.html', '/academics': '/academics.html', '/students': '/students.html', '/admissions': '/internal-registration.html', '/admissions/register': '/internal-registration.html', '/attendance': '/attendance-overview.html', '/examinations': '/examinations.html', '/results': '/results.html', '/promotion': '/results.html', '/fees': '/fees.html', '/fees/admission-structures': '/admission-fees.html', '/fees/scholarships': '/fees.html', '/finance': '/finance.html', '/staff': '/staff.html', '/staff/leave': '/leave.html', '/staff/professional-development': '/staff.html', '/administrator-management': '/administrator-management.html', '/staff-management': '/staff-management.html', '/settings': '/school-settings.html', '/users': '/users-and-roles.html', '/communication': '/communication.html', '/communication/messages': '/sms-messages.html', '/communication/in-app-messages': '/in-app-messages.html', '/communication/calendar': '/academic-calendar.html', '/academic-calendar': '/academic-calendar.html', '/compliance': '/compliance.html', '/documents': '/documents.html', '/privacy': '/privacy.html', '/inventory': '/inventory.html', '/assets': '/assets.html', '/procurement': '/procurement.html', '/property': '/assets.html', '/library': '/library.html', '/transport': '/transport.html', '/sporting-activities': '/sporting-activities.html', '/transport/gps': '/transport.html', '/hostel': '/hostel.html', '/welfare/health': '/welfare.html', '/welfare/discipline': '/welfare.html', '/welfare/counselling': '/welfare.html' };
    Object.assign(pageAliases, { '/about-developer': '/about-developer.html', '/copyright': '/copyright.html' });
    Object.assign(pageAliases, { '/reports': '/reports.html', '/reports/academic': '/reports-academic.html', '/reports/financial': '/reports-financial.html', '/official-documents': '/official-documents.html', '/website': '/website.html', '/admissions/prospectus': '/admission-prospectus.html', '/parent/admission-prospectus': '/parent-admission-prospectus.html', '/examinations/marks': '/examinations.html', '/examinations/mock': '/mock-examinations.html', '/results/mock': '/results.html', '/academics/subjects': '/subjects.html', '/academics/subject-register': '/subject-register.html', '/welfare/shep': '/shep-activities.html', '/settings/result-signatures': '/result-signatures.html', '/fees/invoices': '/receipts.html' });
    Object.assign(pageAliases, { '/academics': '/subjects.html', '/admissions/analytics': '/admission-analytics.html', '/settings/single-school': '/single-school-panel.html', '/user-guide': '/user-guide.html', '/finance/receipts': '/finance-canonical.html' }, PROPRIETOR_PAGE_ALIASES, { '/settings/profile': '/school-profile.html' }, Object.fromEntries(Object.keys(PROPRIETOR_PAGE_ALIASES).filter((route) => route === '/finance' || route.startsWith('/finance/') || route.startsWith('/fees/')).map((route) => [route, '/finance-canonical.html'])));
    Object.assign(pageAliases, { '/fees/setup': '/fee-setup.html', '/fees/collections/extra-classes': '/collections.html', '/fees/collections/canteen': '/canteen.html', '/fees/collections/reports': '/collection-reports.html', '/parent/fees': '/parent-fees.html', '/attendance/students': '/attendance.html', '/attendance/overview': '/attendance-overview.html', '/attendance/reports': '/attendance-report.html' });
    pageAliases['/communication/messages'] = '/sms-messages.html';
    pageAliases['/communication/in-app-messages'] = '/in-app-messages.html';
    const modulePageFallbacks = [
      ['/students/', '/students.html'], ['/admissions/', '/admissions.html'], ['/attendance/', '/attendance-overview.html'],
      ['/examinations/', '/examinations.html'], ['/results/', '/results.html'], ['/academics/', '/academics.html'],
      ['/fees/', '/fees.html'], ['/finance/', '/finance.html'], ['/staff/', '/staff.html'],
      ['/communication/', '/communication.html'], ['/library/', '/library.html'], ['/transport/', '/transport.html'],
      ['/hostel/', '/hostel.html'], ['/welfare/', '/welfare.html'], ['/inventory/', '/inventory.html'],
      ['/assets/', '/assets.html'], ['/property/', '/assets.html'], ['/procurement/', '/procurement.html'],
      ['/compliance/', '/compliance.html'], ['/documents/', '/documents.html'], ['/reports/', '/reports.html']
    ];
    const protectedPage = ['/dashboard', '/parent-dashboard'].includes(pathname) || pathname !== '/parent/admission-prospectus' && SIDEBAR_MODULES.some((module) => module.route === pathname && module.moduleKey !== 'dashboard' && module.moduleKey !== 'logout');
    let protectedUser = null;
    if (protectedPage) {
      const sessionToken = readCookie(request, 'osaah_session');
      const bearerToken = sessionToken ? null : bearer(request);
      const authContext = sessionDiagnosticContext(request, pathname, sessionToken ?? bearerToken, sessionToken ? 'cookie' : bearerToken ? 'bearer' : 'unknown');
      const user = await auth.authenticateAsync(sessionToken ?? bearerToken, authContext);
      const roleKey = user ? canonicalRoleKey(user.roleKey ?? user.role) : null;
      const accessibleModules = user ? visibleSidebar({ modules: SIDEBAR_MODULES, permissions: user.permissions, roleKey, portal: user.portal, schoolType: user.schoolType, subscription: user.subscription, entitlements: user.entitlements, featureAvailability: user.featureAvailability }).flatMap((group) => group.modules.flatMap((module) => [module, ...(module.children ?? [])])) : [];
      const authorized = user && (pathname === '/dashboard' ? user.portal === 'school' : pathname === '/parent-dashboard' ? user.portal === 'parent' : accessibleModules.some((module) => module.route === pathname) || user.portal === 'parent' && pathname === '/examinations/timetable');
      if (process.env.OSAAH_AUTH_SESSION_DIAGNOSTICS === '1') console.info('Authentication session diagnostic', { requestId: authContext.requestId, requestPath: pathname, stage: 'protected_page_authorization', authenticated: Boolean(user), roleKey: user?.roleKey === 'PROPRIETOR' ? 'PROPRIETOR' : user ? 'OTHER' : null, authorizationGranted: Boolean(authorized) });
      if (!authorized) {
        console.warn('Protected page access rejected', {
          requestPath: pathname,
          embedded: new URL(request.url, 'http://localhost').searchParams.get('embedded') === '1',
          sessionCookiePresent: Boolean(sessionToken),
          bearerTokenPresent: Boolean(bearerToken),
          authenticated: Boolean(user),
          sessionValid: Boolean(user),
          roleResolved: Boolean(roleKey),
          rejectionReason: user ? 'ROLE_ROUTE_FORBIDDEN' : !sessionToken && !bearerToken ? 'CREDENTIAL_MISSING' : 'SESSION_VALIDATION_FAILED',
          portal: user?.portal ?? null,
          roleKey,
          routeVisible: Boolean(user && accessibleModules.some((module) => module.route === pathname))
        });
        const isDocumentNavigation = request.headers['sec-fetch-mode'] === 'navigate' && new URL(request.url, 'http://localhost').searchParams.get('embedded') !== '1';
        if (!user && isDocumentNavigation) { response.writeHead(303, { Location: '/', 'Cache-Control': 'no-store' }); return response.end(); }
        response.writeHead(user ? 403 : 401, { 'Content-Type': 'text/plain; charset=utf-8' }); return response.end(user ? 'Forbidden' : 'Authentication required');
      }
      protectedUser = user;
    }
    let publicAdmissionCookie = null;
    const publicAdmissionPage = false;
    if (publicAdmissionPage) {
      const user = await auth.authenticateAsync(readCookie(request, 'osaah_session') ?? bearer(request));
      const isAuthorizedStaff = user?.portal === 'school'
        && user.schoolId === serviceSchoolId
        && user.permissions instanceof Set
        && canAccess(user, 'admissions.write');
      if (user && user.portal !== 'parent' && !isAuthorizedStaff) {
        response.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
        return response.end('Forbidden');
      }
      const hasApplicationNumber = Boolean(new URL(request.url, 'http://localhost').searchParams.get('applicationNumber'));
      const guestAdmissionSession = readCookie(request, 'osaah_admission_session');
      if (!user && hasApplicationNumber && !guestAdmissionSession) {
        response.writeHead(401, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
        return response.end('Authentication required');
      }
      if (!user && !guestAdmissionSession) publicAdmissionCookie = `osaah_admission_session=${randomUUID()}; Path=/; HttpOnly; SameSite=Lax${secureCookieSuffix(request)}`;
    }
    const fallbackPage = modulePageFallbacks.find(([prefix]) => pathname.startsWith(prefix))?.[1];
    const shellNavigation = ['school', 'parent'].includes(protectedUser?.portal) && request.headers['sec-fetch-mode'] === 'navigate' && new URL(request.url, 'http://localhost').searchParams.get('embedded') !== '1';
    const file = pathname === '/' || shellNavigation ? '/index.html' : pageAliases[pathname] ?? fallbackPage ?? pathname;
    try {
      let body = await readFile(join(root, file));
      const requestedNavigationKey = new URL(request.url, 'http://localhost').searchParams.get('navigationKey');
      const selectedModule = SIDEBAR_MODULES.find((module) => requestedNavigationKey && (module.navigationKey === requestedNavigationKey || module.moduleKey === requestedNavigationKey)) ?? PROPRIETOR_SIDEBAR_ROUTES.find((module) => module.route === pathname) ?? SIDEBAR_MODULES.find((module) => module.route === pathname);
      if (selectedModule && extname(file) === '.html') {
        const contract = resolveRouteContract(selectedModule);
        const label = escapeHtmlText(selectedModule.moduleName);
        body = Buffer.from(body.toString('utf8')
          .replace(/<title>[^<]*<\/title>/i, `<title>${label} | OsaaH Daylight</title>`)
          .replace(/<body([^>]*)>/i, `<body$1 data-current-module="${escapeHtmlText(selectedModule.moduleKey)}" data-navigation-key="${escapeHtmlText(contract.navigationKey)}" data-current-view="${escapeHtmlText(contract.exactView)}" data-current-component="${escapeHtmlText(contract.component)}"><p class="route-context" aria-live="polite">${label}</p>`));
      }
      const revalidate = ['.html', '.js', '.css', '.webmanifest'].includes(extname(file)); response.writeHead(200, { 'Content-Type': mime[extname(file)] ?? 'application/octet-stream', ...(revalidate ? { 'Cache-Control': 'no-cache, must-revalidate' } : {}), ...(publicAdmissionCookie ? { 'Set-Cookie': publicAdmissionCookie } : {}) }); response.end(body);
    } catch { response.writeHead(404); response.end('Not found'); }
  };
}
const aiEnabled = String(process.env.OSAAH_AI_ENABLED ?? 'false').toLowerCase() === 'true';
assertProductionAISystemOfRecordReady({ aiEnabled });
const aiPersistence = aiEnabled ? await loadConfiguredAIPersistence() : createDisabledAIPersistence();
const { capabilities: capabilityRegistry, tools: toolRegistry } = await buildAIRegistry();
const aiAuditLoggerForWiring = createAIAuditLogger({ sink: aiPersistence.auditSink });
const productionDataGuard = createProductionDataGuard({ environment: process.env.NODE_ENV ?? 'development' });
const dataQualityGuard = createAIDataQualityGuard({ productionDataGuard, auditLogger: aiAuditLoggerForWiring });
const schoolContextService = createSchoolContextService({ capabilityRegistry, productionDataGuard, dataQualityGuard, auditLogger: aiAuditLoggerForWiring });
const { registry: providerRegistry, providerId, enabled: providerEnabled } = createConfiguredAIProviderRegistry();
const orchestrator = providerEnabled ? createAIOrchestrator({ providerRegistry, providerId, capabilityRegistry, toolRegistry, productionDataGuard, dataQualityGuard, auditLogger: aiAuditLoggerForWiring }) : null;
const aiGateway = aiEnabled ? createAIGateway({ capabilityRegistry, toolRegistry, schoolContextService, productionDataGuard, dataQualityGuard, auditLogger: aiAuditLoggerForWiring, providerRegistry, providerId, orchestrator }) : null;
const aiConversation = aiEnabled ? createAIConversationService({ gateway: aiGateway, capabilityRegistry, toolRegistry }) : null;
const isDirectExecution = process.argv[1] === fileURLToPath(import.meta.url);
let configuredDatabase;
try {
  configuredDatabase = await loadConfiguredDatabaseAdapter({ required: isDirectExecution || process.env.NODE_ENV === 'production' });
  if (configuredDatabase && (isDirectExecution || process.env.NODE_ENV === 'production')) await configuredDatabase.verifyReadiness();
} catch (error) {
  const code = /^[A-Z0-9_]{1,80}$/.test(String(error?.code ?? '')) ? error.code : 'DATABASE_INITIALIZATION_FAILED';
  console.error('TiDB database initialization failed', { component: 'application_database', operation: 'startup', code });
  try { await configuredDatabase?.close?.(); } catch { /* Preserve the initialization error without exposing driver details. */ }
  configuredDatabase = {
    async query() {
      throw Object.assign(new Error('The configured TiDB database is unavailable.'), { code });
    }
  };
}
const app = createApp({ aiEnabled, aiPersistence, capabilityRegistry, toolRegistry, providerRegistry, providerId, aiGateway, aiConversation, database: configuredDatabase });
const server = createServer(app);
server.on('close', () => {
  void configuredDatabase?.close?.().catch(() => {});
  void aiPersistence.close?.().catch(() => {});
});
const port = Number(process.env.OSAAH_PORT || 3000);
if (process.env.NODE_ENV !== 'production' && isDirectExecution) {
  server.listen(port, () => console.log(`OsaaH foundation listening on http://localhost:${port}`));
}
export { server };
export default app;
function publicUser(user) { const identity = { id: user.id, username: user.username, portal: user.portal, roleKey: user.roleKey, schoolId: user.schoolId }; return user.portal === 'parent' ? identity : { ...identity, children: user.children ?? [], assignedStudentIds: user.assignedStudentIds ?? [], assignedClassIds: user.assignedClassIds ?? [], assignedSubjectIds: user.assignedSubjectIds ?? [], assignedDepartmentIds: user.assignedDepartmentIds ?? [] }; }
async function login(request, response, auth, audit) {
  const requestIdHeader = request.headers['x-vercel-id'] ?? request.headers['x-request-id'];
  const requestId = typeof requestIdHeader === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(requestIdHeader) ? requestIdHeader : randomUUID();
  const diagnosticContext = { requestId, requestPath: '/api/auth/login' };
  try {
    const body = await readJson(request);
    const emailValue = typeof body.email === 'string' ? body.email : body.username;
    const normalizedEmail = typeof emailValue === 'string' ? emailValue.trim().toLowerCase() : '';
    const maskedEmail = normalizedEmail.includes('@') ? `${normalizedEmail[0]}***@${normalizedEmail.split('@').at(-1)}` : null;
    const requestedSchoolId = body.school_id ?? body.schoolId;
    const schoolId = typeof requestedSchoolId === 'string' && /^[A-Za-z0-9_-]{1,80}$/.test(requestedSchoolId) ? requestedSchoolId : null;
    console.info('Authentication login checkpoint', { stage: 'request_received', requestId, requestPath: '/api/auth/login', email: maskedEmail, schoolId, portal: body.portal === 'parent' ? 'parent' : 'school' });
    const isParentPhoneLogin = body.portal === 'parent' && Object.prototype.hasOwnProperty.call(body, 'phone');
    const credentials = isParentPhoneLogin ? { phone: body.phone, portal: 'parent', diagnosticContext, ipAddress: clientIpAddress(request) } : { ...body, diagnosticContext };
    const result = isParentPhoneLogin
      ? (typeof auth.loginByPhoneFromDatabase === 'function' ? await auth.loginByPhoneFromDatabase(credentials) : { ok: false, status: 503, error: 'Authentication service unavailable.' })
      : (typeof auth.loginFromDatabase === 'function' ? await auth.loginFromDatabase(credentials) : auth.login(body));
    console.info('Authentication login checkpoint', { stage: result.ok ? 'session_created' : 'authentication_rejected', requestId, status: result.status ?? 200, authenticated: Boolean(result.ok) });
    if (!result.ok) return json(response, { error: result.error }, result.status);

    audit(createAuditLog({ userId: result.user.id, roleId: result.user.roleKey, sessionId: result.user.sessionId, action: 'LOGIN_SUCCESS', entity: 'Authentication' }));
    const cookie = `osaah_session=${result.token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${Math.floor(auth.sessionTtlMs / 1000)}${secureCookieSuffix(request)}`;
    if (process.env.OSAAH_AUTH_SESSION_DIAGNOSTICS === '1') console.info('Authentication session diagnostic', { requestId, requestPath: '/api/auth/login', stage: 'session_cookie_issued', cookieIssued: true, cookieName: 'osaah_session', path: '/', hostOnly: true, sameSite: 'Lax', secure: cookie.includes('; Secure'), httpOnly: true, maxAgeSeconds: Math.floor(auth.sessionTtlMs / 1000), trustedProxy: process.env.OSAAH_TRUST_PROXY === 'true' || process.env.VERCEL === '1' });
    return json(response, { user: result.user, redirectTo: result.redirectTo, expiresAt: result.expiresAt }, 200, cookie);
  } catch (error) {
    const clientErrors = {
      INVALID_JSON: { status: 400, message: 'Invalid JSON request body.' },
      REQUEST_BODY_TOO_LARGE: { status: 413, message: 'Request body is too large.' }
    };
    const clientError = clientErrors[error?.code];
    console.error('Authentication login request failed', {
      component: 'school_authentication',
      operation: 'login_request',
      category: clientError ? 'INVALID_LOGIN_REQUEST' : 'AUTHENTICATION_SERVICE_FAILED',
      requestId,
      requestPath: '/api/auth/login',
      code: /^[A-Z0-9_]+$/.test(String(error?.code ?? '')) ? error.code : 'UNKNOWN',
      errorType: /^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(String(error?.name ?? '')) ? error.name : 'Error',
      stack: safeAuthenticationStack(error?.stack)
    });
    return json(response, {
      error: clientError?.message ?? 'Authentication service unavailable.'
    }, clientError?.status ?? 503);
  }
}
function safeAuthenticationStack(stack) {
  if (typeof stack !== 'string') return null;
  return stack.split('\n').slice(1, 9).map((line) => line.trim()
    .replace(/(?:mysql|postgres(?:ql)?|https?):\/\/[^\s)]+/gi, '[redacted-url]')
    .replace(/\bBearer\s+[^\s)]+/gi, 'Bearer [redacted]')
    .replace(/\b(password|passwd|secret|token|connection[_ -]?string)\s*[:=]\s*[^\s,;)]+/gi, '$1=[redacted]')
    .slice(0, 300));
}
function secureCookieSuffix(request) {
  const forwardedProto = String(request.headers['x-forwarded-proto'] ?? '').split(',')[0].trim().toLowerCase();
  const trustedProxy = process.env.OSAAH_TRUST_PROXY === 'true' || process.env.VERCEL === '1';
  const secure = process.env.NODE_ENV === 'production' || request.socket?.encrypted || (trustedProxy && forwardedProto === 'https');
  return secure ? '; Secure' : '';
}
function clientIpAddress(request) {
  const trustedProxy = process.env.OSAAH_TRUST_PROXY === 'true' || process.env.VERCEL === '1';
  const forwarded = trustedProxy ? String(request.headers['x-forwarded-for'] ?? '').split(',')[0].trim() : '';
  return forwarded && forwarded.length <= 128 ? forwarded : request.socket?.remoteAddress ?? 'unknown';
}
function readCookie(request, name) {
  const parsedCookie = request.cookies?.[name];
  if (typeof parsedCookie === 'string') return parsedCookie;
  for (const part of String(request.headers.cookie ?? '').split(';')) {
    const separator = part.indexOf('=');
    if (separator < 0 || part.slice(0, separator).trim() !== name) continue;
    return part.slice(separator + 1).trim();
  }
  return undefined;
}
function sessionDiagnosticContext(request, requestPath, token, credentialSource) {
  const suppliedId = request.headers['x-vercel-id'] ?? request.headers['x-request-id'];
  const requestId = typeof suppliedId === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(suppliedId) ? suppliedId : randomUUID();
  const cookieReceived = /(?:^|;\s*)osaah_session=/.test(String(request.headers.cookie ?? '')) || Boolean(request.cookies?.osaah_session);
  return { requestId, requestPath, cookieReceived, cookieParsed: credentialSource === 'cookie' && Boolean(token), credentialSource };
}
function safeFeeError(error, fallbackStatus = 503) { const status = Number.isInteger(error?.status) && error.status >= 400 && error.status < 500 ? error.status : fallbackStatus; const safeMessages = new Set(['Forbidden.', 'Parent access required.', 'Financial read permission required.', 'Financial write permission required.', 'Collection not found.', 'Fee obligation not found.', 'Invalid amount.', 'Collection correction reason required.', 'Invalid collection type.', 'Invalid Extra Classes collection period.', 'Canteen collections support only 1st Term, 2nd Term, and 3rd Term.', 'Fee publication input is invalid.', 'Invalid fee target.', 'Academic year, term, fee type, and amount are required.', 'Academic year not found.', 'Term not found.', 'Fee structure not found.', 'Class is required for a specific-class fee.', 'Class not found.', 'A published fee obligation already exists for this student, fee type, and period. Resolve the existing fee before publishing an overlapping target.']); const message = safeMessages.has(error?.message) ? error.message : 'Fee service is temporarily unavailable.'; return { body: { error: message }, status }; }
function parentApiError(response, error, endpoint) {
  const status = Number.isInteger(error?.status) && error.status >= 400 && error.status <= 599 ? error.status : 503;
  const code = String(error?.code ?? '');
  if (status >= 500) console.error('[Parent API] read failed', { endpoint, code: code || 'UNCLASSIFIED', errno: error?.errno ?? error?.cause?.errno ?? null, sqlState: error?.sqlState ?? error?.cause?.sqlState ?? null, causeCode: error?.cause?.code ?? null, errorType: error?.name ?? 'Error' });
  const message = code.startsWith('PARENT_') ? error.message : status === 403 ? 'Forbidden.' : status === 404 ? 'The requested Parent record was not found.' : status === 501 ? 'Not available yet.' : status === 400 ? 'Check the selected child and academic context.' : 'Unable to load Parent data right now. Check academic setup and try again.';
  return json(response, { error: message, ...(code.startsWith('PARENT_') ? { code } : {}) }, status);
}
function safeReceiptFilename(receiptNumber) { const safe = String(receiptNumber ?? '').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 80) || 'receipt'; return `OSAAH-Receipt-${safe}.pdf`; }
function safeProspectusFilename(prospectus) { const detail = `${prospectus.className}-${prospectus.academicYear}`.replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 80); return `OSAAH-Admission-Prospectus-${detail || 'Published'}.pdf`; }
function bearer(request) { const value = request.headers.authorization ?? ''; const match = /^Bearer\s+(.+)$/i.exec(value); return match?.[1] ?? null; }
function readBytes(request, maxBytes) { return new Promise((resolve, reject) => { const declaredLength = Number(request.headers['content-length'] ?? 0); if (declaredLength > maxBytes) { request.resume(); reject(Object.assign(new Error(`Admission documents may not exceed ${maxBytes} bytes.`), { status: 413 })); return; } const chunks = []; let size = 0, tooLarge = false; request.on('data', (chunk) => { size += chunk.length; if (size > maxBytes) { tooLarge = true; chunks.length = 0; return; } if (!tooLarge) chunks.push(chunk); }); request.on('end', () => tooLarge ? reject(Object.assign(new Error(`Admission documents may not exceed ${maxBytes} bytes.`), { status: 413 })) : resolve(Buffer.concat(chunks))); request.on('error', reject); }); }
function readJson(request) { return new Promise((resolve, reject) => { let data = ''; let tooLarge = false; request.on('data', (chunk) => { if (tooLarge) return; data += chunk; if (data.length > 100_000) { tooLarge = true; data = ''; } }); request.on('end', () => { if (tooLarge) return reject(Object.assign(new Error('Request body is too large.'), { status: 413, code: 'REQUEST_BODY_TOO_LARGE' })); try { resolve(data ? JSON.parse(data) : {}); } catch { reject(Object.assign(new Error('Invalid JSON request body.'), { status: 400, code: 'INVALID_JSON' })); } }); }); }
function presentAdmissionApplication(record) { if (!record) return record; const sanitize = (value) => { if (Array.isArray(value)) return value.map(sanitize); if (!value || typeof value !== 'object') return value; return Object.fromEntries(Object.entries(value).filter(([key]) => !['storageKey', 'fileReference'].includes(key)).map(([key, item]) => [key, sanitize(item)])); }; return { ...sanitize(record), documents: sanitize(record.documents ?? []) }; }
function attendanceApiFailure(response, error, endpoint, actor) {
  const status = Number.isInteger(error?.status) && error.status >= 400 && error.status <= 599 ? error.status : 503;
  const code = String(error?.code ?? (status >= 500 ? 'ATTENDANCE_SERVICE_UNAVAILABLE' : 'ATTENDANCE_REQUEST_INVALID'));
  if (status >= 500) console.error('[Attendance API] request failed', { endpoint, code, schoolId: actor?.schoolId ?? null, roleKey: actor?.roleKey ?? null, errorType: error?.name ?? 'Error', dbCode: error?.code ?? error?.cause?.code ?? null, errno: error?.errno ?? error?.cause?.errno ?? null });
  const message = status >= 500 ? 'The attendance service is temporarily unavailable. Please retry.' : String(error?.message ?? 'Attendance request could not be completed.');
  return json(response, { success: false, data: null, error: message, message, code }, status);
}
function json(response, value, status = 200, cookie) { const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }; if (cookie) headers['Set-Cookie'] = cookie; response.writeHead(status, headers); response.end(status === 204 ? '' : JSON.stringify(value)); }
function escapeHtmlText(value) { return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]); }
