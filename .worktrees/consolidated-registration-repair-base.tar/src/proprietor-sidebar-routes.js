// The authoritative Proprietor navigation contract. Every item gets a stable,
// unique URL while reusing an existing page implementation.
const group = (category, page, entries) => entries.map(([moduleKey, moduleName, route], index) => ({
  moduleKey, moduleName, category, route, page, displayOrder: index + 1
}));

export const PROPRIETOR_SIDEBAR_ROUTES = Object.freeze([
  ...group('ADMINISTRATIVE', '/administrative-modules.html', [
    ['settings', 'School Settings', '/settings'], ['users', 'Users & Roles', '/users'], ['school-profile', 'School Profile', '/settings/profile'],
    ['academic-calendar', 'Academic Calendar', '/academic-calendar'],
    ['single-school-panel', 'Single-School Panel', '/settings/single-school'],
    ['official-documents', 'Official Documents', '/official-documents'],
    ['administrator-management', 'Administrator Management', '/administrator-management'],
    ['signature-management', 'Result Signatures', '/settings/result-signatures']
  ]).map((item) => ({ ...item, page: ({
    'settings': '/school-settings.html',
    'official-documents': '/official-documents.html',
    'users': '/users-and-roles.html', 'academic-calendar': '/academic-calendar.html', 'single-school-panel': '/single-school-panel.html', 'administrator-management': '/administrator-management.html', 'signature-management': '/result-signatures.html'
  })[item.moduleKey] ?? item.page })),
  ...group('ACADEMICS', '/subjects.html', [
    ['academics', 'Academics', '/academics'], ['attendance-dashboard', 'Attendance Overview', '/attendance'],
    ['examinations', 'Score Entry', '/examinations'], ['sporting-activities', 'Sporting Activities', '/sporting-activities'],
    ['student-attendance', "Today's Attendance", '/attendance/students'],
    ['staff-attendance', 'Staff Attendance', '/attendance/staff'], ['results', 'Results & Reports', '/results'],
    ['attendance-reports', 'Attendance Reports', '/attendance/reports'], ['promotion', 'Promotion', '/promotion'],
    ['mock-score-entry', 'Mock Score Entry', '/examinations/mock'], ['subject-management', 'Subject Management', '/academics/subjects'],
    ['mock-results', 'Mock Results', '/results/mock'], ['subject-register', 'Subject Register', '/academics/subject-register'],
    ['academic-years', 'Academic Years', '/academics/years'], ['attendance-alerts', 'Attendance Alerts', '/attendance/alerts'],
    ['exam-timetable', 'Exam Timetable', '/examinations/timetable'], ['academic-terms', 'Terms', '/academics/terms'],
    ['spreadsheets', 'Spreadsheets', '/academics/spreadsheets'], ['academic-classes', 'Classes', '/academics/classes'],
    ['broadsheets', 'Broadsheets', '/results/broadsheets'],
    ['report-cards', 'Report Cards', '/results/report-cards'], ['academic-subjects', 'Subjects', '/academics/subjects/list'],
    ['promotion-results', 'Promotion Results', '/results/promotions'], ['teacher-assignments', 'Teacher Assignments', '/academics/teacher-assignments'],
    ['curriculum', 'Curriculum', '/academics/curriculum'], ['lesson-plans', 'Lesson Plans', '/academics/lesson-plans'],
    ['academic-assignments', 'Assignments', '/academics/assignments'], ['timetable', 'Timetable', '/academics/timetable']
  ]).map((item) => ({ ...item, page: ({
    'exam-timetable': '/exam-timetable.html', 'attendance-dashboard': '/attendance-overview.html', 'student-attendance': '/attendance.html', 'staff-attendance': '/staff-attendance.html', 'broadsheets': '/academic-modules.html', 'attendance-reports': '/reports-academic.html', 'attendance-alerts': '/attendance-alerts.html',
    'academic-classes': '/academic-modules.html', 'academic-subjects': '/subjects.html',
    'promotion': '/promotion.html', 'report-cards': '/results.html', 'promotion-results': '/promotion-results.html',
    'curriculum': '/academic-modules.html', 'lesson-plans': '/academic-modules.html',
    'academic-assignments': '/academic-modules.html', 'timetable': '/exam-timetable.html',
    'spreadsheets': '/academic-modules.html', 'academic-years': '/academic-modules.html',
    'academic-terms': '/academic-modules.html', 'teacher-assignments': '/academic-modules.html'
  })[item.moduleKey] ?? (item.route.startsWith('/attendance') ? '/attendance.html' : item.route.startsWith('/examinations/mock') ? '/mock-examinations.html' : item.route.startsWith('/examinations') ? '/examinations.html' : item.route === '/sporting-activities' ? '/sporting-activities.html' : item.route === '/academics/subject-register' ? '/subject-register.html' : item.route.startsWith('/results/mock') ? '/mock-results.html' : item.route.startsWith('/results') || item.route === '/promotion' ? '/results.html' : item.page) })),
  ...group('FEE HUB', '/fees.html', [
    ['fees', 'Fees', '/fees'], ['finance', 'Finance', '/finance'], ['invoices', 'Invoices & Receipts', '/fees/invoices'],
    ['finance-reports', 'Finance Reports', '/finance/reports'], ['fee-structure', 'Fee Structure', '/fees/structure'],
    ['fee.scholarships', 'Scholarships', '/fees/scholarships'], ['admission-fee-management', 'Admission Fee Structures', '/fees/admission-structures'],
    ['student-fees', 'Student Fees', '/fees/students'], ['income', 'Income', '/finance/income'], ['payments', 'Payments', '/fees/payments'],
    ['expenses', 'Expenses', '/finance/expenses'], ['receipts', 'Receipts', '/fees/receipts'], ['finance-receipts', 'Receipts', '/finance/receipts'], ['cashbook', 'Cashbook', '/finance/cashbook'],
    ['arrears', 'Arrears', '/fees/arrears'], ['budgets', 'Budgets', '/finance/budgets'], ['discounts', 'Discounts', '/fees/discounts'],
    ['fee-statements', 'Fee Statements', '/fees/statements']
  ]).map((item) => ({ ...item, page: '/finance-canonical.html' })),
  ...group('STAFF MANAGEMENT', '/staff.html', [
    ['staff-directory', 'Staff Directory', '/staff'], ['teachers', 'Teachers', '/staff/teachers'], ['hr', 'HR', '/staff/hr'],
    ['leave', 'Leave', '/staff/leave'], ['staff-attendance-hr', 'Staff Attendance', '/staff/attendance'],
    ['qualifications', 'Qualifications / Licences', '/staff/qualifications-licences'], ['performance', 'Performance', '/staff/performance'],
    ['staff.professional-development', 'Professional Development', '/staff/professional-development'],
    ['qualifications-licences', 'Qualifications', '/staff/qualifications'], ['ntc-records', 'NTC Records', '/staff/ntc-records'],
    ['appraisals', 'Appraisal', '/staff/appraisal'], ['hr-documents', 'HR Documents', '/staff/documents']
    ]).map((item) => ({ ...item, page: item.moduleKey === 'leave' ? '/leave.html' : item.moduleKey === 'staff-attendance-hr' ? '/staff-attendance.html' : '/staff-canonical.html' })),
  ...group('STUDENTS MANAGEMENT', '/students.html', [
    ['class-database', 'Class Database', '/class-database.html'], ['student-profiles', 'Student Profiles', '/students'], ['admissions', 'Student Registration', '/admissions/register'], ['student-search', 'Student Search', '/students/search'],
    ['admission-prospectus', 'Admission Prospectus Management', '/admissions/prospectus'], ['student-directory', 'Student Directory', '/students/directory'],
    ['admission-enquiries', 'Enquiries', '/admissions/enquiries'], ['student-ids', 'Student IDs', '/students/ids'],
    ['admission-applications', 'Applications', '/admissions/applications'], ['student-transfers', 'Transfers', '/students/transfers'],
    ['admission-review', 'Application Review', '/admissions/review'], ['student-alumni', 'Alumni', '/students/alumni'],
    ['admission-offers', 'Admission Offers', '/admissions/offers'], ['admission-enrollment', 'Enrollment', '/admissions/enrollment']
    ]).map((item) => ({ ...item, page: item.moduleKey === 'class-database' ? '/class-database.html' : item.moduleKey === 'admission-prospectus' ? '/admission-prospectus.html' : item.moduleKey === 'admissions' ? '/internal-registration.html' : '/student-canonical.html' })),
  ...group('REPORTS & ANALYTICS', '/reports.html', [
    ['reports', 'Reports & Analytics', '/reports'], ['admission-analytics', 'Admission Analytics', '/reports/admissions'],
    ['academic-reports', 'Academic Reports', '/reports/academic'], ['attendance-reports-management', 'Attendance Reports', '/reports/attendance'],
    ['financial-reports', 'Financial Reports', '/reports/financial'], ['enrollment-reports', 'Enrollment Reports', '/reports/enrollment'],
    ['staff-reports', 'Staff Reports', '/reports/staff'], ['operational-reports', 'Operational Reports', '/reports/operations'],
    ['management-dashboard', 'Management Dashboard', '/reports/management']
    ]).map((item) => ({ ...item, page: item.moduleKey === 'admission-analytics' ? '/admission-analytics.html' : item.moduleKey === 'academic-reports' ? '/reports-academic.html' : item.moduleKey === 'financial-reports' ? '/reports-financial.html' : '/reports-canonical.html' })),
  ...group('COMMUNICATION HUB', '/communication.html', [
    ['announcements', 'Announcements', '/communication'], ['messages', 'Messages', '/communication/messages'],
    ['calendar', 'School Calendar', '/communication/school-calendar'], ['sms', 'SMS', '/communication/sms'], ['email', 'Email', '/communication/email'],
    ['notifications', 'Notifications', '/communication/notifications'], ['communication-history', 'Communication History', '/communication/history']
  ]),
  ...group('LIBRARY MANAGEMENT', '/library.html', [['library', 'Library', '/library'], ['library-circulation', 'Borrowing & Returns', '/library/circulation'], ['books', 'Books', '/library/books'], ['borrowing', 'Borrowing', '/library/borrowing'], ['returns', 'Returns', '/library/returns'], ['library-reports', 'Library Reports', '/library/reports']]).map((item) => ({ ...item, page: '/operations-canonical.html' })),
  ...group('TRANSPORT MANAGEMENT', '/transport.html', [['transport', 'Transport', '/transport'], ['transport.gps', 'GPS Tracking', '/transport/gps'], ['transport-routes', 'Routes & Students', '/transport/routes'], ['vehicles', 'Vehicles', '/transport/vehicles'], ['drivers', 'Drivers', '/transport/drivers'], ['routes', 'Routes', '/transport/routes/list'], ['transport-students', 'Students', '/transport/students'], ['trips', 'Trips', '/transport/trips'], ['transport-fees', 'Transport Fees', '/transport/fees']]).map((item) => ({ ...item, page: '/operations-canonical.html' })),
  ...group('HOSTEL MANAGEMENT', '/hostel.html', [['hostel-residences', 'Dormitories & Beds', '/hostel'], ['hostel-roll-call', 'Boarding Roll Call', '/hostel/roll-call'], ['houses', 'Houses', '/hostel/houses'], ['dormitories', 'Dormitories', '/hostel/dormitories'], ['beds', 'Beds', '/hostel/beds'], ['boarders', 'Boarders', '/hostel/boarders'], ['roll-call', 'Roll Call', '/hostel/roll-call/list'], ['hostel-fees', 'Hostel Fees', '/hostel/fees']]).map((item) => ({ ...item, page: '/operations-canonical.html' })),
  ...group('HEALTH & WELFARE', '/welfare.html', [['health-records', 'Health Records', '/welfare/health'], ['discipline', 'Discipline', '/welfare/discipline'], ['counselling', 'Guidance & Counselling', '/welfare/counselling'], ['shep-activities', 'SHEP Activities', '/welfare/shep'], ['health', 'Health', '/welfare/health/overview'], ['sick-bay', 'Sick Bay', '/welfare/health/sick-bay'], ['student-welfare', 'Student Welfare', '/welfare/health/student-welfare']]).map((item) => ({ ...item, page: '/operations-canonical.html' })),
  ...group('INVENTORY & STORES', '/inventory.html', [['inventory', 'Inventory & Stores', '/inventory'], ['inventory-movements', 'Stock Movements', '/inventory/movements'], ['stock', 'Stock', '/inventory/stock'], ['stock-in', 'Stock In', '/inventory/stock-in'], ['stock-out', 'Stock Out', '/inventory/stock-out'], ['suppliers', 'Suppliers', '/inventory/suppliers'], ['inventory-reports', 'Inventory Reports', '/inventory/reports']]).map((item) => ({ ...item, page: '/operations-canonical.html' })),
  ...group('ASSETS & PROPERTY', '/assets.html', [['assets', 'Assets', '/assets'], ['property', 'School Property', '/property'], ['buildings', 'Buildings', '/property/buildings'], ['furniture', 'Furniture', '/property/furniture'], ['maintenance', 'Maintenance', '/property/maintenance'], ['property-reports', 'Property Reports', '/property/reports']]).map((item) => ({ ...item, page: '/operations-canonical.html' })),
  ...group('PROCUREMENT', '/procurement.html', [['procurement', 'Procurement', '/procurement'], ['purchase-requests', 'Purchase Requests', '/procurement/requests'], ['quotations', 'Quotations', '/procurement/quotations'], ['purchase-orders', 'Purchase Orders', '/procurement/orders'], ['goods-received', 'Goods Received', '/procurement/goods-received'], ['procurement-suppliers', 'Suppliers', '/procurement/suppliers']]).map((item) => ({ ...item, page: '/operations-canonical.html' })),
  ...group('SYSTEM & INFORMATION', '/compliance.html', [['compliance', 'Compliance & Regulatory', '/compliance'], ['documents', 'Document Management', '/documents'], ['privacy', 'Privacy & Data Protection', '/privacy'], ['nasia', 'NaSIA', '/compliance/nasia'], ['roles', 'Roles', '/users/roles'], ['ntc', 'NTC', '/compliance/ntc'], ['permissions', 'Permissions', '/users/permissions'], ['fire-safety', 'Fire Safety', '/compliance/fire-safety'], ['audit-logs', 'Audit Logs', '/settings/audit-logs'], ['emis-census', 'EMIS / School Census', '/compliance/emis-census'], ['sessions', 'Sessions', '/settings/sessions'], ['inspections', 'Inspections', '/compliance/inspections'], ['backups', 'Backups', '/settings/backups'], ['compliance-calendar', 'Compliance Calendar', '/compliance/calendar'], ['document-repository', 'Document Repository', '/documents/repository']]).map((item) => ({ ...item, page: '/system-canonical.html' }))
]);

export const PROPRIETOR_PAGE_ALIASES = Object.freeze(Object.fromEntries(PROPRIETOR_SIDEBAR_ROUTES.map(({ route, page }) => [route, page])));
