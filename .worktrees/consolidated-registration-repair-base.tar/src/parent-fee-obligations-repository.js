const PARENT_ROLES = new Set(['PARENT']);

export function createParentFeeObligationsRepository(database) {
  if (!database?.query) throw new Error('A durable database adapter is required.');
  return {
    async listForParent(actor, filters = {}) {
      if (!actor?.id || !actor?.schoolId || !PARENT_ROLES.has(actor.roleKey) || actor.portal !== 'parent') throw new Error('Parent access required.');
      const conditions = ['psl.parent_user_id=?', 's.school_id=?', "psl.link_status='ACTIVE'", 's.is_test_record IS NOT TRUE'];
      const params = [actor.id, actor.schoolId];
      for (const [key, column] of [['academicYearId', 'fo.academic_year_id'], ['termId', 'fo.term_id'], ['feeStructureId', 'fo.fee_structure_id'], ['status', 'fo.status']]) {
        if (filters[key] !== undefined && filters[key] !== '') { conditions.push(`${column}=?`); params.push(filters[key]); }
      }
      if (filters.classId !== undefined && filters.classId !== '') { conditions.push('(fo.class_id=? OR fo.class_id IS NULL)'); params.push(filters.classId); }
      const rows = await database.query(`SELECT psl.student_id AS studentId,s.permanent_student_id AS permanentStudentId,s.first_name AS firstName,s.middle_name AS middleName,s.last_name AS surname,sp.class_id AS classId,s.school_id AS schoolId,fo.id AS obligationId,fo.fee_structure_id AS feeStructureId,fo.academic_year_id AS academicYearId,ay.name AS academicYearName,fo.term_id AS termId,tr.name AS termName,fo.due_date AS dueDate,fo.amount_minor AS amountMinor,fo.custom_fee_type_name AS customFeeTypeName,fo.published_at AS publishedAt,fo.class_id AS targetClassId,COALESCE(NULLIF(fo.custom_fee_type_name,''),ft.name,fo.fee_structure_id) AS feeTypeName,fo.status FROM parent_student_links psl JOIN student_profiles sp ON sp.id=psl.student_id AND sp.school_id=? JOIN students s ON s.id=sp.student_master_id AND s.school_id=sp.school_id LEFT JOIN fee_obligations fo ON fo.student_id=sp.student_master_id AND fo.school_id=s.school_id AND fo.status='PUBLISHED' LEFT JOIN fee_types ft ON ft.id=fo.fee_structure_id AND ft.school_id=fo.school_id LEFT JOIN academic_years ay ON ay.id=fo.academic_year_id AND ay.school_id=fo.school_id LEFT JOIN terms tr ON tr.id=fo.term_id AND tr.academic_year_id=fo.academic_year_id WHERE ${conditions.join(' AND ')}`, [actor.schoolId, ...params]);
      const children = new Map();
      for (const row of rows) {
        if (!children.has(row.studentId)) children.set(row.studentId, { student: { id: row.studentId, permanentStudentId: row.permanentStudentId, name: [row.firstName, row.middleName, row.surname].filter(Boolean).join(' '), classId: row.classId, schoolId: row.schoolId }, obligations: [] });
        if (row.obligationId) children.get(row.studentId).obligations.push({ id: row.obligationId, feeStructureId: row.feeStructureId, academicYearId: row.academicYearId, academicYearName: row.academicYearName ?? row.academicYearId, termId: row.termId, termName: row.termName ?? row.termId, dueDate: row.dueDate, amountMinor: row.amountMinor, customFeeTypeName: row.customFeeTypeName ?? null, feeTypeName: row.feeTypeName ?? row.customFeeTypeName ?? row.feeStructureId ?? null, publishedAt: row.publishedAt ?? null, targetClassId: row.targetClassId ?? null, status: row.status, allocation_status: 'NOT_EVALUATED' });
      }
      return { children: [...children.values()] };
    }
  };
}
